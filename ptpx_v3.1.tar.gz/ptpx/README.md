# ptpx v3.1

Ultra-Low-Latency TCP for HFT Order Entry & Execution

## Overview

ptpx provides kernel-bypass TCP networking for high-frequency trading systems with sub-microsecond latency.

### Supported Transports (Solarflare NICs)

| Transport | API | Latency | Use Case |
|-----------|-----|---------|----------|
| TCPDirect | ZF API | ~200-400ns | Lowest latency |
| Onload | Socket + LD_PRELOAD | ~500ns-1µs | Simpler integration |

### Key Features

- **Dual send paths**: Zero-overhead callback path, lock-free async path
- **Hardware timestamps**: Solarflare NIC timestamps for accurate latency measurement
- **Named poll threads**: CPU affinity and priority configuration
- **Automatic reconnection**: Exponential backoff with jitter
- **Session heartbeats**: Configurable interval and timeout

## Quick Start

```cpp
#include <ptpx_v3.hpp>

using namespace ptpx;

int main() {
    initialize();
    
    // 1. Register named thread
    register_thread("IO_CME")
        .cpu_affinity(2)
        .priority(ThreadPriority::REALTIME)
        .create();
    
    // 2. Create session
    auto session = session("CME_ORDERS")
        .tcpdirect()                    // or .onload()
        .connect_to("10.0.0.1", 9000)
        .thread("IO_CME")
        .hw_timestamps(true)
        .heartbeat(1000, 5000)          // 1s interval, 5s timeout
        .reconnect(100, 30000)          // 100ms initial, 30s max
        .create();
    
    // 3. Set callbacks
    SessionCallbacks cb;
    cb.on_message = [&](ISession& s, const MessageHeader& hdr, 
                        const uint8_t* payload, size_t len) {
        // Process message and respond
        s.send_immediate(MessageType::APPLICATION, payload, len);
    };
    session->set_callbacks(cb);
    
    // 4. Start
    session->start();
    
    // 5. Send from any thread
    uint8_t order[64];
    session->send(MessageType::NEW_ORDER, order, sizeof(order));
    
    // 6. Check latency stats
    auto stats = session->latency_stats().summary();
    printf("RTT: min=%lu ns, avg=%lu ns, max=%lu ns (HW=%s)\n",
           (unsigned long)stats.min_ns, (unsigned long)stats.avg_ns, 
           (unsigned long)stats.max_ns, stats.hw_timestamps ? "yes" : "no");
    
    return 0;
}
```

## Threading Model

### Send API

| Method | Overhead | Usage |
|--------|----------|-------|
| `send_immediate()` | ~0ns | Callback only - direct send |
| `send_async()` | ~15-30ns | Any thread - lock-free queue |
| `send()` | ~2ns check | Auto-detect - uses best path |

### Thread Registry

```cpp
// Register named thread with CPU affinity
register_thread("IO_CME")
    .cpu_affinity(2)
    .priority(ThreadPriority::REALTIME)
    .create();

// Bind session to named thread
auto s = session("CME")
    .thread("IO_CME")  // Share thread with other sessions
    .connect_to("10.0.0.1", 9000)
    .create();
```

## Hardware Timestamps

Accurate latency measurement using Solarflare NIC timestamps:

```cpp
// Enable HW timestamps
auto s = session("TEST")
    .connect_to("10.0.0.1", 9000)
    .hw_timestamps(true)
    .create();

// Check latency stats
auto stats = s->latency_stats().summary();
printf("Min: %lu ns, Avg: %lu ns, Max: %lu ns\n",
       (unsigned long)stats.min_ns, (unsigned long)stats.avg_ns, 
       (unsigned long)stats.max_ns);
printf("Using HW timestamps: %s\n", stats.hw_timestamps ? "yes" : "no");
```

## Building

### Requirements

- C++17 compiler (GCC 9+ or Clang 10+)
- CMake 3.16+
- Google Test (for tests)
- Solarflare drivers (for TCPDirect/Onload)

### Build

```bash
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
make -j4
```

### Run Tests

```bash
cd build
make all_tests
for t in tests/test_*; do ./$t; done
```

## Project Structure

```
ptpx/
├── include/
│   ├── core/
│   │   ├── common.hpp          # Core types, MessageHeader
│   │   ├── mpsc_queue.hpp      # Lock-free queue for async sends
│   │   ├── hw_timestamp.hpp    # Hardware timestamp support
│   │   ├── thread_registry.hpp # Named thread management
│   │   ├── ring_buffer.hpp     # Lock-free ring buffer
│   │   └── timer_wheel.hpp     # Timer wheel for timeouts
│   ├── net/
│   │   ├── transport_v3.hpp    # TCPDirect & Onload transports
│   │   └── session_v3.hpp      # Session layer with dual send
│   └── ptpx_v3.hpp     # Main header
├── tests/
│   ├── test_mpsc_queue.cpp     # 9 tests
│   ├── test_hw_timestamp.cpp   # 15 tests
│   ├── test_session_v3.cpp     # 24 tests
│   ├── test_threading.cpp      # 8 tests
│   └── ...                     # 300+ total tests
├── docs/
│   └── DESIGN.md               # Technical design document
└── README.md
```

## Test Coverage

| Test Suite | Tests | Status |
|------------|-------|--------|
| test_common | 42 | ✅ PASS |
| test_mpsc_queue | 9 | ✅ PASS |
| test_hw_timestamp | 15 | ✅ PASS |
| test_session_v3 | 24 | ✅ PASS |
| test_threading | 8 | ✅ PASS |
| test_transport | 34 | ✅ PASS |
| test_connection_manager | 48 | ✅ PASS |
| test_socket_integration | 13 | ✅ PASS |
| test_ring_buffer | 29 | ✅ PASS |
| **Total** | **300+** | ✅ ALL PASS |

## License

Proprietary - Internal use only.

## Version History

- **v3.1** - Dual send paths, HW timestamps, MPSC queue, named threads
- **v3.0** - Threading model, session binding
- **v2.0** - Runtime transport selection
- **v1.0** - Initial release
