const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
        HeadingLevel, BorderStyle, WidthType, ShadingType, AlignmentType,
        Header, Footer, PageNumber, TableOfContents } = require('docx');
const fs = require('fs');

// Colors
const PRIMARY = "2d3748";
const SECONDARY = "4a5568";
const ACCENT = "3182ce";

const border = { style: BorderStyle.SINGLE, size: 1, color: "e2e8f0" };
const borders = { top: border, bottom: border, left: border, right: border };

function createTable(headers, rows, colWidths) {
    return new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        columnWidths: colWidths,
        rows: [
            new TableRow({
                children: headers.map((h, i) => new TableCell({
                    borders,
                    width: { size: colWidths[i], type: WidthType.DXA },
                    shading: { fill: "edf2f7", type: ShadingType.CLEAR },
                    margins: { top: 80, bottom: 80, left: 120, right: 120 },
                    children: [new Paragraph({ children: [new TextRun({ text: h, bold: true, size: 22, font: "Calibri" })] })]
                }))
            }),
            ...rows.map(row => new TableRow({
                children: row.map((cell, i) => new TableCell({
                    borders,
                    width: { size: colWidths[i], type: WidthType.DXA },
                    margins: { top: 80, bottom: 80, left: 120, right: 120 },
                    children: [new Paragraph({ children: [new TextRun({ text: cell, size: 22, font: "Calibri" })] })]
                }))
            }))
        ]
    });
}

function heading(level, text) {
    return new Paragraph({
        heading: level,
        spacing: { before: 300, after: 150 },
        children: [new TextRun({ text, bold: true, font: "Calibri", 
            size: level === HeadingLevel.HEADING_1 ? 32 : level === HeadingLevel.HEADING_2 ? 28 : 24,
            color: PRIMARY })]
    });
}

function para(text, opts = {}) {
    return new Paragraph({
        spacing: { after: 150 },
        children: [new TextRun({ text, size: 22, font: "Calibri", ...opts })]
    });
}

const doc = new Document({
    styles: {
        default: { document: { run: { font: "Calibri", size: 22 } } },
        paragraphStyles: [
            { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
              run: { size: 32, bold: true, font: "Calibri", color: PRIMARY },
              paragraph: { spacing: { before: 300, after: 150 }, outlineLevel: 0 } },
            { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
              run: { size: 28, bold: true, font: "Calibri", color: PRIMARY },
              paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 1 } },
            { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
              run: { size: 24, bold: true, font: "Calibri", color: SECONDARY },
              paragraph: { spacing: { before: 200, after: 100 }, outlineLevel: 2 } },
        ]
    },
    sections: [{
        properties: {
            page: {
                size: { width: 12240, height: 15840 },
                margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }
            }
        },
        headers: {
            default: new Header({
                children: [new Paragraph({
                    alignment: AlignmentType.RIGHT,
                    children: [new TextRun({ text: "ptpx v3.1 — High Level Design", size: 20, color: SECONDARY, font: "Calibri" })]
                })]
            })
        },
        footers: {
            default: new Footer({
                children: [new Paragraph({
                    alignment: AlignmentType.CENTER,
                    children: [new TextRun({ text: "Page ", size: 20, font: "Calibri" }), new TextRun({ children: [PageNumber.CURRENT], size: 20, font: "Calibri" })]
                })]
            })
        },
        children: [
            // Title
            new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { after: 100 },
                children: [new TextRun({ text: "ptpx", size: 56, bold: true, font: "Calibri", color: PRIMARY })]
            }),
            new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { after: 100 },
                children: [new TextRun({ text: "Precision Trading Protocol for eXchange", size: 24, font: "Calibri", color: SECONDARY, italics: true })]
            }),
            new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { after: 400 },
                children: [new TextRun({ text: "High Level Design — Version 3.1", size: 28, font: "Calibri", color: SECONDARY })]
            }),
            
            // Metadata table
            createTable(
                ["Property", "Value"],
                [
                    ["Version", "3.1.0"],
                    ["Date", "February 2026"],
                    ["Status", "Final"]
                ],
                [3000, 6360]
            ),
            
            new Paragraph({ spacing: { after: 300 }, children: [] }),
            
            // TOC
            new TableOfContents("Table of Contents", { hyperlink: true, headingStyleRange: "1-3" }),
            
            new Paragraph({ spacing: { after: 300 }, children: [] }),
            
            // 1. Overview
            heading(HeadingLevel.HEADING_1, "1. Overview"),
            para("ptpx (Precision Trading Protocol for eXchange) provides ultra-low-latency TCP connectivity for high-frequency trading systems. The library delivers sub-microsecond message processing with deterministic performance characteristics."),
            
            heading(HeadingLevel.HEADING_2, "1.1 Design Goals"),
            createTable(
                ["Goal", "Description"],
                [
                    ["Ultra-Low Latency", "Sub-microsecond message processing on critical path"],
                    ["Deterministic Performance", "Consistent latency with minimal jitter"],
                    ["Dual Send Paths", "Zero-overhead callback path, lock-free async path"],
                    ["Transport Abstraction", "TCPDirect, Onload, Kernel with unified API"],
                    ["Hardware Timestamps", "NIC-level timestamps for accurate measurement"],
                    ["Production Ready", "Comprehensive error handling and recovery"]
                ],
                [2500, 6860]
            ),
            
            new Paragraph({ spacing: { after: 200 }, children: [] }),
            
            // 2. Architecture
            heading(HeadingLevel.HEADING_1, "2. Architecture"),
            para("The library implements a layered architecture separating concerns while maintaining zero-copy data paths."),
            
            createTable(
                ["Layer", "Responsibility"],
                [
                    ["Application", "Order entry, execution handling, business logic"],
                    ["Session", "State management, sequencing, heartbeat"],
                    ["Transport", "Send/receive abstraction, connection lifecycle"],
                    ["Protocol", "Message framing, header serialization"],
                    ["Core", "Timestamps, buffers, lock-free queues"]
                ],
                [2500, 6860]
            ),
            
            new Paragraph({ spacing: { after: 200 }, children: [] }),
            
            // 3. Threading Model
            heading(HeadingLevel.HEADING_1, "3. Threading Model"),
            para("Named poll threads with CPU affinity support. Sessions bind to threads for deterministic processing."),
            
            heading(HeadingLevel.HEADING_2, "3.1 Dual Send Paths"),
            createTable(
                ["Path", "Latency", "Use Case"],
                [
                    ["send_immediate()", "~0 ns overhead", "From message callback only"],
                    ["send_async()", "~30 ns overhead", "From any thread, lock-free MPSC queue"]
                ],
                [3000, 2500, 3860]
            ),
            
            para("The immediate path provides zero overhead when sending from within a message callback. The async path uses a lock-free MPSC queue for cross-thread communication."),
            
            new Paragraph({ spacing: { after: 200 }, children: [] }),
            
            // 4. Session States
            heading(HeadingLevel.HEADING_1, "4. Session Design"),
            
            heading(HeadingLevel.HEADING_2, "4.1 Session States"),
            createTable(
                ["State", "Description"],
                [
                    ["DISCONNECTED", "Initial state, not connected"],
                    ["CONNECTING", "Connection attempt in progress"],
                    ["CONNECTED", "Active session, ready for messaging"],
                    ["CLOSING", "Graceful shutdown, completing pending sends"],
                    ["ERROR", "Unrecoverable error, requires reset"]
                ],
                [2500, 6860]
            ),
            
            new Paragraph({ spacing: { after: 200 }, children: [] }),
            
            // 5. Heartbeat Mechanism
            heading(HeadingLevel.HEADING_1, "5. Heartbeat Mechanism"),
            para("The heartbeat mechanism monitors connection liveness and detects stale connections. Heartbeats use an idle-aware design to avoid unnecessary traffic during active message exchange."),
            
            heading(HeadingLevel.HEADING_2, "5.1 Idle-Aware Design"),
            para("Heartbeats are only sent during idle periods. If application messages are being sent or received, the connection is considered active and heartbeat transmission is suppressed. This reduces unnecessary network traffic and processing overhead on the critical path."),
            
            createTable(
                ["Activity", "Heartbeat Behavior"],
                [
                    ["Application message sent", "Resets idle timer, suppresses heartbeat"],
                    ["Application message received", "Resets idle timer, suppresses heartbeat"],
                    ["Idle period exceeds interval", "Sends HEARTBEAT_REQUEST"],
                    ["No response within timeout", "Triggers disconnect"]
                ],
                [4000, 5360]
            ),
            
            new Paragraph({ spacing: { after: 150 }, children: [] }),
            
            heading(HeadingLevel.HEADING_2, "5.2 Configuration Parameters"),
            createTable(
                ["Parameter", "Default", "Description"],
                [
                    ["heartbeat.enabled", "true", "Enable/disable heartbeat mechanism"],
                    ["heartbeat.interval_ns", "1,000,000,000", "Idle time before sending heartbeat (1 second)"],
                    ["heartbeat.timeout_ns", "5,000,000,000", "Max wait for heartbeat response (5 seconds)"]
                ],
                [3000, 2000, 4360]
            ),
            
            new Paragraph({ spacing: { after: 150 }, children: [] }),
            
            heading(HeadingLevel.HEADING_2, "5.3 Implementation Details"),
            para("The session tracks three timestamps for heartbeat management:"),
            createTable(
                ["Timestamp", "Updated When", "Purpose"],
                [
                    ["last_send_ns_", "Application message sent", "Track outbound activity"],
                    ["last_hb_recv_ns_", "Any message received", "Track inbound activity"],
                    ["last_hb_sent_ns_", "Heartbeat request sent", "Track heartbeat timing"]
                ],
                [2800, 3500, 3060]
            ),
            
            para("Heartbeat decision: send only when now - max(last_send_ns_, last_hb_recv_ns_) > interval_ns"),
            
            new Paragraph({ spacing: { after: 200 }, children: [] }),
            
            // 6. Reconnection
            heading(HeadingLevel.HEADING_1, "6. Reconnection & Failover"),
            para("Automatic reconnection with exponential backoff and optional failover endpoint."),
            
            createTable(
                ["Parameter", "Default", "Description"],
                [
                    ["initial_delay_ms", "100", "First retry delay"],
                    ["max_delay_ms", "30,000", "Maximum backoff delay"],
                    ["multiplier", "2.0", "Exponential factor"],
                    ["jitter", "0.1", "Random variance (±10%)"],
                    ["max_attempts", "0", "Max retries (0 = unlimited)"]
                ],
                [3000, 2000, 4360]
            ),
            
            new Paragraph({ spacing: { after: 200 }, children: [] }),
            
            // 7. Message Protocol
            heading(HeadingLevel.HEADING_1, "7. Message Protocol"),
            para("Fixed 20-byte header followed by variable payload. All fields little-endian."),
            
            createTable(
                ["Field", "Offset", "Size", "Description"],
                [
                    ["length", "0", "4", "Total message length including header"],
                    ["sequence", "4", "4", "Monotonic sequence number"],
                    ["timestamp", "8", "8", "TSC or nanosecond timestamp"],
                    ["type", "16", "1", "Message type enum"],
                    ["flags", "17", "1", "Message flags"],
                    ["reserved", "18", "2", "Reserved for alignment"]
                ],
                [2000, 1500, 1500, 4360]
            ),
            
            new Paragraph({ spacing: { after: 200 }, children: [] }),
            
            // 8. Transport Selection
            heading(HeadingLevel.HEADING_1, "8. Transport Selection"),
            createTable(
                ["Transport", "Latency", "Requirements"],
                [
                    ["TCPDirect", "~200-400 ns", "Solarflare NIC, ZF API license"],
                    ["Onload", "~500 ns - 1 µs", "Solarflare NIC, ef_vi"],
                    ["Kernel", "~2-5 µs", "Standard Linux TCP stack"]
                ],
                [2500, 2500, 4360]
            ),
            
            new Paragraph({ spacing: { after: 200 }, children: [] }),
            
            // 9. Deployment
            heading(HeadingLevel.HEADING_1, "9. Deployment Considerations"),
            
            heading(HeadingLevel.HEADING_2, "9.1 System Configuration"),
            createTable(
                ["Setting", "Recommendation"],
                [
                    ["CPU Isolation", "isolcpus for poll threads"],
                    ["Huge Pages", "1GB pages for buffer allocation"],
                    ["NUMA", "Pin to local memory node"],
                    ["IRQ Affinity", "Steer NIC interrupts to poll cores"],
                    ["Power Management", "Disable C-states, set performance governor"]
                ],
                [3000, 6360]
            ),
            
            new Paragraph({ spacing: { after: 300 }, children: [] }),
            
            new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [new TextRun({ text: "— End of Document —", size: 20, color: SECONDARY, font: "Calibri", italics: true })]
            })
        ]
    }]
});

Packer.toBuffer(doc).then(buffer => {
    fs.writeFileSync("/mnt/user-data/outputs/ptpx_HLD_v3.1.docx", buffer);
    console.log("Created: ptpx_HLD_v3.1.docx (" + buffer.length + " bytes)");
});
