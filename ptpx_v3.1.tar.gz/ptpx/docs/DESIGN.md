# TCP Exchange Library v3.1 - Technical Design

## 1. Overview

TCP Exchange Library provides ultra-low-latency TCP networking for HFT systems.

### Design Goals

1. **Sub-microsecond latency** - Kernel bypass via TCPDirect/Onload
2. **Thread-safe sends** - Any thread can send without blocking
3. **Zero-copy receive** - Callbacks get direct buffer access
4. **Accurate measurement** - Hardware timestamps from NIC
5. **Production resilience** - Auto-reconnect, heartbeats, failover

## 2. Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      Application                            │
├─────────────────────────────────────────────────────────────┤
│  Session Layer                                              │
│  ┌─────────────┐  ┌──────────────┐  ┌───────────────────┐  │
│  │   Session   │  │ SessionBuilder│  │ SessionCallbacks  │  │
│  │  send()     │  │  .tcpdirect() │  │  on_message()     │  │
│  │  send_imm() │  │  .connect_to()│  │  on_connect()     │  │
│  │  send_async()│  │  .thread()   │  │  on_disconnect()  │  │
│  └─────────────┘  └──────────────┘  └───────────────────┘  │
├─────────────────────────────────────────────────────────────┤
│  Transport Layer                                            │
│  ┌─────────────────────┐  ┌─────────────────────────────┐  │
│  │  TCPDirectTransport │  │     OnloadTransport         │  │
│  │  ZF API ~300ns      │  │  Socket+LD_PRELOAD ~800ns   │  │
│  └─────────────────────┘  └─────────────────────────────┘  │
├─────────────────────────────────────────────────────────────┤
│  Core Layer                                                 │
│  ┌───────────┐ ┌────────────┐ ┌──────────┐ ┌────────────┐  │
│  │ MPSCQueue │ │ HWTimestamp│ │LatencyStats│ThreadRegistry│ │
│  └───────────┘ └────────────┘ └──────────┘ └────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

## 3. Threading Model

### 3.1 Core Principle

- **Poll thread**: Handles receive, callbacks, async queue drain
- **Send**: Thread-safe from any thread

### 3.2 Send API

| Method | Thread Safety | Overhead | Use Case |
|--------|--------------|----------|----------|
| `send_immediate()` | Poll thread only | ~0ns | In callbacks |
| `send_async()` | Any thread | ~15-30ns | Cross-thread |
| `send()` | Any thread | ~2ns | Auto-detect |

### 3.3 Implementation

```cpp
SendResult Session::send(MessageType type, const void* payload, size_t len) {
    // Check if we're on poll thread (~2ns)
    if (std::this_thread::get_id() == poll_thread_id_) [[likely]] {
        return send_immediate(type, payload, len);  // Direct path
    }
    return send_async(type, payload, len);          // Queue path
}
```

### 3.4 MPSC Queue

Lock-free multi-producer single-consumer queue for async sends:

- **Push**: CAS on slot state (EMPTY → WRITING → READY)
- **Pop**: Single consumer, no synchronization
- **Capacity**: 4096 slots, configurable
- **Latency**: ~30ns push (measured P50)

## 4. Hardware Timestamps

### 4.1 Timestamp Sources

| Transport | TX Timestamp | RX Timestamp |
|-----------|-------------|--------------|
| TCPDirect | `zft_pkt_get_timestamp()` | `zft_pkt_get_timestamp()` |
| Onload | `SO_TIMESTAMPING` (error queue) | `SO_TIMESTAMPING` (recvmsg) |

### 4.2 LatencyStats

Thread-safe statistics using atomics:

```cpp
class LatencyStats {
    std::atomic<uint64_t> min_rtt_ns_{UINT64_MAX};
    std::atomic<uint64_t> max_rtt_ns_{0};
    std::atomic<uint64_t> sum_rtt_ns_{0};
    std::atomic<uint64_t> count_{0};
    
    void record(HWTimestamp tx, HWTimestamp rx);
    uint64_t min_ns() const;
    uint64_t max_ns() const;
    uint64_t avg_ns() const;
    bool has_hw_timestamps() const;
};
```

## 5. Session Layer

### 5.1 SessionBuilder

Fluent API for configuration:

```cpp
auto session = session("CME_ORDERS")
    .tcpdirect()
    .connect_to("10.0.0.1", 9000)
    .thread("IO_CME")
    .heartbeat(1000, 5000)
    .reconnect(100, 30000, 10)
    .hw_timestamps(true)
    .create();
```

### 5.2 Callbacks

| Callback | Invoked When |
|----------|-------------|
| `on_connect` | Connection established |
| `on_disconnect` | Connection lost (with reason) |
| `on_message` | Message received |
| `on_sequence_gap` | Sequence number gap |
| `on_error` | Error occurred |

### 5.3 Memory Layout

Cache-line optimized for hot path:

```cpp
class Session {
    // Cache line 1: Hot send path
    alignas(64) struct {
        std::unique_ptr<ITransport> transport_;
        std::atomic<SessionState> state_;
        uint32_t send_sequence_;
        std::thread::id poll_thread_id_;
        bool stats_enabled_;
    } hot_;
    
    // Separate cache line: Async queue
    alignas(64) MPSCQueue<4096> async_queue_;
    
    // Cold data: Config, callbacks, stats
    alignas(64) struct { ... } cold_;
};
```

## 6. Transport Layer

### 6.1 TCPDirect

- Uses Solarflare ZF API
- Direct NIC access, bypasses kernel
- ~200-400ns RTT
- Requires ZF library and Solarflare NIC

### 6.2 Onload

- Uses standard socket API
- Accelerated via `LD_PRELOAD=libonload.so`
- ~500ns-1µs RTT
- Simpler deployment, same NIC

### 6.3 Thread Safety

Transport send protected by spinlock:

```cpp
SendResult Transport::send(const void* data, size_t len) {
    while (send_lock_.test_and_set(std::memory_order_acquire)) {
        __builtin_ia32_pause();  // Reduce contention
    }
    auto result = do_send(data, len);
    send_lock_.clear(std::memory_order_release);
    return result;
}
```

## 7. Reconnection

### 7.1 Configuration

```cpp
struct ReconnectConfig {
    bool enabled = true;
    uint64_t initial_delay_ns = 100'000'000;    // 100ms
    uint64_t max_delay_ns = 30'000'000'000ULL;  // 30s
    double backoff_multiplier = 2.0;
    double jitter_factor = 0.1;
    uint32_t max_attempts = 0;  // 0 = unlimited
};
```

### 7.2 Backoff Algorithm

```
delay = initial_delay * (backoff_multiplier ^ attempt)
delay = min(delay, max_delay)
delay += random(-jitter_factor, +jitter_factor) * delay
```

## 8. Test Coverage

| Component | Tests | Coverage |
|-----------|-------|----------|
| MPSC Queue | 9 | Push/pop, concurrent, stress |
| HW Timestamp | 15 | Record, concurrent, invalid |
| Session v3 | 24 | Config, builder, state, send |
| Threading | 8 | Registry, binding, safety |
| Transport | 34 | TCPDirect, Onload, factory |
| **Total** | **300+** | All components |

## 9. Performance Characteristics

| Operation | Latency | Notes |
|-----------|---------|-------|
| `send_immediate()` | ~0ns | Direct syscall/ZF call |
| `send_async()` push | ~30ns | MPSC queue push |
| `send()` check | ~2ns | Thread ID comparison |
| TCPDirect RTT | ~300ns | Wire-to-wire |
| Onload RTT | ~800ns | Wire-to-wire |
| HW timestamp accuracy | ~10ns | NIC clock |

## 10. Files

### Core

- `include/core/common.hpp` - Types, MessageHeader, Config
- `include/core/mpsc_queue.hpp` - Lock-free async send queue
- `include/core/hw_timestamp.hpp` - HW timestamp, LatencyStats
- `include/core/thread_registry.hpp` - Named poll threads

### Network

- `include/net/transport_v3.hpp` - TCPDirect, Onload transports
- `include/net/session_v3.hpp` - Session with dual send paths

### Main Header

- `include/tcp_exchange_v3.hpp` - Includes all components
