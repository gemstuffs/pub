// =============================================================================
// Multi-Session Manager Example
// Demonstrates managing multiple exchange connections simultaneously
// =============================================================================

#include <ptpx.hpp>
#include <iostream>
#include <csignal>
#include <atomic>

using namespace ptpx;

static std::atomic<bool> running{true};

void signal_handler(int) {
    running = false;
}

int main() {
    initialize();
    signal(SIGINT, signal_handler);
    
    std::cout << "\n=== Multi-Session Manager Example ===\n";
    print_capabilities();
    
    // =========================================================================
    // Create Session Manager
    // =========================================================================
    
    SessionManager manager;
    
    // Set global callbacks (applied to all sessions)
    manager.set_global_callbacks({
        .on_connect = [](ISession& s) {
            std::cout << "[" << s.name() << "] CONNECTED via " 
                      << s.transport_name() << "\n";
        },
        
        .on_disconnect = [](ISession& s, DisconnectReason reason) {
            std::cout << "[" << s.name() << "] DISCONNECTED: " 
                      << to_string(reason) << "\n";
        },
        
        .on_message = [](ISession& s, const MessageHeader& h, 
                        const uint8_t* p, size_t len) {
            std::cout << "[" << s.name() << "] MSG type=" 
                      << static_cast<int>(h.type) << "\n";
        },
        
        .on_failover = [](ISession& s, const EndpointConfig& ep) {
            std::cout << "[" << s.name() << "] FAILOVER to " 
                      << ep.to_string() << "\n";
        }
    });
    
    // =========================================================================
    // Add Sessions (Configuration-Driven)
    // =========================================================================
    
    // CME Order Entry - TCPDirect preferred, with failover
    manager.add_session(
        session("CME_ORDERS")
            .as_initiator()
            .connect_to("cme-gateway.example.com", 9000)
            .transport(TransportSubType::TCPDIRECT)
            .interface("enp1s0f0")
            .failover("cme-gateway-dr.example.com", 9000)
            .heartbeat(1000, 5000)
            .reconnect(100, 30000)
            .pin_to_cpu(2)
            .build()
    );
    
    // EUREX Order Entry - Auto transport
    manager.add_session(
        session("EUREX_ORDERS")
            .as_initiator()
            .connect_to("eurex-gateway.example.com", 9001)
            .transport(TransportSubType::AUTO)
            .heartbeat(1000, 5000)
            .reconnect(100, 30000)
            .build()
    );
    
    // ICE Order Entry - OpenOnload preferred
    manager.add_session(
        session("ICE_ORDERS")
            .as_initiator()
            .connect_to("ice-gateway.example.com", 9002)
            .transport(TransportSubType::ONLOAD)
            .heartbeat(2000, 10000)
            .reconnect(500, 60000)
            .build()
    );
    
    // Market Data Feed - No heartbeat, no reconnect
    manager.add_session(
        session("MARKET_DATA")
            .as_initiator()
            .connect_to("md-feed.example.com", 9010)
            .transport(TransportSubType::KERNEL)
            .no_heartbeat()
            .no_reconnect()
            .build()
    );
    
    // =========================================================================
    // Print Session Configuration
    // =========================================================================
    
    std::cout << "\n=== Configured Sessions ===\n";
    manager.for_each_session([](ISession& s) {
        const auto& cfg = s.config();
        std::cout << "\nSession: " << s.name() << "\n"
                  << "  Type:      " << to_string(s.type()) << "\n"
                  << "  Transport: " << to_string(cfg.transport.subtype) << "\n"
                  << "  Endpoint:  " << cfg.transport.primary.to_string() << "\n";
        
        if (cfg.transport.failover.has_value()) {
            std::cout << "  Failover:  " << cfg.transport.failover->to_string() << "\n";
        }
        
        std::cout << "  Heartbeat: " << (cfg.heartbeat.enabled ? "yes" : "no");
        if (cfg.heartbeat.enabled) {
            std::cout << " (" << (cfg.heartbeat.interval_ns / 1000000) << "ms / "
                      << (cfg.heartbeat.timeout_ns / 1000000) << "ms)";
        }
        std::cout << "\n";
        
        std::cout << "  Reconnect: " << (cfg.reconnect.enabled ? "yes" : "no") << "\n";
    });
    
    // =========================================================================
    // Start All Sessions
    // =========================================================================
    
    std::cout << "\n=== Starting All Sessions ===\n";
    manager.start_all();
    
    std::cout << "\nSession count: " << manager.session_count() << "\n";
    std::cout << "Running... Press Ctrl+C to stop\n\n";
    
    // =========================================================================
    // Main Event Loop
    // =========================================================================
    
    while (running) {
        // Poll all sessions
        manager.poll_all();
        
        // Small sleep to avoid busy loop
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
    
    // =========================================================================
    // Print Final Statistics
    // =========================================================================
    
    std::cout << "\n=== Final Statistics ===\n";
    manager.for_each_session([](ISession& s) {
        const auto& stats = s.stats();
        std::cout << "\n" << s.name() << ":\n"
                  << "  State:       " << to_string(s.state()) << "\n"
                  << "  Connects:    " << stats.connect_count << "\n"
                  << "  Disconnects: " << stats.disconnect_count << "\n"
                  << "  Msgs Sent:   " << stats.messages_sent << "\n"
                  << "  Msgs Recv:   " << stats.messages_received << "\n";
        
        if (stats.avg_rtt_ns > 0) {
            std::cout << "  Avg RTT:     " << stats.avg_rtt_ns << " ns\n";
        }
    });
    
    // =========================================================================
    // Stop All Sessions
    // =========================================================================
    
    std::cout << "\n=== Stopping All Sessions ===\n";
    manager.stop_all();
    
    std::cout << "Done.\n";
    return 0;
}
