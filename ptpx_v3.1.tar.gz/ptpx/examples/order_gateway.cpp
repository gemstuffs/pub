// =============================================================================
// Example: Low-Latency Order Gateway Server
// =============================================================================

#include "ptpx.hpp"
#include <iostream>
#include <csignal>
#include <thread>
#include <sched.h>

using namespace ptpx;

// Global server for signal handling
static TCPServer* g_server = nullptr;

void signal_handler(int) {
    if (g_server) {
        g_server->stop();
    }
}

// =============================================================================
// Example Order Handler
// Demonstrates message dispatch and response generation
// =============================================================================

class OrderHandler : public MessageDispatcher<OrderHandler> {
public:
    OrderHandler(TCPServer& server) : server_(server), next_order_id_(1) {}
    
    // Handle incoming message from server
    void handle_message(TCPSession& session, const MessageHeader& header, const uint8_t* payload) {
        // Store current session for response sending
        current_session_ = &session;
        
        // Dispatch to appropriate handler based on message type
        size_t payload_len = header.length - MessageHeader::SIZE;
        dispatch(header, payload, payload_len);
    }
    
protected:
    // Called by dispatcher for new orders
    void on_new_order(const uint8_t* payload, size_t len, const MessageHeader& header) {
        // In production: parse FlatBuffer, validate, send to matching engine
        // For demo: generate immediate ack
        
        // Example latency measurement
        uint64_t recv_tsc = Timestamp::now_tsc();
        uint64_t latency_ns = Timestamp::tsc_to_ns(recv_tsc - header.timestamp_ns);
        
        std::cout << "[ORDER] Session " << current_session_->session_id() 
                  << " NewOrder received, wire-to-parse latency: " 
                  << latency_ns << " ns\n";
        
        // Send acknowledgment (in production: full ExecutionReport)
        send_execution_ack(next_order_id_++);
    }
    
    void on_cancel_order(const uint8_t* payload, size_t len, const MessageHeader& header) {
        std::cout << "[ORDER] Session " << current_session_->session_id() 
                  << " CancelOrder received\n";
        // Handle cancel...
    }
    
    void on_modify_order(const uint8_t* payload, size_t len, const MessageHeader& header) {
        std::cout << "[ORDER] Session " << current_session_->session_id() 
                  << " ModifyOrder received\n";
        // Handle modify...
    }
    
private:
    void send_execution_ack(uint64_t order_id) {
        // In production: build proper FlatBuffer ExecutionReport
        // For demo: send minimal response
        
        // Placeholder - in real implementation use FlatBuffer builder
        uint8_t ack_payload[64] = {0};
        // ... build FlatBuffer here ...
        
        server_.send_to(current_session_->session_id(), 
                        MessageType::EXECUTION_REPORT, 
                        ack_payload, sizeof(ack_payload));
    }
    
    TCPServer& server_;
    TCPSession* current_session_;
    uint64_t next_order_id_;
};

// =============================================================================
// CPU Affinity Helper
// =============================================================================

bool pin_to_cpu(int cpu) {
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(cpu, &cpuset);
    return pthread_setaffinity_np(pthread_self(), sizeof(cpuset), &cpuset) == 0;
}

// =============================================================================
// Main
// =============================================================================

int main(int argc, char* argv[]) {
    // Parse arguments
    uint16_t port = 9000;
    int cpu_affinity = -1;
    bool busy_poll = true;
    
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--port" && i + 1 < argc) {
            port = static_cast<uint16_t>(std::stoi(argv[++i]));
        } else if (arg == "--cpu" && i + 1 < argc) {
            cpu_affinity = std::stoi(argv[++i]);
        } else if (arg == "--no-busy-poll") {
            busy_poll = false;
        }
    }
    
    // Pin to CPU if specified
    if (cpu_affinity >= 0) {
        if (pin_to_cpu(cpu_affinity)) {
            std::cout << "Pinned to CPU " << cpu_affinity << "\n";
        } else {
            std::cerr << "Warning: Failed to pin to CPU " << cpu_affinity << "\n";
        }
    }
    
    // Initialize library
    ptpx::initialize();
    std::cout << "Timestamp calibration complete\n";
    
    // Configure server
    ServerConfig config;
    config.port = port;
    config.max_sessions = 64;
    config.epoll_timeout_ms = busy_poll ? 0 : 1;  // 0 = busy poll
    config.socket_opts = SocketOptions::low_latency();
    
    // Create server
    TCPServer server;
    g_server = &server;
    
    if (!server.initialize(config)) {
        std::cerr << "Failed to initialize server on port " << port << "\n";
        return 1;
    }
    
    std::cout << "Server listening on port " << port << "\n";
    std::cout << "Busy polling: " << (busy_poll ? "enabled" : "disabled") << "\n";
    
    // Create order handler
    OrderHandler handler(server);
    
    // Set up event handlers
    server.set_connect_handler([](TCPSession& session) {
        std::cout << "[CONNECT] Session " << session.session_id() << " connected\n";
    });
    
    server.set_disconnect_handler([](TCPSession& session) {
        std::cout << "[DISCONNECT] Session " << session.session_id() << " disconnected\n";
    });
    
    server.set_message_handler([&handler](TCPSession& session, 
                                           const MessageHeader& header, 
                                           const uint8_t* payload) {
        handler.handle_message(session, header, payload);
    });
    
    server.set_heartbeat_timeout_handler([](TCPSession& session) {
        std::cout << "[TIMEOUT] Session " << session.session_id() << " heartbeat timeout\n";
    });
    
    // Install signal handlers
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);
    
    std::cout << "Press Ctrl+C to stop\n\n";
    
    // Run event loop
    server.run();
    
    std::cout << "\nServer stopped\n";
    
    return 0;
}
