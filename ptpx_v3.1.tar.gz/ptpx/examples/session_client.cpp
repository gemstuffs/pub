// =============================================================================
// Session-Centric Trading Client Example
// Demonstrates the new configuration-driven session architecture
// =============================================================================

#include <ptpx.hpp>
#include <iostream>
#include <csignal>
#include <atomic>

using namespace ptpx;

static std::atomic<bool> running{true};

void signal_handler(int) {
    running = false;
}

int main(int argc, char* argv[]) {
    // Parse arguments
    std::string host = argc > 1 ? argv[1] : "127.0.0.1";
    uint16_t port = argc > 2 ? std::stoi(argv[2]) : 9000;
    std::string failover_host = argc > 3 ? argv[3] : "";
    uint16_t failover_port = argc > 4 ? std::stoi(argv[4]) : 9000;
    
    initialize();
    signal(SIGINT, signal_handler);
    
    std::cout << "\n=== Session-Centric Trading Client ===\n";
    print_capabilities();
    
    // =========================================================================
    // Method 1: Fluent Builder API
    // =========================================================================
    
    auto order_session = session("CME_ORDER_ENTRY")
        .as_initiator()
        .connect_to(host, port)
        .transport(TransportSubType::AUTO)      // Auto-detect best transport
        .interface("eth0")                       // Solarflare interface
        .heartbeat(1000, 5000)                   // 1s interval, 5s timeout
        .reconnect(100, 30000, 0)                // 100ms initial, 30s max, infinite attempts
        .create();
    
    // Add failover if specified
    if (!failover_host.empty()) {
        // Note: In production, failover would be in the builder
        std::cout << "Failover endpoint: " << failover_host << ":" << failover_port << "\n";
    }
    
    // Set up callbacks
    order_session->set_callbacks({
        .on_connect = [](ISession& s) {
            std::cout << "[" << s.name() << "] Connected via " 
                      << s.transport_name() << " (~" 
                      << s.estimated_latency_ns() << "ns)\n";
        },
        
        .on_disconnect = [](ISession& s, DisconnectReason reason) {
            std::cout << "[" << s.name() << "] Disconnected: " 
                      << to_string(reason) << "\n";
        },
        
        .on_state_change = [](ISession& s, SessionState old_state, SessionState new_state) {
            std::cout << "[" << s.name() << "] State: " 
                      << to_string(old_state) << " -> " 
                      << to_string(new_state) << "\n";
        },
        
        .on_message = [](ISession& s, const MessageHeader& h, const uint8_t* p, size_t len) {
            std::cout << "[" << s.name() << "] Received: type=" 
                      << static_cast<int>(h.type) << " seq=" 
                      << h.sequence_number << " len=" << len << "\n";
        },
        
        .on_sequence_gap = [](ISession& s, uint32_t expected, uint32_t received) {
            std::cout << "[" << s.name() << "] SEQUENCE GAP: expected=" 
                      << expected << " received=" << received << "\n";
        },
        
        .on_reconnect_attempt = [](ISession& s, int attempt, uint64_t delay_ns) {
            std::cout << "[" << s.name() << "] Reconnect attempt " 
                      << attempt << " in " << (delay_ns / 1000000) << "ms\n";
        },
        
        .on_failover = [](ISession& s, const EndpointConfig& ep) {
            std::cout << "[" << s.name() << "] Failing over to " 
                      << ep.to_string() << "\n";
        }
    });
    
    // Start session
    std::cout << "\nStarting session '" << order_session->name() << "'...\n";
    
    if (!order_session->start()) {
        std::cerr << "Failed to start session\n";
        return 1;
    }
    
    // Main loop
    std::cout << "Running... Press Ctrl+C to stop\n\n";
    
    int order_count = 0;
    auto last_send = std::chrono::steady_clock::now();
    
    while (running) {
        // Poll for messages
        order_session->poll();
        
        // Send order every second if connected
        if (order_session->is_connected()) {
            auto now = std::chrono::steady_clock::now();
            auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - last_send);
            
            if (elapsed.count() >= 1) {
                uint8_t order_data[64] = {0};
                order_data[0] = static_cast<uint8_t>(++order_count);
                
                auto result = order_session->send_order(order_data, sizeof(order_data));
                if (result == SendResult::SUCCESS) {
                    std::cout << "Sent order #" << order_count 
                              << " (seq=" << order_session->next_send_sequence() - 1 << ")\n";
                }
                
                last_send = now;
            }
        }
        
        // Small sleep to avoid busy loop
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
    
    // Print statistics
    const auto& stats = order_session->stats();
    std::cout << "\n=== Session Statistics ===\n"
              << "Name:             " << order_session->name() << "\n"
              << "Transport:        " << order_session->transport_name() << "\n"
              << "State:            " << to_string(order_session->state()) << "\n"
              << "Connects:         " << stats.connect_count << "\n"
              << "Disconnects:      " << stats.disconnect_count << "\n"
              << "Reconnects:       " << stats.reconnect_count << "\n"
              << "Failovers:        " << stats.failover_count << "\n"
              << "Messages Sent:    " << stats.messages_sent << "\n"
              << "Messages Recv:    " << stats.messages_received << "\n"
              << "Bytes Sent:       " << stats.bytes_sent << "\n"
              << "Bytes Recv:       " << stats.bytes_received << "\n"
              << "Sequence Gaps:    " << stats.sequence_gaps << "\n"
              << "HB Timeouts:      " << stats.heartbeat_timeouts << "\n";
    
    if (stats.min_rtt_ns != UINT64_MAX) {
        std::cout << "RTT Min:          " << stats.min_rtt_ns << " ns\n"
                  << "RTT Avg:          " << stats.avg_rtt_ns << " ns\n"
                  << "RTT Max:          " << stats.max_rtt_ns << " ns\n";
    }
    
    // Stop session
    order_session->stop();
    
    std::cout << "\nSession stopped.\n";
    return 0;
}
