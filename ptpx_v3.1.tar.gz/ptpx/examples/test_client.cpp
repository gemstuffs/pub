// =============================================================================
// Test Client - Latency Measurement
// =============================================================================

#include "ptpx.hpp"
#include <iostream>
#include <cstring>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <vector>
#include <algorithm>
#include <numeric>

using namespace ptpx;

class TestClient {
public:
    TestClient() : fd_(-1), sequence_(0) {}
    
    ~TestClient() {
        if (fd_ >= 0) {
            ::close(fd_);
        }
    }
    
    bool connect(const char* host, uint16_t port) {
        fd_ = socket(AF_INET, SOCK_STREAM, 0);
        if (fd_ < 0) return false;
        
        // Configure socket
        int one = 1;
        setsockopt(fd_, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
        setsockopt(fd_, IPPROTO_TCP, TCP_QUICKACK, &one, sizeof(one));
        
        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(port);
        inet_pton(AF_INET, host, &addr.sin_addr);
        
        if (::connect(fd_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) < 0) {
            ::close(fd_);
            fd_ = -1;
            return false;
        }
        
        return true;
    }
    
    // Send a test order and measure RTT
    uint64_t send_order_and_measure() {
        // Build message
        uint8_t buffer[256];
        MessageHeader* header = reinterpret_cast<MessageHeader*>(buffer);
        
        header->length = MessageHeader::SIZE + 64;  // Header + dummy payload
        header->sequence_number = ++sequence_;
        header->timestamp_ns = Timestamp::now_tsc();
        header->type = MessageType::NEW_ORDER;
        header->flags = 0;
        header->reserved = 0;
        
        // Dummy payload
        std::memset(buffer + MessageHeader::SIZE, 0, 64);
        
        uint64_t send_tsc = Timestamp::now_tsc();
        
        // Send
        ssize_t sent = ::send(fd_, buffer, header->length, 0);
        if (sent != header->length) {
            return UINT64_MAX;
        }
        
        // Receive response
        uint8_t recv_buffer[256];
        ssize_t received = ::recv(fd_, recv_buffer, sizeof(recv_buffer), 0);
        
        uint64_t recv_tsc = Timestamp::now_tsc();
        
        if (received < static_cast<ssize_t>(MessageHeader::SIZE)) {
            return UINT64_MAX;
        }
        
        return Timestamp::tsc_to_ns(recv_tsc - send_tsc);
    }
    
private:
    int fd_;
    uint32_t sequence_;
};

void print_stats(std::vector<uint64_t>& latencies) {
    if (latencies.empty()) {
        std::cout << "No samples\n";
        return;
    }
    
    std::sort(latencies.begin(), latencies.end());
    
    size_t n = latencies.size();
    uint64_t sum = std::accumulate(latencies.begin(), latencies.end(), 0ULL);
    
    std::cout << "\n=== Latency Statistics (ns) ===\n";
    std::cout << "Samples:   " << n << "\n";
    std::cout << "Min:       " << latencies.front() << "\n";
    std::cout << "Max:       " << latencies.back() << "\n";
    std::cout << "Mean:      " << (sum / n) << "\n";
    std::cout << "Median:    " << latencies[n / 2] << "\n";
    std::cout << "P90:       " << latencies[n * 90 / 100] << "\n";
    std::cout << "P99:       " << latencies[n * 99 / 100] << "\n";
    std::cout << "P99.9:     " << latencies[n * 999 / 1000] << "\n";
}

int main(int argc, char* argv[]) {
    const char* host = "127.0.0.1";
    uint16_t port = 9000;
    int iterations = 10000;
    int warmup = 1000;
    
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--host" && i + 1 < argc) {
            host = argv[++i];
        } else if (arg == "--port" && i + 1 < argc) {
            port = static_cast<uint16_t>(std::stoi(argv[++i]));
        } else if (arg == "--iterations" && i + 1 < argc) {
            iterations = std::stoi(argv[++i]);
        }
    }
    
    ptpx::initialize();
    
    TestClient client;
    if (!client.connect(host, port)) {
        std::cerr << "Failed to connect to " << host << ":" << port << "\n";
        return 1;
    }
    
    std::cout << "Connected to " << host << ":" << port << "\n";
    std::cout << "Running " << warmup << " warmup iterations...\n";
    
    // Warmup
    for (int i = 0; i < warmup; ++i) {
        client.send_order_and_measure();
    }
    
    std::cout << "Running " << iterations << " test iterations...\n";
    
    // Actual measurements
    std::vector<uint64_t> latencies;
    latencies.reserve(iterations);
    
    for (int i = 0; i < iterations; ++i) {
        uint64_t rtt = client.send_order_and_measure();
        if (rtt != UINT64_MAX) {
            latencies.push_back(rtt);
        }
        
        if ((i + 1) % 1000 == 0) {
            std::cout << "Progress: " << (i + 1) << "/" << iterations << "\r" << std::flush;
        }
    }
    
    print_stats(latencies);
    
    return 0;
}
