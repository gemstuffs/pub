// =============================================================================
// Trading Client Example
// Demonstrates ExchangeClient with automatic transport selection
// =============================================================================

#include <ptpx.hpp>
#include <iostream>
#include <vector>
#include <algorithm>
#include <chrono>
#include <csignal>
#include <cstring>

using namespace ptpx;

static volatile bool running = true;

void signal_handler(int) {
    running = false;
}

void print_usage(const char* prog) {
    std::cout << "Usage: " << prog << " [options]\n"
              << "Options:\n"
              << "  -h, --host HOST      Server hostname (default: 127.0.0.1)\n"
              << "  -p, --port PORT      Server port (default: 9000)\n"
              << "  -n, --num NUM        Number of orders (default: 10000)\n"
              << "  -t, --transport TYPE Force transport: tcpdirect, onload, kernel, auto\n"
              << "  --help               Show this help\n";
}

int main(int argc, char* argv[]) {
    // Parse arguments
    std::string host = "127.0.0.1";
    uint16_t port = 9000;
    int num_orders = 10000;
    std::string transport_override;
    
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if ((arg == "-h" || arg == "--host") && i + 1 < argc) {
            host = argv[++i];
        } else if ((arg == "-p" || arg == "--port") && i + 1 < argc) {
            port = std::stoi(argv[++i]);
        } else if ((arg == "-n" || arg == "--num") && i + 1 < argc) {
            num_orders = std::stoi(argv[++i]);
        } else if ((arg == "-t" || arg == "--transport") && i + 1 < argc) {
            transport_override = argv[++i];
        } else if (arg == "--help") {
            print_usage(argv[0]);
            return 0;
        }
    }
    
    // Initialize library
    initialize();
    
    // Apply transport override if specified
    if (!transport_override.empty()) {
        if (transport_override == "tcpdirect") {
            use_tcpdirect();
        } else if (transport_override == "onload") {
            use_onload();
        } else if (transport_override == "kernel") {
            use_kernel();
        } else if (transport_override == "auto") {
            use_auto();
        } else {
            std::cerr << "Unknown transport: " << transport_override << "\n";
            return 1;
        }
    }
    
    // Print configuration
    std::cout << "\n=== Trading Client ===\n";
    print_capabilities();
    std::cout << "\nServer: " << host << ":" << port << "\n"
              << "Orders: " << num_orders << "\n\n";
    
    signal(SIGINT, signal_handler);
    
    // Latency tracking
    std::vector<uint64_t> latencies;
    latencies.reserve(num_orders);
    
    // Create client with config
    ExchangeClient::Config cfg;
    cfg.host = host;
    cfg.port = port;
    cfg.auto_reconnect = false;
    cfg.heartbeat_enabled = false;
    
    ExchangeClient client(cfg);
    
    // Set up message callback to track latency
    client.on_message([&](const ReceivedMessage& msg) {
        if (msg.payload_len >= sizeof(uint64_t)) {
            uint64_t send_time;
            std::memcpy(&send_time, msg.payload, sizeof(send_time));
            uint64_t recv_time = Timestamp::now_tsc();
            uint64_t rtt_tsc = recv_time - send_time;
            uint64_t rtt_ns = Timestamp::tsc_to_ns(rtt_tsc);
            latencies.push_back(rtt_ns);
        }
    });
    
    client.on_disconnect([](DisconnectReason reason) {
        std::cout << "Disconnected: " << static_cast<int>(reason) << "\n";
        running = false;
    });
    
    // Connect
    std::cout << "Connecting using " << client.transport_name() 
              << " (~" << client.estimated_latency_ns() << "ns)...\n";
    
    if (!client.connect()) {
        std::cerr << "Failed to connect to " << host << ":" << port << "\n";
        return 1;
    }
    
    std::cout << "Connected. Sending " << num_orders << " orders...\n";
    
    // Warm up
    for (int i = 0; i < 1000 && running; ++i) {
        uint8_t payload[64] = {0};
        client.send_order(payload, sizeof(payload));
        client.poll();
    }
    latencies.clear();
    
    // Benchmark
    auto start = std::chrono::high_resolution_clock::now();
    
    for (int i = 0; i < num_orders && running; ++i) {
        uint8_t payload[64];
        std::memset(payload, 0, sizeof(payload));
        
        // Store send timestamp in payload
        uint64_t send_time = Timestamp::now_tsc();
        std::memcpy(payload, &send_time, sizeof(send_time));
        
        client.send_order(payload, sizeof(payload));
        
        // Poll for response
        for (int j = 0; j < 1000; ++j) {
            client.poll();
            if (latencies.size() > static_cast<size_t>(i)) break;
        }
    }
    
    auto end = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
    
    client.disconnect();
    
    // Print results
    if (!latencies.empty()) {
        std::sort(latencies.begin(), latencies.end());
        
        size_t p50_idx = latencies.size() * 50 / 100;
        size_t p99_idx = latencies.size() * 99 / 100;
        size_t p999_idx = latencies.size() * 999 / 1000;
        
        std::cout << "\n=== Results ===\n"
                  << "Transport: " << client.transport_name() << "\n"
                  << "Messages:  " << latencies.size() << " / " << num_orders << "\n"
                  << "Duration:  " << duration.count() << " ms\n"
                  << "Throughput: " << (latencies.size() * 1000 / duration.count()) << " msg/s\n"
                  << "\nRTT Latency:\n"
                  << "  Min:  " << latencies.front() << " ns\n"
                  << "  P50:  " << latencies[p50_idx] << " ns\n"
                  << "  P99:  " << latencies[p99_idx] << " ns\n"
                  << "  P999: " << latencies[p999_idx] << " ns\n"
                  << "  Max:  " << latencies.back() << " ns\n";
    } else {
        std::cout << "No responses received\n";
    }
    
    return 0;
}
