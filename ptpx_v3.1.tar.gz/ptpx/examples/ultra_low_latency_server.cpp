// =============================================================================
// Ultra Low Latency Server Example
// Demonstrates server with runtime transport info
// =============================================================================

#include <ptpx.hpp>
#include <iostream>
#include <csignal>
#include <atomic>

using namespace ptpx;

static std::atomic<bool> running{true};

void signal_handler(int) {
    running = false;
}

// Handler that echoes messages back
class EchoHandler {
public:
    void operator()(uint32_t session_id, 
                    const MessageHeader& header,
                    const uint8_t* payload, 
                    size_t len,
                    TCPServer& server) {
        // Echo back - creates an execution report response
        server.send(session_id, MessageType::EXECUTION_REPORT, payload, len);
        ++messages_processed_;
    }
    
    uint64_t messages_processed() const { return messages_processed_; }
    
private:
    uint64_t messages_processed_ = 0;
};

void print_usage(const char* prog) {
    std::cout << "Usage: " << prog << " [options]\n"
              << "Options:\n"
              << "  -p, --port PORT     Listen port (default: 9000)\n"
              << "  --help              Show this help\n"
              << "\nFor lowest latency, run with OpenOnload:\n"
              << "  onload --profile=latency " << prog << "\n";
}

int main(int argc, char* argv[]) {
    uint16_t port = 9000;
    
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if ((arg == "-p" || arg == "--port") && i + 1 < argc) {
            port = std::stoi(argv[++i]);
        } else if (arg == "--help") {
            print_usage(argv[0]);
            return 0;
        }
    }
    
    // Initialize and show capabilities
    initialize();
    
    std::cout << "\n=== Ultra Low Latency Server ===\n";
    print_capabilities();
    
    // Check for OpenOnload
    auto caps = TransportCapabilities::detect();
    if (caps.onload_active) {
        std::cout << "\n✓ Running with OpenOnload acceleration\n";
    } else if (caps.solarflare_nic_present) {
        std::cout << "\n⚠ Solarflare NIC detected but OpenOnload not active\n"
                  << "For lower latency, run: onload --profile=latency " << argv[0] << "\n";
    }
    
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);
    
    // Create server
    ServerConfig config;
    config.port = port;
    config.max_sessions = 64;
    config.epoll_timeout_ms = 0;  // Busy poll for lowest latency
    
    EchoHandler handler;
    TCPServer server(config);
    
    // Set up callbacks
    server.set_message_handler([&](uint32_t session_id, 
                                   const MessageHeader& header,
                                   const uint8_t* payload, 
                                   size_t len) {
        handler(session_id, header, payload, len, server);
    });
    
    server.set_connect_handler([](uint32_t session_id) {
        std::cout << "Client connected: session " << session_id << "\n";
    });
    
    server.set_disconnect_handler([](uint32_t session_id) {
        std::cout << "Client disconnected: session " << session_id << "\n";
    });
    
    if (!server.start()) {
        std::cerr << "Failed to start server on port " << port << "\n";
        return 1;
    }
    
    std::cout << "\nListening on port " << port << "...\n"
              << "Press Ctrl+C to stop\n\n";
    
    uint64_t last_count = 0;
    auto last_time = std::chrono::steady_clock::now();
    
    while (running) {
        server.poll(100);  // 100ms timeout for stats printing
        
        // Print stats every 5 seconds
        auto now = std::chrono::steady_clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - last_time);
        if (elapsed.count() >= 5) {
            uint64_t current = handler.messages_processed();
            uint64_t rate = (current - last_count) / elapsed.count();
            if (rate > 0) {
                std::cout << "Messages: " << current << " (rate: " << rate << "/s)\n";
            }
            last_count = current;
            last_time = now;
        }
    }
    
    server.stop();
    std::cout << "\nServer stopped. Total messages: " << handler.messages_processed() << "\n";
    
    return 0;
}
