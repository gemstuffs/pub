#pragma once

#include <cstdint>
#include <cstddef>
#include <cstring>
#include <atomic>
#include <array>
#include <chrono>
#include <x86intrin.h>

namespace ptpx {

// =============================================================================
// Compile-time Configuration
// =============================================================================

struct Config {
    static constexpr size_t MAX_SESSIONS = 64;
    static constexpr size_t MAX_MESSAGE_SIZE = 4096;
    static constexpr size_t RECV_BUFFER_SIZE = 65536;
    static constexpr size_t SEND_BUFFER_SIZE = 65536;
    
    // Heartbeat configuration
    static constexpr uint64_t HEARTBEAT_INTERVAL_NS = 1'000'000'000;  // 1 second
    static constexpr uint64_t HEARTBEAT_TIMEOUT_NS = 3'000'000'000;   // 3 seconds
    static constexpr uint64_t CONNECTION_TIMEOUT_NS = 10'000'000'000; // 10 seconds
    
    // Ring buffer sizes (must be power of 2)
    static constexpr size_t SEND_RING_SIZE = 256;
    static constexpr size_t RECV_RING_SIZE = 256;
    
    // Busy poll configuration
    static constexpr int BUSY_POLL_US = 50;
    static constexpr int BUSY_READ_US = 50;
};

// =============================================================================
// Cache Line Alignment
// =============================================================================

static constexpr size_t CACHE_LINE_SIZE = 64;

#define CACHE_ALIGNED alignas(CACHE_LINE_SIZE)
#define HOT_PATH [[gnu::hot, gnu::flatten]]
#define COLD_PATH [[gnu::cold]]
#define FORCE_INLINE [[gnu::always_inline]] inline
#define LIKELY(x) __builtin_expect(!!(x), 1)
#define UNLIKELY(x) __builtin_expect(!!(x), 0)

// Padding to prevent false sharing
template<typename T>
struct CACHE_ALIGNED CacheAligned {
    T value;
    char padding[CACHE_LINE_SIZE - (sizeof(T) % CACHE_LINE_SIZE)];
};

// =============================================================================
// High-Resolution Timing (RDTSC-based)
// =============================================================================

class Timestamp {
public:
    FORCE_INLINE static uint64_t now_tsc() noexcept {
        return __rdtsc();
    }
    
    FORCE_INLINE static uint64_t now_ns() noexcept {
        // For startup calibration only - avoid in hot path
        auto now = std::chrono::steady_clock::now();
        return std::chrono::duration_cast<std::chrono::nanoseconds>(
            now.time_since_epoch()).count();
    }
    
    // Call once at startup to calibrate TSC to nanoseconds
    static void calibrate() noexcept {
        uint64_t start_tsc = now_tsc();
        uint64_t start_ns = now_ns();
        
        // Busy wait ~10ms for calibration
        while ((now_ns() - start_ns) < 10'000'000) {
            _mm_pause();
        }
        
        uint64_t end_tsc = now_tsc();
        uint64_t end_ns = now_ns();
        
        tsc_frequency_ = static_cast<double>(end_tsc - start_tsc) / 
                         static_cast<double>(end_ns - start_ns);
    }
    
    FORCE_INLINE static uint64_t tsc_to_ns(uint64_t tsc) noexcept {
        return static_cast<uint64_t>(static_cast<double>(tsc) / tsc_frequency_);
    }
    
private:
    static inline double tsc_frequency_ = 1.0;
};

// =============================================================================
// Message Types
// =============================================================================

enum class MessageType : uint8_t {
    HEARTBEAT_REQUEST = 0x01,
    HEARTBEAT_RESPONSE = 0x02,
    NEW_ORDER = 0x10,
    CANCEL_ORDER = 0x11,
    MODIFY_ORDER = 0x12,
    EXECUTION_REPORT = 0x20,
    ORDER_REJECT = 0x21,
    CANCEL_REJECT = 0x22,
};

// Wire format header (fixed size, before FlatBuffer payload)
struct __attribute__((packed)) MessageHeader {
    uint32_t length;           // Total message length including header
    uint32_t sequence_number;  // For gap detection
    uint64_t timestamp_ns;     // Sender timestamp
    MessageType type;          // Message type
    uint8_t flags;             // Reserved
    uint16_t reserved;         // Alignment padding
    
    static constexpr size_t SIZE = 20;
};

static_assert(sizeof(MessageHeader) == MessageHeader::SIZE, "Header size mismatch");

// =============================================================================
// Session State
// =============================================================================

enum class SessionState : uint8_t {
    DISCONNECTED = 0,
    CONNECTING,
    CONNECTED,
    DRAINING,
    ERROR
};

// =============================================================================
// Result Types
// =============================================================================

enum class SendResult : int8_t {
    SUCCESS = 0,
    QUEUED = 1,           // Message queued for async send
    WOULD_BLOCK = -1,
    DISCONNECTED = -2,
    BUFFER_FULL = -3,
    QUEUE_FULL = -4,      // Async queue full
    ERROR = -5
};

enum class RecvResult : int8_t {
    SUCCESS = 0,
    WOULD_BLOCK = -1,
    DISCONNECTED = -2,
    INCOMPLETE = -3,
    ERROR = -4
};

// =============================================================================
// Memory Utilities
// =============================================================================

template<size_t SIZE>
class CACHE_ALIGNED PreallocatedBuffer {
public:
    PreallocatedBuffer() noexcept : read_pos_(0), write_pos_(0) {}
    
    FORCE_INLINE uint8_t* write_ptr() noexcept { 
        return data_.data() + write_pos_; 
    }
    
    FORCE_INLINE const uint8_t* read_ptr() const noexcept { 
        return data_.data() + read_pos_; 
    }
    
    FORCE_INLINE size_t writable() const noexcept { 
        return SIZE - write_pos_; 
    }
    
    FORCE_INLINE size_t readable() const noexcept { 
        return write_pos_ - read_pos_; 
    }
    
    FORCE_INLINE void advance_write(size_t n) noexcept { 
        write_pos_ += n; 
    }
    
    FORCE_INLINE void advance_read(size_t n) noexcept { 
        read_pos_ += n; 
    }
    
    FORCE_INLINE void compact() noexcept {
        if (read_pos_ > 0) {
            size_t remaining = readable();
            if (remaining > 0) {
                std::memmove(data_.data(), read_ptr(), remaining);
            }
            read_pos_ = 0;
            write_pos_ = remaining;
        }
    }
    
    FORCE_INLINE void reset() noexcept {
        read_pos_ = 0;
        write_pos_ = 0;
    }
    
private:
    std::array<uint8_t, SIZE> data_;
    size_t read_pos_;
    size_t write_pos_;
};

} // namespace ptpx
