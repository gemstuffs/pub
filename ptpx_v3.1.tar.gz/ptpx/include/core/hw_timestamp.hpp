// =============================================================================
// ptpx v3.0 - Hardware Timestamps
// =============================================================================
//
// Support for NIC hardware timestamps (Solarflare).
// Provides accurate wire-level latency measurement.
//
// =============================================================================

#pragma once

#include <cstdint>
#include <atomic>

#ifdef __linux__
#include <linux/net_tstamp.h>
#include <linux/errqueue.h>
#include <sys/socket.h>
#include <time.h>
#endif

namespace ptpx {

// =============================================================================
// Hardware Timestamp
// =============================================================================

struct HWTimestamp {
    uint64_t ns;      // Nanoseconds (NIC clock or system clock)
    bool valid;       // True if timestamp is from hardware
    bool is_hw;       // True if from NIC, false if software fallback
    
    HWTimestamp() : ns(0), valid(false), is_hw(false) {}
    HWTimestamp(uint64_t n, bool v, bool hw = true) : ns(n), valid(v), is_hw(hw) {}
    
    static HWTimestamp invalid() { return HWTimestamp(); }
    static HWTimestamp now_sw();  // Software timestamp fallback
};

// =============================================================================
// Latency Statistics (HW timestamp based)
// =============================================================================

class LatencyStats {
    std::atomic<uint64_t> min_rtt_ns_{UINT64_MAX};
    std::atomic<uint64_t> max_rtt_ns_{0};
    std::atomic<uint64_t> sum_rtt_ns_{0};
    std::atomic<uint64_t> count_{0};
    std::atomic<uint64_t> last_rtt_ns_{0};
    std::atomic<bool> has_hw_timestamps_{false};
    
public:
    LatencyStats() = default;
    
    // Record RTT from TX and RX timestamps
    void record(HWTimestamp tx, HWTimestamp rx) {
        if (!tx.valid || !rx.valid) return;
        if (rx.ns <= tx.ns) return;  // Invalid
        
        uint64_t rtt = rx.ns - tx.ns;
        
        last_rtt_ns_.store(rtt, std::memory_order_relaxed);
        sum_rtt_ns_.fetch_add(rtt, std::memory_order_relaxed);
        count_.fetch_add(1, std::memory_order_relaxed);
        
        if (tx.is_hw && rx.is_hw) {
            has_hw_timestamps_.store(true, std::memory_order_relaxed);
        }
        
        // Atomic min
        uint64_t cur = min_rtt_ns_.load(std::memory_order_relaxed);
        while (rtt < cur) {
            if (min_rtt_ns_.compare_exchange_weak(cur, rtt, 
                    std::memory_order_relaxed, std::memory_order_relaxed)) {
                break;
            }
        }
        
        // Atomic max
        cur = max_rtt_ns_.load(std::memory_order_relaxed);
        while (rtt > cur) {
            if (max_rtt_ns_.compare_exchange_weak(cur, rtt,
                    std::memory_order_relaxed, std::memory_order_relaxed)) {
                break;
            }
        }
    }
    
    // Record one-way latency
    void record_oneway(uint64_t latency_ns, bool is_hw = true) {
        last_rtt_ns_.store(latency_ns, std::memory_order_relaxed);
        sum_rtt_ns_.fetch_add(latency_ns, std::memory_order_relaxed);
        count_.fetch_add(1, std::memory_order_relaxed);
        
        if (is_hw) {
            has_hw_timestamps_.store(true, std::memory_order_relaxed);
        }
        
        uint64_t cur = min_rtt_ns_.load(std::memory_order_relaxed);
        while (latency_ns < cur) {
            if (min_rtt_ns_.compare_exchange_weak(cur, latency_ns,
                    std::memory_order_relaxed, std::memory_order_relaxed)) {
                break;
            }
        }
        
        cur = max_rtt_ns_.load(std::memory_order_relaxed);
        while (latency_ns > cur) {
            if (max_rtt_ns_.compare_exchange_weak(cur, latency_ns,
                    std::memory_order_relaxed, std::memory_order_relaxed)) {
                break;
            }
        }
    }
    
    void reset() {
        min_rtt_ns_.store(UINT64_MAX, std::memory_order_relaxed);
        max_rtt_ns_.store(0, std::memory_order_relaxed);
        sum_rtt_ns_.store(0, std::memory_order_relaxed);
        count_.store(0, std::memory_order_relaxed);
        last_rtt_ns_.store(0, std::memory_order_relaxed);
        has_hw_timestamps_.store(false, std::memory_order_relaxed);
    }
    
    // Getters
    uint64_t min_ns() const { 
        uint64_t v = min_rtt_ns_.load(std::memory_order_relaxed);
        return v == UINT64_MAX ? 0 : v;
    }
    uint64_t max_ns() const { return max_rtt_ns_.load(std::memory_order_relaxed); }
    uint64_t last_ns() const { return last_rtt_ns_.load(std::memory_order_relaxed); }
    uint64_t count() const { return count_.load(std::memory_order_relaxed); }
    bool has_hw_timestamps() const { return has_hw_timestamps_.load(std::memory_order_relaxed); }
    
    uint64_t avg_ns() const {
        uint64_t c = count_.load(std::memory_order_relaxed);
        if (c == 0) return 0;
        return sum_rtt_ns_.load(std::memory_order_relaxed) / c;
    }
    
    // Summary structure
    struct Summary {
        uint64_t min_ns;
        uint64_t max_ns;
        uint64_t avg_ns;
        uint64_t last_ns;
        uint64_t count;
        bool hw_timestamps;
    };
    
    Summary summary() const {
        return {
            .min_ns = min_ns(),
            .max_ns = max_ns(),
            .avg_ns = avg_ns(),
            .last_ns = last_ns(),
            .count = count(),
            .hw_timestamps = has_hw_timestamps()
        };
    }
};

// =============================================================================
// Hardware Timestamp Utilities
// =============================================================================

#ifdef __linux__

namespace hw_timestamp {

// Enable hardware timestamping on a socket
inline bool enable(int fd) {
    int flags = SOF_TIMESTAMPING_TX_HARDWARE |
                SOF_TIMESTAMPING_RX_HARDWARE |
                SOF_TIMESTAMPING_RAW_HARDWARE |
                SOF_TIMESTAMPING_OPT_TSONLY;
    
    return setsockopt(fd, SOL_SOCKET, SO_TIMESTAMPING, &flags, sizeof(flags)) == 0;
}

// Enable software timestamping as fallback
inline bool enable_software(int fd) {
    int flags = SOF_TIMESTAMPING_TX_SOFTWARE |
                SOF_TIMESTAMPING_RX_SOFTWARE |
                SOF_TIMESTAMPING_SOFTWARE;
    
    return setsockopt(fd, SOL_SOCKET, SO_TIMESTAMPING, &flags, sizeof(flags)) == 0;
}

// Extract timestamp from control message
inline HWTimestamp extract_from_cmsg(struct msghdr* msg) {
    for (struct cmsghdr* cmsg = CMSG_FIRSTHDR(msg); 
         cmsg != nullptr; 
         cmsg = CMSG_NXTHDR(msg, cmsg)) {
        
        if (cmsg->cmsg_level == SOL_SOCKET &&
            cmsg->cmsg_type == SO_TIMESTAMPING) {
            
            auto* ts = reinterpret_cast<struct scm_timestamping*>(CMSG_DATA(cmsg));
            
            // ts->ts[0] = software timestamp
            // ts->ts[1] = deprecated
            // ts->ts[2] = raw hardware timestamp
            
            // Prefer hardware timestamp
            if (ts->ts[2].tv_sec != 0 || ts->ts[2].tv_nsec != 0) {
                return HWTimestamp(
                    static_cast<uint64_t>(ts->ts[2].tv_sec) * 1'000'000'000ULL +
                    static_cast<uint64_t>(ts->ts[2].tv_nsec),
                    true,
                    true  // is_hw = true
                );
            }
            
            // Fall back to software timestamp
            if (ts->ts[0].tv_sec != 0 || ts->ts[0].tv_nsec != 0) {
                return HWTimestamp(
                    static_cast<uint64_t>(ts->ts[0].tv_sec) * 1'000'000'000ULL +
                    static_cast<uint64_t>(ts->ts[0].tv_nsec),
                    true,
                    false  // is_hw = false
                );
            }
        }
    }
    
    return HWTimestamp::invalid();
}

// Get TX timestamp from error queue (for kernel sockets)
inline HWTimestamp get_tx_timestamp(int fd) {
    char control[256];
    struct msghdr msg = {};
    msg.msg_control = control;
    msg.msg_controllen = sizeof(control);
    
    // TX timestamps come via error queue
    if (recvmsg(fd, &msg, MSG_ERRQUEUE | MSG_DONTWAIT) >= 0) {
        return extract_from_cmsg(&msg);
    }
    
    return HWTimestamp::invalid();
}

}  // namespace hw_timestamp

#endif  // __linux__

// =============================================================================
// Implementation
// =============================================================================

inline HWTimestamp HWTimestamp::now_sw() {
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    return HWTimestamp(
        static_cast<uint64_t>(ts.tv_sec) * 1'000'000'000ULL +
        static_cast<uint64_t>(ts.tv_nsec),
        true,
        false  // Software timestamp
    );
}

} // namespace ptpx
