// =============================================================================
// ptpx v3.0 - MPSC Lock-Free Queue
// =============================================================================
//
// Multi-Producer Single-Consumer queue for async send path.
// Uses spinlock for correctness - simple and reliable.
//
// =============================================================================

#pragma once

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <cstring>

namespace ptpx {

// =============================================================================
// Send Request - Stored in queue
// =============================================================================

struct SendRequest {
    static constexpr size_t MAX_PAYLOAD = 4096;
    
    alignas(64) uint8_t payload[MAX_PAYLOAD];
    size_t len;
    uint64_t enqueue_tsc;  // For latency tracking
    
    SendRequest() : len(0), enqueue_tsc(0) {}
    
    bool set(const void* data, size_t data_len, uint64_t tsc) {
        if (data_len > MAX_PAYLOAD) return false;
        std::memcpy(payload, data, data_len);
        len = data_len;
        enqueue_tsc = tsc;
        return true;
    }
};

// =============================================================================
// MPSC Queue - Simple spinlock-based bounded queue
// =============================================================================

template<size_t Capacity = 4096>
class MPSCQueue {
    static_assert((Capacity & (Capacity - 1)) == 0, "Capacity must be power of 2");
    static constexpr size_t MASK = Capacity - 1;
    
    alignas(64) SendRequest slots_[Capacity];
    alignas(64) size_t head_{0};  // Write position
    alignas(64) size_t tail_{0};  // Read position
    alignas(64) std::atomic_flag lock_ = ATOMIC_FLAG_INIT;
    
    void lock() {
        while (lock_.test_and_set(std::memory_order_acquire)) {
            #if defined(__x86_64__) || defined(__i386__)
            __builtin_ia32_pause();
            #endif
        }
    }
    
    void unlock() {
        lock_.clear(std::memory_order_release);
    }
    
public:
    MPSCQueue() = default;
    
    // Non-copyable, non-movable
    MPSCQueue(const MPSCQueue&) = delete;
    MPSCQueue& operator=(const MPSCQueue&) = delete;
    
    // =========================================================================
    // Producer API (any thread)
    // =========================================================================
    
    bool try_push(const void* data, size_t len, uint64_t tsc = 0) {
        if (len > SendRequest::MAX_PAYLOAD) return false;
        
        lock();
        
        // Check if full
        if (head_ - tail_ >= Capacity) {
            unlock();
            return false;
        }
        
        // Write to slot
        size_t idx = head_ & MASK;
        slots_[idx].set(data, len, tsc);
        ++head_;
        
        unlock();
        return true;
    }
    
    // =========================================================================
    // Consumer API (single thread only - poll thread)
    // =========================================================================
    
    SendRequest* try_pop() {
        lock();
        
        // Check if empty
        if (head_ == tail_) {
            unlock();
            return nullptr;
        }
        
        size_t idx = tail_ & MASK;
        // Note: We keep the lock until pop_commit() or return nullptr
        // This is safe because only one consumer exists
        return &slots_[idx];
    }
    
    void pop_commit() {
        ++tail_;
        unlock();
    }
    
    // Pop and immediately commit (safer API)
    bool try_pop_copy(SendRequest& out) {
        lock();
        
        if (head_ == tail_) {
            unlock();
            return false;
        }
        
        size_t idx = tail_ & MASK;
        out = slots_[idx];
        ++tail_;
        
        unlock();
        return true;
    }
    
    // Convenience: pop and auto-commit
    template<typename Func>
    bool try_pop_and_process(Func&& func) {
        SendRequest req;
        if (try_pop_copy(req)) {
            func(req);
            return true;
        }
        return false;
    }
    
    // Drain all pending items
    template<typename Func>
    size_t drain(Func&& func) {
        size_t count = 0;
        SendRequest req;
        while (try_pop_copy(req)) {
            func(req);
            ++count;
        }
        return count;
    }
    
    // =========================================================================
    // Status
    // =========================================================================
    
    bool empty() {
        lock();
        bool e = (head_ == tail_);
        unlock();
        return e;
    }
    
    size_t capacity() const { return Capacity; }
    
    size_t size_approx() {
        lock();
        size_t s = head_ - tail_;
        unlock();
        return s;
    }
};

} // namespace ptpx
