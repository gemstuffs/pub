#pragma once

#include "common.hpp"
#include <atomic>
#include <new>

namespace ptpx {

// =============================================================================
// Lock-Free SPSC Ring Buffer
// Single Producer, Single Consumer - optimal for hot path
// =============================================================================

template<typename T, size_t CAPACITY>
class SPSCRingBuffer {
    static_assert((CAPACITY & (CAPACITY - 1)) == 0, "Capacity must be power of 2");
    static_assert(CAPACITY >= 2, "Capacity must be at least 2");
    
public:
    SPSCRingBuffer() noexcept : head_(0), tail_(0) {
        static_assert(sizeof(Node) % CACHE_LINE_SIZE == 0, "Node must be cache-aligned");
    }
    
    // Producer: try to push item
    // Returns true if successful, false if full
    template<typename... Args>
    HOT_PATH bool try_push(Args&&... args) noexcept {
        const size_t current_tail = tail_.load(std::memory_order_relaxed);
        const size_t next_tail = (current_tail + 1) & MASK;
        
        // Check if full
        if (UNLIKELY(next_tail == head_.load(std::memory_order_acquire))) {
            return false;
        }
        
        // Construct in place
        new (&buffer_[current_tail].data) T(std::forward<Args>(args)...);
        
        // Publish
        tail_.store(next_tail, std::memory_order_release);
        return true;
    }
    
    // Consumer: try to pop item
    // Returns true if successful, false if empty
    HOT_PATH bool try_pop(T& item) noexcept {
        const size_t current_head = head_.load(std::memory_order_relaxed);
        
        // Check if empty
        if (UNLIKELY(current_head == tail_.load(std::memory_order_acquire))) {
            return false;
        }
        
        // Move out
        item = std::move(buffer_[current_head].data);
        
        // Destroy
        buffer_[current_head].data.~T();
        
        // Advance head
        head_.store((current_head + 1) & MASK, std::memory_order_release);
        return true;
    }
    
    // Non-destructive peek at front
    HOT_PATH const T* peek() const noexcept {
        const size_t current_head = head_.load(std::memory_order_relaxed);
        if (current_head == tail_.load(std::memory_order_acquire)) {
            return nullptr;
        }
        return &buffer_[current_head].data;
    }
    
    FORCE_INLINE size_t size() const noexcept {
        const size_t tail = tail_.load(std::memory_order_acquire);
        const size_t head = head_.load(std::memory_order_acquire);
        return (tail - head) & MASK;
    }
    
    FORCE_INLINE bool empty() const noexcept {
        return head_.load(std::memory_order_acquire) == 
               tail_.load(std::memory_order_acquire);
    }
    
    FORCE_INLINE bool full() const noexcept {
        const size_t next_tail = (tail_.load(std::memory_order_relaxed) + 1) & MASK;
        return next_tail == head_.load(std::memory_order_acquire);
    }
    
    static constexpr size_t capacity() noexcept { return CAPACITY - 1; }
    
private:
    static constexpr size_t MASK = CAPACITY - 1;
    
    // Cache-aligned node to prevent false sharing between elements
    struct CACHE_ALIGNED Node {
        T data;
    };
    
    // Hot data - keep producer and consumer indices on separate cache lines
    CACHE_ALIGNED std::atomic<size_t> head_;  // Consumer writes, producer reads
    CACHE_ALIGNED std::atomic<size_t> tail_;  // Producer writes, consumer reads
    
    // Cold data - the actual buffer
    std::array<Node, CAPACITY> buffer_;
};

// =============================================================================
// Message Slot for Zero-Copy FlatBuffer Handling
// =============================================================================

struct MessageSlot {
    alignas(16) std::array<uint8_t, Config::MAX_MESSAGE_SIZE> buffer;
    uint32_t length;
    uint32_t sequence;
    uint64_t timestamp;
    MessageType type;
    
    MessageSlot() noexcept : length(0), sequence(0), timestamp(0), type(MessageType::HEARTBEAT_REQUEST) {}
    
    FORCE_INLINE uint8_t* data() noexcept { return buffer.data(); }
    FORCE_INLINE const uint8_t* data() const noexcept { return buffer.data(); }
    
    // Zero-copy access to FlatBuffer payload (after header)
    FORCE_INLINE uint8_t* payload() noexcept { 
        return buffer.data() + MessageHeader::SIZE; 
    }
    FORCE_INLINE const uint8_t* payload() const noexcept { 
        return buffer.data() + MessageHeader::SIZE; 
    }
    FORCE_INLINE size_t payload_size() const noexcept { 
        return length > MessageHeader::SIZE ? length - MessageHeader::SIZE : 0; 
    }
};

// =============================================================================
// Pre-allocated Message Pool
// =============================================================================

template<size_t POOL_SIZE>
class MessagePool {
    static_assert((POOL_SIZE & (POOL_SIZE - 1)) == 0, "Pool size must be power of 2");
    
public:
    MessagePool() noexcept : free_head_(0) {
        // Initialize free list
        for (size_t i = 0; i < POOL_SIZE; ++i) {
            free_indices_[i].store(i, std::memory_order_relaxed);
        }
    }
    
    // Acquire a slot from pool
    HOT_PATH MessageSlot* acquire() noexcept {
        const size_t head = free_head_.load(std::memory_order_relaxed);
        
        for (size_t i = 0; i < POOL_SIZE; ++i) {
            size_t idx = (head + i) & MASK;
            size_t slot_idx = free_indices_[idx].load(std::memory_order_relaxed);
            
            if (slot_idx != INVALID_INDEX) {
                if (free_indices_[idx].compare_exchange_strong(
                        slot_idx, INVALID_INDEX, 
                        std::memory_order_acquire, 
                        std::memory_order_relaxed)) {
                    free_head_.store((idx + 1) & MASK, std::memory_order_relaxed);
                    return &slots_[slot_idx];
                }
            }
        }
        return nullptr;  // Pool exhausted
    }
    
    // Release slot back to pool
    HOT_PATH void release(MessageSlot* slot) noexcept {
        if (UNLIKELY(slot == nullptr)) return;
        
        size_t slot_idx = slot - slots_.data();
        if (UNLIKELY(slot_idx >= POOL_SIZE)) return;
        
        // Find free position
        for (size_t i = 0; i < POOL_SIZE; ++i) {
            size_t expected = INVALID_INDEX;
            if (free_indices_[i].compare_exchange_strong(
                    expected, slot_idx,
                    std::memory_order_release,
                    std::memory_order_relaxed)) {
                return;
            }
        }
    }
    
private:
    static constexpr size_t MASK = POOL_SIZE - 1;
    static constexpr size_t INVALID_INDEX = ~size_t(0);
    
    std::array<MessageSlot, POOL_SIZE> slots_;
    std::array<std::atomic<size_t>, POOL_SIZE> free_indices_;
    CACHE_ALIGNED std::atomic<size_t> free_head_;
};

} // namespace ptpx
