// =============================================================================
// ptpx v3.0 - Thread Registry
// =============================================================================
//
// Named thread management for session polling. Threads are registered by name
// and sessions bind to them by reference.
//
// THREADING:
//   - register_thread() must be called before any sessions are created
//   - Thread lifecycle is tied to bound sessions
//   - send() is thread-safe and can be called from any thread
//   - poll() is managed by the registered thread
//
// =============================================================================

#pragma once

#include "common.hpp"
#include <string>
#include <memory>
#include <unordered_map>
#include <vector>
#include <thread>
#include <atomic>
#include <mutex>
#include <functional>
#include <optional>
#include <cassert>

#ifdef __linux__
#include <pthread.h>
#include <sched.h>
#endif

namespace ptpx {

// Forward declaration
class ISession;

// =============================================================================
// Thread Priority
// =============================================================================

enum class ThreadPriority : uint8_t {
    NORMAL = 0,     // Default scheduler
    HIGH,           // Nice -10 or SCHED_RR
    REALTIME        // SCHED_FIFO (requires root)
};

inline const char* to_string(ThreadPriority p) {
    switch (p) {
        case ThreadPriority::NORMAL: return "normal";
        case ThreadPriority::HIGH: return "high";
        case ThreadPriority::REALTIME: return "realtime";
        default: return "unknown";
    }
}

// =============================================================================
// Thread Configuration
// =============================================================================

struct ThreadConfig {
    std::string name;
    std::optional<int> cpu_affinity;
    ThreadPriority priority = ThreadPriority::NORMAL;
    size_t stack_size = 0;  // 0 = default
    
    bool is_valid() const noexcept {
        if (name.empty()) return false;
        if (name.length() > 64) return false;
        if (cpu_affinity && *cpu_affinity < 0) return false;
        return true;
    }
};

// =============================================================================
// Poll Thread - Manages polling for bound sessions
// =============================================================================

class PollThread {
public:
    explicit PollThread(const ThreadConfig& config);
    ~PollThread();
    
    PollThread(const PollThread&) = delete;
    PollThread& operator=(const PollThread&) = delete;
    
    // Thread identity
    const std::string& name() const noexcept { return config_.name; }
    const ThreadConfig& config() const noexcept { return config_; }
    
    // Session binding (called during setup, before start)
    void bind_session(ISession* session) noexcept;
    void unbind_session(ISession* session) noexcept;
    size_t session_count() const noexcept;
    
    // Lifecycle
    bool start() noexcept;
    void stop() noexcept;
    bool is_running() const noexcept { return running_.load(std::memory_order_acquire); }
    
    // Check if current thread is this poll thread
    bool is_current_thread() const noexcept;
    
    // Statistics
    uint64_t poll_count() const noexcept { return poll_count_.load(std::memory_order_relaxed); }
    uint64_t total_events() const noexcept { return total_events_.load(std::memory_order_relaxed); }
    
private:
    void run() noexcept;
    void apply_thread_config() noexcept;
    
    ThreadConfig config_;
    std::vector<ISession*> sessions_;
    mutable std::mutex sessions_mutex_;  // Only for bind/unbind during setup
    std::thread thread_;
    std::atomic<bool> running_{false};
    std::atomic<bool> stop_requested_{false};
    std::thread::id thread_id_;
    
    // Statistics
    std::atomic<uint64_t> poll_count_{0};
    std::atomic<uint64_t> total_events_{0};
};

// =============================================================================
// Thread Registry - Global registry of named threads
// =============================================================================

class ThreadRegistry {
public:
    // Singleton access
    static ThreadRegistry& instance() noexcept;
    
    // Thread registration (must be done before sessions use them)
    bool register_thread(const ThreadConfig& config) noexcept;
    bool has_thread(const std::string& name) const noexcept;
    PollThread* get_thread(const std::string& name) noexcept;
    
    // Create dedicated thread for a session (when no thread specified)
    PollThread* get_or_create_dedicated(const std::string& session_name) noexcept;
    
    // Lifecycle management
    void start_all() noexcept;
    void stop_all() noexcept;
    
    // Cleanup
    void clear() noexcept;
    
    // Info
    size_t thread_count() const noexcept;
    std::vector<std::string> thread_names() const noexcept;
    
private:
    ThreadRegistry() = default;
    ~ThreadRegistry() = default;
    
    ThreadRegistry(const ThreadRegistry&) = delete;
    ThreadRegistry& operator=(const ThreadRegistry&) = delete;
    
    mutable std::mutex mutex_;
    std::unordered_map<std::string, std::unique_ptr<PollThread>> threads_;
};

// =============================================================================
// Thread Configuration Builder
// =============================================================================

class ThreadConfigBuilder {
public:
    explicit ThreadConfigBuilder(const std::string& name) { config_.name = name; }
    
    ThreadConfigBuilder& cpu_affinity(int cpu) noexcept { 
        config_.cpu_affinity = cpu; 
        return *this; 
    }
    
    ThreadConfigBuilder& priority(ThreadPriority p) noexcept { 
        config_.priority = p; 
        return *this; 
    }
    
    ThreadConfigBuilder& stack_size(size_t size) noexcept { 
        config_.stack_size = size; 
        return *this; 
    }
    
    bool is_valid() const noexcept { return config_.is_valid(); }
    
    ThreadConfig build() const noexcept { return config_; }
    
    bool create() noexcept {
        if (!config_.is_valid()) return false;
        return ThreadRegistry::instance().register_thread(config_);
    }
    
private:
    ThreadConfig config_;
};

// =============================================================================
// Convenience function for thread registration
// =============================================================================

inline ThreadConfigBuilder register_thread(const std::string& name) {
    return ThreadConfigBuilder(name);
}

// =============================================================================
// PollThread Implementation
// =============================================================================

inline PollThread::PollThread(const ThreadConfig& config) 
    : config_(config) {
}

inline PollThread::~PollThread() {
    stop();
}

inline void PollThread::bind_session(ISession* session) noexcept {
    if (!session) return;
    std::lock_guard<std::mutex> lock(sessions_mutex_);
    // Check for duplicates
    for (auto* s : sessions_) {
        if (s == session) return;
    }
    sessions_.push_back(session);
}

inline void PollThread::unbind_session(ISession* session) noexcept {
    if (!session) return;
    std::lock_guard<std::mutex> lock(sessions_mutex_);
    sessions_.erase(
        std::remove(sessions_.begin(), sessions_.end(), session),
        sessions_.end()
    );
}

inline size_t PollThread::session_count() const noexcept {
    std::lock_guard<std::mutex> lock(sessions_mutex_);
    return sessions_.size();
}

inline bool PollThread::start() noexcept {
    if (running_.load(std::memory_order_acquire)) return true;
    
    stop_requested_.store(false, std::memory_order_release);
    
    // Note: std::thread constructor can throw, but with -fno-exceptions
    // we rely on the system not running out of resources
    thread_ = std::thread(&PollThread::run, this);
    return true;
}

inline void PollThread::stop() noexcept {
    if (!running_.load(std::memory_order_acquire)) return;
    
    stop_requested_.store(true, std::memory_order_release);
    
    if (thread_.joinable()) {
        thread_.join();
    }
}

inline bool PollThread::is_current_thread() const noexcept {
    return std::this_thread::get_id() == thread_id_;
}

// Note: PollThread::run() implementation is in session_impl.hpp
// because it needs ISession which creates circular include

inline void PollThread::apply_thread_config() noexcept {
#ifdef __linux__
    // Set thread name
    if (!config_.name.empty()) {
        std::string tname = config_.name.substr(0, 15);  // pthread limit
        pthread_setname_np(pthread_self(), tname.c_str());
    }
    
    // Set CPU affinity
    if (config_.cpu_affinity) {
        cpu_set_t cpuset;
        CPU_ZERO(&cpuset);
        CPU_SET(*config_.cpu_affinity, &cpuset);
        pthread_setaffinity_np(pthread_self(), sizeof(cpu_set_t), &cpuset);
    }
    
    // Set priority
    switch (config_.priority) {
        case ThreadPriority::REALTIME: {
            struct sched_param param;
            param.sched_priority = sched_get_priority_max(SCHED_FIFO);
            pthread_setschedparam(pthread_self(), SCHED_FIFO, &param);
            break;
        }
        case ThreadPriority::HIGH: {
            struct sched_param param;
            param.sched_priority = sched_get_priority_max(SCHED_RR);
            pthread_setschedparam(pthread_self(), SCHED_RR, &param);
            break;
        }
        case ThreadPriority::NORMAL:
        default:
            break;
    }
#endif
}

// =============================================================================
// ThreadRegistry Implementation
// =============================================================================

inline ThreadRegistry& ThreadRegistry::instance() noexcept {
    static ThreadRegistry registry;
    return registry;
}

inline bool ThreadRegistry::register_thread(const ThreadConfig& config) noexcept {
    if (!config.is_valid()) return false;
    
    std::lock_guard<std::mutex> lock(mutex_);
    
    // Check for duplicate
    if (threads_.count(config.name) > 0) return false;
    
    threads_[config.name] = std::make_unique<PollThread>(config);
    return true;
}

inline bool ThreadRegistry::has_thread(const std::string& name) const noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    return threads_.count(name) > 0;
}

inline PollThread* ThreadRegistry::get_thread(const std::string& name) noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = threads_.find(name);
    if (it == threads_.end()) return nullptr;
    return it->second.get();
}

inline PollThread* ThreadRegistry::get_or_create_dedicated(const std::string& session_name) noexcept {
    std::string thread_name = "_dedicated_" + session_name;
    
    std::lock_guard<std::mutex> lock(mutex_);
    
    auto it = threads_.find(thread_name);
    if (it != threads_.end()) {
        return it->second.get();
    }
    
    ThreadConfig config;
    config.name = thread_name;
    config.priority = ThreadPriority::NORMAL;
    
    auto thread = std::make_unique<PollThread>(config);
    auto* ptr = thread.get();
    threads_[thread_name] = std::move(thread);
    return ptr;
}

inline void ThreadRegistry::start_all() noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    for (auto& [name, thread] : threads_) {
        thread->start();
    }
}

inline void ThreadRegistry::stop_all() noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    for (auto& [name, thread] : threads_) {
        thread->stop();
    }
}

inline void ThreadRegistry::clear() noexcept {
    stop_all();
    std::lock_guard<std::mutex> lock(mutex_);
    threads_.clear();
}

inline size_t ThreadRegistry::thread_count() const noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    return threads_.size();
}

inline std::vector<std::string> ThreadRegistry::thread_names() const noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<std::string> names;
    names.reserve(threads_.size());
    for (const auto& [name, _] : threads_) {
        names.push_back(name);
    }
    return names;
}

} // namespace ptpx
