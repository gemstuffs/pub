#pragma once

#include "common.hpp"
#include <array>
#include <functional>
#include <vector>

namespace ptpx {

// =============================================================================
// Timer Wheel for Heartbeat and Timeout Management
// O(1) insert, O(1) per-tick expiration check
// =============================================================================

class TimerWheel {
public:
    using TimerCallback = std::function<void(uint32_t session_id)>;
    
    static constexpr size_t WHEEL_SIZE = 1024;  // Must be power of 2
    static constexpr size_t WHEEL_MASK = WHEEL_SIZE - 1;
    static constexpr uint64_t TICK_NS = 1'000'000;  // 1ms per tick
    
    struct TimerEntry {
        uint32_t session_id;
        uint64_t expiry_tsc;
        TimerEntry* next;
        TimerEntry* prev;
        bool active;
        
        TimerEntry() noexcept 
            : session_id(0), expiry_tsc(0), next(nullptr), prev(nullptr), active(false) {}
    };
    
    TimerWheel() noexcept : current_tick_(0), last_advance_tsc_(0) {
        for (auto& slot : wheel_) {
            slot.head = nullptr;
        }
    }
    
    // Pre-allocate timer entries for sessions
    void initialize(size_t max_sessions) {
        entries_.resize(max_sessions);
        for (size_t i = 0; i < max_sessions; ++i) {
            entries_[i].session_id = static_cast<uint32_t>(i);
        }
    }
    
    // Schedule timer for session (absolute TSC time)
    HOT_PATH void schedule(uint32_t session_id, uint64_t expiry_tsc) noexcept {
        if (UNLIKELY(session_id >= entries_.size())) return;
        
        TimerEntry& entry = entries_[session_id];
        
        // Cancel existing timer if active
        if (entry.active) {
            unlink(&entry);
        }
        
        entry.expiry_tsc = expiry_tsc;
        entry.active = true;
        
        // Calculate which slot
        uint64_t ticks_from_now = (expiry_tsc > last_advance_tsc_) 
            ? (expiry_tsc - last_advance_tsc_) / tsc_per_tick_
            : 0;
        
        size_t slot = (current_tick_ + ticks_from_now) & WHEEL_MASK;
        
        // Link into slot
        link(&wheel_[slot], &entry);
    }
    
    // Cancel timer for session
    HOT_PATH void cancel(uint32_t session_id) noexcept {
        if (UNLIKELY(session_id >= entries_.size())) return;
        
        TimerEntry& entry = entries_[session_id];
        if (entry.active) {
            unlink(&entry);
            entry.active = false;
        }
    }
    
    // Reschedule (common operation for heartbeats)
    HOT_PATH void reschedule(uint32_t session_id, uint64_t delay_ns) noexcept {
        uint64_t expiry_tsc = Timestamp::now_tsc() + ns_to_tsc(delay_ns);
        schedule(session_id, expiry_tsc);
    }
    
    // Process expired timers - call from main loop
    // Returns number of expired timers processed
    HOT_PATH size_t advance(uint64_t current_tsc, const TimerCallback& callback) noexcept {
        size_t processed = 0;
        
        // Calculate how many ticks to advance
        uint64_t elapsed_tsc = current_tsc - last_advance_tsc_;
        size_t ticks_to_advance = elapsed_tsc / tsc_per_tick_;
        
        if (ticks_to_advance == 0) return 0;
        
        // Limit to one full rotation
        ticks_to_advance = std::min(ticks_to_advance, WHEEL_SIZE);
        
        for (size_t i = 0; i < ticks_to_advance; ++i) {
            current_tick_ = (current_tick_ + 1) & WHEEL_MASK;
            
            WheelSlot& slot = wheel_[current_tick_];
            TimerEntry* entry = slot.head;
            
            while (entry != nullptr) {
                TimerEntry* next = entry->next;
                
                if (entry->expiry_tsc <= current_tsc) {
                    // Timer expired
                    entry->active = false;
                    unlink(entry);
                    
                    if (callback) {
                        callback(entry->session_id);
                    }
                    ++processed;
                }
                
                entry = next;
            }
        }
        
        last_advance_tsc_ = current_tsc;
        return processed;
    }
    
    // Calibrate TSC conversion (call at startup after Timestamp::calibrate())
    void calibrate() noexcept {
        // TSC ticks per timer wheel tick
        tsc_per_tick_ = static_cast<uint64_t>(
            static_cast<double>(TICK_NS) * (1.0 / 1e9) * get_tsc_frequency());
        last_advance_tsc_ = Timestamp::now_tsc();
    }
    
private:
    struct WheelSlot {
        TimerEntry* head;
    };
    
    FORCE_INLINE void link(WheelSlot* slot, TimerEntry* entry) noexcept {
        entry->next = slot->head;
        entry->prev = nullptr;
        if (slot->head) {
            slot->head->prev = entry;
        }
        slot->head = entry;
    }
    
    FORCE_INLINE void unlink(TimerEntry* entry) noexcept {
        if (entry->prev) {
            entry->prev->next = entry->next;
        }
        if (entry->next) {
            entry->next->prev = entry->prev;
        }
        // Note: We don't update slot.head here for simplicity
        // The advance() function handles orphaned entries
        entry->next = nullptr;
        entry->prev = nullptr;
    }
    
    FORCE_INLINE uint64_t ns_to_tsc(uint64_t ns) const noexcept {
        return static_cast<uint64_t>(static_cast<double>(ns) * (1.0 / 1e9) * get_tsc_frequency());
    }
    
    // Approximate - should be calibrated
    static double get_tsc_frequency() noexcept {
        static double freq = 3.0e9;  // Default 3 GHz
        return freq;
    }
    
    std::array<WheelSlot, WHEEL_SIZE> wheel_;
    std::vector<TimerEntry> entries_;
    
    size_t current_tick_;
    uint64_t last_advance_tsc_;
    uint64_t tsc_per_tick_;
};

// =============================================================================
// Heartbeat Manager
// =============================================================================

class HeartbeatManager {
public:
    enum class Event : uint8_t {
        NONE = 0,
        SEND_HEARTBEAT,      // Time to send heartbeat
        HEARTBEAT_TIMEOUT,   // No response received in time
        CONNECTION_TIMEOUT   // Session completely dead
    };
    
    struct SessionTimers {
        uint64_t last_send_tsc;
        uint64_t last_recv_tsc;
        uint64_t last_heartbeat_sent_tsc;
        bool awaiting_response;
        
        SessionTimers() noexcept 
            : last_send_tsc(0), last_recv_tsc(0), last_heartbeat_sent_tsc(0), 
              awaiting_response(false) {}
    };
    
    HeartbeatManager() noexcept = default;
    
    void initialize(size_t max_sessions) {
        session_timers_.resize(max_sessions);
        send_timer_.initialize(max_sessions);
        timeout_timer_.initialize(max_sessions);
        send_timer_.calibrate();
        timeout_timer_.calibrate();
    }
    
    // Called when session connects
    HOT_PATH void on_session_start(uint32_t session_id) noexcept {
        if (UNLIKELY(session_id >= session_timers_.size())) return;
        
        uint64_t now = Timestamp::now_tsc();
        SessionTimers& timers = session_timers_[session_id];
        timers.last_send_tsc = now;
        timers.last_recv_tsc = now;
        timers.last_heartbeat_sent_tsc = 0;
        timers.awaiting_response = false;
        
        // Schedule first heartbeat check
        send_timer_.reschedule(session_id, Config::HEARTBEAT_INTERVAL_NS);
    }
    
    // Called when session disconnects
    HOT_PATH void on_session_end(uint32_t session_id) noexcept {
        send_timer_.cancel(session_id);
        timeout_timer_.cancel(session_id);
    }
    
    // Called on any message sent
    HOT_PATH void on_message_sent(uint32_t session_id) noexcept {
        if (UNLIKELY(session_id >= session_timers_.size())) return;
        
        uint64_t now = Timestamp::now_tsc();
        session_timers_[session_id].last_send_tsc = now;
        
        // Reschedule heartbeat since we just sent data
        send_timer_.reschedule(session_id, Config::HEARTBEAT_INTERVAL_NS);
    }
    
    // Called on any message received
    HOT_PATH void on_message_received(uint32_t session_id) noexcept {
        if (UNLIKELY(session_id >= session_timers_.size())) return;
        
        uint64_t now = Timestamp::now_tsc();
        SessionTimers& timers = session_timers_[session_id];
        timers.last_recv_tsc = now;
        timers.awaiting_response = false;
        
        // Cancel timeout since we got data
        timeout_timer_.cancel(session_id);
    }
    
    // Called when heartbeat is sent
    HOT_PATH void on_heartbeat_sent(uint32_t session_id) noexcept {
        if (UNLIKELY(session_id >= session_timers_.size())) return;
        
        uint64_t now = Timestamp::now_tsc();
        SessionTimers& timers = session_timers_[session_id];
        timers.last_heartbeat_sent_tsc = now;
        timers.awaiting_response = true;
        
        // Schedule timeout for response
        timeout_timer_.reschedule(session_id, Config::HEARTBEAT_TIMEOUT_NS);
        
        // Schedule next heartbeat
        send_timer_.reschedule(session_id, Config::HEARTBEAT_INTERVAL_NS);
    }
    
    // Called when heartbeat response received
    HOT_PATH void on_heartbeat_received(uint32_t session_id) noexcept {
        on_message_received(session_id);  // Same behavior
    }
    
    // Process timers and return events via callbacks
    template<typename SendCallback, typename TimeoutCallback>
    HOT_PATH void process(const SendCallback& on_send, const TimeoutCallback& on_timeout) noexcept {
        uint64_t now = Timestamp::now_tsc();
        
        // Process send timers (need to send heartbeat)
        send_timer_.advance(now, [&](uint32_t session_id) {
            if (session_id < session_timers_.size()) {
                // Check if session has been idle
                SessionTimers& timers = session_timers_[session_id];
                uint64_t idle_tsc = now - std::max(timers.last_send_tsc, timers.last_recv_tsc);
                
                // Convert to ns for comparison
                uint64_t idle_ns = Timestamp::tsc_to_ns(idle_tsc);
                
                if (idle_ns >= Config::HEARTBEAT_INTERVAL_NS) {
                    on_send(session_id);
                } else {
                    // Reschedule for remaining time
                    send_timer_.reschedule(session_id, 
                        Config::HEARTBEAT_INTERVAL_NS - idle_ns);
                }
            }
        });
        
        // Process timeout timers
        timeout_timer_.advance(now, [&](uint32_t session_id) {
            if (session_id < session_timers_.size()) {
                SessionTimers& timers = session_timers_[session_id];
                if (timers.awaiting_response) {
                    on_timeout(session_id);
                }
            }
        });
    }
    
private:
    std::vector<SessionTimers> session_timers_;
    TimerWheel send_timer_;     // For scheduling heartbeat sends
    TimerWheel timeout_timer_;  // For heartbeat response timeouts
};

} // namespace ptpx
