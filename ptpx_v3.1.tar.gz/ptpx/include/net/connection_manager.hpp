#pragma once

#include "../core/common.hpp"
#include "../core/timer_wheel.hpp"
#include <functional>
#include <cstring>
#include <cmath>
#include <atomic>

namespace ptpx {

// =============================================================================
// Connection State Machine
// =============================================================================

enum class ConnState : uint8_t {
    DISCONNECTED = 0,   // Not connected, not trying
    CONNECTING,         // Connection attempt in progress
    CONNECTED,          // Fully connected and operational
    DRAINING,           // Sending remaining data before disconnect
    RECONNECTING,       // Waiting for backoff before retry
    FAILED,             // Max retries exceeded, giving up
    CLOSING             // Graceful shutdown in progress
};

inline const char* conn_state_to_string(ConnState state) {
    switch (state) {
        case ConnState::DISCONNECTED: return "DISCONNECTED";
        case ConnState::CONNECTING:   return "CONNECTING";
        case ConnState::CONNECTED:    return "CONNECTED";
        case ConnState::DRAINING:     return "DRAINING";
        case ConnState::RECONNECTING: return "RECONNECTING";
        case ConnState::FAILED:       return "FAILED";
        case ConnState::CLOSING:      return "CLOSING";
        default:                      return "UNKNOWN";
    }
}

// =============================================================================
// Disconnect Reason
// =============================================================================

enum class DisconnectReason : uint8_t {
    NONE = 0,
    PEER_CLOSED,            // Peer sent FIN
    PEER_RESET,             // Peer sent RST
    HEARTBEAT_TIMEOUT,      // No heartbeat response
    WRITE_ERROR,            // Failed to write
    READ_ERROR,             // Failed to read
    CONNECT_TIMEOUT,        // Connection attempt timed out
    CONNECT_REFUSED,        // Connection refused
    PROTOCOL_ERROR,         // Invalid message/sequence
    USER_REQUESTED,         // Application called disconnect
    NETWORK_UNREACHABLE,    // Network error
    MAX_RETRIES_EXCEEDED    // Too many reconnection attempts
};

inline const char* disconnect_reason_to_string(DisconnectReason reason) {
    switch (reason) {
        case DisconnectReason::NONE:                return "NONE";
        case DisconnectReason::PEER_CLOSED:         return "PEER_CLOSED";
        case DisconnectReason::PEER_RESET:          return "PEER_RESET";
        case DisconnectReason::HEARTBEAT_TIMEOUT:   return "HEARTBEAT_TIMEOUT";
        case DisconnectReason::WRITE_ERROR:         return "WRITE_ERROR";
        case DisconnectReason::READ_ERROR:          return "READ_ERROR";
        case DisconnectReason::CONNECT_TIMEOUT:     return "CONNECT_TIMEOUT";
        case DisconnectReason::CONNECT_REFUSED:     return "CONNECT_REFUSED";
        case DisconnectReason::PROTOCOL_ERROR:      return "PROTOCOL_ERROR";
        case DisconnectReason::USER_REQUESTED:      return "USER_REQUESTED";
        case DisconnectReason::NETWORK_UNREACHABLE: return "NETWORK_UNREACHABLE";
        case DisconnectReason::MAX_RETRIES_EXCEEDED:return "MAX_RETRIES_EXCEEDED";
        default:                                    return "UNKNOWN";
    }
}

// =============================================================================
// Reconnection Configuration
// =============================================================================

struct ReconnectConfig {
    bool enabled = true;
    
    // Exponential backoff parameters
    uint64_t initial_delay_ns = 10'000'000;      // 10ms initial delay
    uint64_t max_delay_ns = 30'000'000'000ULL;   // 30s max delay
    double backoff_multiplier = 2.0;
    double jitter_factor = 0.1;                   // ±10% jitter
    
    // Limits
    uint32_t max_attempts = 0;                    // 0 = infinite
    uint64_t connect_timeout_ns = 5'000'000'000;  // 5s connect timeout
    
    // Reset backoff after this duration of successful connection
    uint64_t backoff_reset_ns = 60'000'000'000;   // 60s
};

// =============================================================================
// Heartbeat Configuration
// =============================================================================

struct HeartbeatCfg {
    bool enabled = true;
    uint64_t interval_ns = 1'000'000'000;         // 1s send interval
    uint64_t timeout_ns = 5'000'000'000;          // 5s timeout (miss ~5 beats)
    uint64_t response_timeout_ns = 500'000'000;   // 500ms per-request timeout
};

// =============================================================================
// Connection Statistics
// =============================================================================

struct ConnStats {
    // Counters
    std::atomic<uint64_t> connects{0};
    std::atomic<uint64_t> disconnects{0};
    std::atomic<uint64_t> reconnect_attempts{0};
    std::atomic<uint64_t> failed_connects{0};
    std::atomic<uint64_t> heartbeats_sent{0};
    std::atomic<uint64_t> heartbeats_received{0};
    std::atomic<uint64_t> heartbeat_timeouts{0};
    std::atomic<uint64_t> bytes_sent{0};
    std::atomic<uint64_t> bytes_received{0};
    std::atomic<uint64_t> messages_sent{0};
    std::atomic<uint64_t> messages_received{0};
    
    // Latency tracking
    std::atomic<uint64_t> last_heartbeat_rtt_ns{0};
    std::atomic<uint64_t> min_heartbeat_rtt_ns{UINT64_MAX};
    std::atomic<uint64_t> max_heartbeat_rtt_ns{0};
    
    // Timestamps
    std::atomic<uint64_t> last_connect_tsc{0};
    std::atomic<uint64_t> last_disconnect_tsc{0};
    std::atomic<uint64_t> last_activity_tsc{0};
    std::atomic<uint64_t> total_connected_ns{0};
    
    void reset() {
        connects = 0;
        disconnects = 0;
        reconnect_attempts = 0;
        failed_connects = 0;
        heartbeats_sent = 0;
        heartbeats_received = 0;
        heartbeat_timeouts = 0;
        bytes_sent = 0;
        bytes_received = 0;
        messages_sent = 0;
        messages_received = 0;
        last_heartbeat_rtt_ns = 0;
        min_heartbeat_rtt_ns = UINT64_MAX;
        max_heartbeat_rtt_ns = 0;
        last_connect_tsc = 0;
        last_disconnect_tsc = 0;
        last_activity_tsc = 0;
        total_connected_ns = 0;
    }
};

// =============================================================================
// Exponential Backoff Calculator
// =============================================================================

class ExponentialBackoff {
public:
    explicit ExponentialBackoff(const ReconnectConfig& config)
        : config_(config)
        , attempt_(0)
        , current_delay_ns_(config.initial_delay_ns)
        , last_success_tsc_(0) {}
    
    void reset() noexcept {
        attempt_ = 0;
        current_delay_ns_ = config_.initial_delay_ns;
    }
    
    void record_success() noexcept {
        last_success_tsc_ = Timestamp::now_tsc();
    }
    
    void record_failure() noexcept {
        ++attempt_;
        
        // Check if we should reset due to long successful period
        if (last_success_tsc_ > 0) {
            uint64_t elapsed = Timestamp::tsc_to_ns(
                Timestamp::now_tsc() - last_success_tsc_);
            if (elapsed > config_.backoff_reset_ns) {
                reset();
                return;
            }
        }
        
        // Calculate next delay with exponential backoff
        current_delay_ns_ = static_cast<uint64_t>(
            current_delay_ns_ * config_.backoff_multiplier);
        
        if (current_delay_ns_ > config_.max_delay_ns) {
            current_delay_ns_ = config_.max_delay_ns;
        }
    }
    
    uint64_t get_next_delay_ns() const noexcept {
        // Add jitter to prevent thundering herd
        if (config_.jitter_factor > 0) {
            // Simple deterministic jitter based on attempt count
            double jitter = 1.0 + (config_.jitter_factor * 
                ((attempt_ % 20) / 10.0 - 1.0));
            return static_cast<uint64_t>(current_delay_ns_ * jitter);
        }
        return current_delay_ns_;
    }
    
    uint32_t attempt_count() const noexcept { return attempt_; }
    
    bool max_attempts_exceeded() const noexcept {
        return config_.max_attempts > 0 && attempt_ >= config_.max_attempts;
    }
    
private:
    ReconnectConfig config_;
    uint32_t attempt_;
    uint64_t current_delay_ns_;
    uint64_t last_success_tsc_;
};

// =============================================================================
// Heartbeat Manager
// =============================================================================

class ConnectionHeartbeat {
public:
    using SendCallback = std::function<bool(uint64_t seq)>;
    using TimeoutCallback = std::function<void()>;
    
    explicit ConnectionHeartbeat(const HeartbeatCfg& config)
        : config_(config)
        , enabled_(config.enabled)
        , pending_seq_(0)
        , pending_send_tsc_(0)
        , last_recv_tsc_(0)
        , last_send_tsc_(0) {}
    
    void set_send_callback(SendCallback cb) { send_callback_ = std::move(cb); }
    void set_timeout_callback(TimeoutCallback cb) { timeout_callback_ = std::move(cb); }
    
    void start() noexcept {
        uint64_t now = Timestamp::now_tsc();
        last_recv_tsc_ = now;
        last_send_tsc_ = now;
        pending_seq_ = 0;
        pending_send_tsc_ = 0;
    }
    
    void stop() noexcept {
        pending_seq_ = 0;
    }
    
    void enable(bool e) noexcept { enabled_ = e; }
    bool is_enabled() const noexcept { return enabled_; }
    
    // Call this on every poll iteration
    HOT_PATH void poll(ConnStats& stats) {
        if (!enabled_) return;
        
        uint64_t now = Timestamp::now_tsc();
        uint64_t now_ns = Timestamp::tsc_to_ns(now);
        
        // Check for timeout
        uint64_t since_recv_ns = Timestamp::tsc_to_ns(now - last_recv_tsc_);
        if (since_recv_ns > config_.timeout_ns) {
            stats.heartbeat_timeouts.fetch_add(1, std::memory_order_relaxed);
            if (timeout_callback_) {
                timeout_callback_();
            }
            // Reset to avoid repeated callbacks
            last_recv_tsc_ = now;
            return;
        }
        
        // Check if we have a pending heartbeat request timeout
        if (pending_seq_ > 0) {
            uint64_t pending_ns = Timestamp::tsc_to_ns(now - pending_send_tsc_);
            if (pending_ns > config_.response_timeout_ns) {
                // Individual heartbeat timed out, but not connection-level yet
                // Send another heartbeat
                pending_seq_ = 0;
            }
        }
        
        // Send heartbeat if interval elapsed
        uint64_t since_send_ns = Timestamp::tsc_to_ns(now - last_send_tsc_);
        if (since_send_ns >= config_.interval_ns && pending_seq_ == 0) {
            uint64_t seq = ++sequence_counter_;
            
            if (send_callback_ && send_callback_(seq)) {
                pending_seq_ = seq;
                pending_send_tsc_ = now;
                last_send_tsc_ = now;
                stats.heartbeats_sent.fetch_add(1, std::memory_order_relaxed);
            }
        }
    }
    
    // Call when heartbeat response received
    HOT_PATH void on_heartbeat_response(uint64_t seq, ConnStats& stats) {
        uint64_t now = Timestamp::now_tsc();
        last_recv_tsc_ = now;
        
        if (seq == pending_seq_) {
            uint64_t rtt_ns = Timestamp::tsc_to_ns(now - pending_send_tsc_);
            
            stats.heartbeats_received.fetch_add(1, std::memory_order_relaxed);
            stats.last_heartbeat_rtt_ns.store(rtt_ns, std::memory_order_relaxed);
            
            // Update min/max
            uint64_t old_min = stats.min_heartbeat_rtt_ns.load(std::memory_order_relaxed);
            while (rtt_ns < old_min && 
                   !stats.min_heartbeat_rtt_ns.compare_exchange_weak(
                       old_min, rtt_ns, std::memory_order_relaxed)) {}
            
            uint64_t old_max = stats.max_heartbeat_rtt_ns.load(std::memory_order_relaxed);
            while (rtt_ns > old_max && 
                   !stats.max_heartbeat_rtt_ns.compare_exchange_weak(
                       old_max, rtt_ns, std::memory_order_relaxed)) {}
            
            pending_seq_ = 0;
        }
    }
    
    // Call when any data received (keeps connection alive)
    HOT_PATH void on_activity() noexcept {
        last_recv_tsc_ = Timestamp::now_tsc();
    }
    
    uint64_t get_last_recv_tsc() const noexcept { return last_recv_tsc_; }
    
private:
    HeartbeatCfg config_;
    bool enabled_;
    
    uint64_t pending_seq_;
    uint64_t pending_send_tsc_;
    uint64_t last_recv_tsc_;
    uint64_t last_send_tsc_;
    
    static inline std::atomic<uint64_t> sequence_counter_{0};
    
    SendCallback send_callback_;
    TimeoutCallback timeout_callback_;
};

// =============================================================================
// Sequence Number Tracker (for resync after reconnect)
// =============================================================================

class SequenceTracker {
public:
    SequenceTracker() 
        : next_send_seq_(1)
        , next_expected_recv_seq_(1)
        , last_acked_seq_(0)
        , gap_count_(0) {}
    
    void reset() noexcept {
        next_send_seq_ = 1;
        next_expected_recv_seq_ = 1;
        last_acked_seq_ = 0;
        gap_count_ = 0;
    }
    
    // Get next sequence for outgoing message
    HOT_PATH uint32_t next_send() noexcept {
        return next_send_seq_++;
    }
    
    // Validate incoming sequence
    HOT_PATH bool validate_recv(uint32_t seq) noexcept {
        if (seq == next_expected_recv_seq_) {
            ++next_expected_recv_seq_;
            return true;
        }
        
        if (seq > next_expected_recv_seq_) {
            // Gap detected
            uint32_t gap = seq - next_expected_recv_seq_;
            gap_count_ += gap;
            next_expected_recv_seq_ = seq + 1;
            return true;  // Accept but record gap
        }
        
        // Duplicate or old message
        return false;
    }
    
    // For resync after reconnect
    void resync_send(uint32_t seq) noexcept {
        next_send_seq_ = seq;
    }
    
    void resync_recv(uint32_t seq) noexcept {
        next_expected_recv_seq_ = seq;
    }
    
    void set_last_acked(uint32_t seq) noexcept {
        last_acked_seq_ = seq;
    }
    
    uint32_t get_next_send_seq() const noexcept { return next_send_seq_; }
    uint32_t get_expected_recv_seq() const noexcept { return next_expected_recv_seq_; }
    uint32_t get_last_acked_seq() const noexcept { return last_acked_seq_; }
    uint64_t get_gap_count() const noexcept { return gap_count_; }
    
    // Returns number of unacked messages
    uint32_t unacked_count() const noexcept {
        return next_send_seq_ - last_acked_seq_ - 1;
    }
    
private:
    std::atomic<uint32_t> next_send_seq_;
    std::atomic<uint32_t> next_expected_recv_seq_;
    std::atomic<uint32_t> last_acked_seq_;
    std::atomic<uint64_t> gap_count_;
};

// =============================================================================
// Partial Message Buffer (handles disconnect mid-message)
// =============================================================================

class PartialMessageBuffer {
public:
    static constexpr size_t MAX_MESSAGE_SIZE = 64 * 1024;  // 64KB max
    
    PartialMessageBuffer() 
        : write_pos_(0)
        , expected_len_(0)
        , header_complete_(false) {}
    
    void reset() noexcept {
        write_pos_ = 0;
        expected_len_ = 0;
        header_complete_ = false;
    }
    
    // Returns true if we have a complete message
    HOT_PATH bool append(const uint8_t* data, size_t len) noexcept {
        size_t to_copy = std::min(len, MAX_MESSAGE_SIZE - write_pos_);
        std::memcpy(buffer_ + write_pos_, data, to_copy);
        write_pos_ += to_copy;
        
        // Try to parse header if we haven't yet
        if (!header_complete_ && write_pos_ >= sizeof(MessageHeader)) {
            const auto* header = reinterpret_cast<const MessageHeader*>(buffer_);
            expected_len_ = header->length;
            
            if (expected_len_ > MAX_MESSAGE_SIZE) {
                // Invalid message, reset
                reset();
                return false;
            }
            
            header_complete_ = true;
        }
        
        return header_complete_ && write_pos_ >= expected_len_;
    }
    
    const uint8_t* data() const noexcept { return buffer_; }
    size_t size() const noexcept { return write_pos_; }
    size_t expected_size() const noexcept { return expected_len_; }
    bool has_partial_header() const noexcept { return write_pos_ > 0 && !header_complete_; }
    bool has_partial_message() const noexcept { return header_complete_ && write_pos_ < expected_len_; }
    
    // Extract complete message and shift remaining data
    size_t consume_message(uint8_t* out, size_t out_len) noexcept {
        if (!header_complete_ || write_pos_ < expected_len_) {
            return 0;
        }
        
        size_t msg_len = expected_len_;
        if (out && out_len >= msg_len) {
            std::memcpy(out, buffer_, msg_len);
        }
        
        // Shift remaining data
        if (write_pos_ > msg_len) {
            std::memmove(buffer_, buffer_ + msg_len, write_pos_ - msg_len);
        }
        write_pos_ -= msg_len;
        expected_len_ = 0;
        header_complete_ = false;
        
        return msg_len;
    }
    
private:
    alignas(64) uint8_t buffer_[MAX_MESSAGE_SIZE];
    size_t write_pos_;
    size_t expected_len_;
    bool header_complete_;
};

// =============================================================================
// Connection Manager (orchestrates all the above)
// =============================================================================

template<typename Derived>
class ConnectionManager {
public:
    using StateChangeCallback = std::function<void(ConnState old_state, ConnState new_state, DisconnectReason reason)>;
    
    ConnectionManager(const ReconnectConfig& reconnect_cfg,
                      const HeartbeatCfg& heartbeat_cfg)
        : state_(ConnState::DISCONNECTED)
        , disconnect_reason_(DisconnectReason::NONE)
        , backoff_(reconnect_cfg)
        , heartbeat_(heartbeat_cfg)
        , reconnect_config_(reconnect_cfg)
        , reconnect_scheduled_tsc_(0)
        , connect_start_tsc_(0) {
        
        heartbeat_.set_timeout_callback([this]() {
            on_heartbeat_timeout();
        });
    }
    
    void set_state_change_callback(StateChangeCallback cb) {
        state_change_callback_ = std::move(cb);
    }
    
    // State accessors
    ConnState state() const noexcept { return state_; }
    DisconnectReason last_disconnect_reason() const noexcept { return disconnect_reason_; }
    const ConnStats& stats() const noexcept { return stats_; }
    ConnStats& stats() noexcept { return stats_; }
    SequenceTracker& sequence() noexcept { return sequence_; }
    ConnectionHeartbeat& heartbeat() noexcept { return heartbeat_; }
    
    // Initiate connection
    bool connect() {
        if (state_ == ConnState::CONNECTED || state_ == ConnState::CONNECTING) {
            return true;
        }
        
        transition_to(ConnState::CONNECTING, DisconnectReason::NONE);
        connect_start_tsc_ = Timestamp::now_tsc();
        
        return static_cast<Derived*>(this)->do_connect();
    }
    
    // Graceful disconnect
    void disconnect(DisconnectReason reason = DisconnectReason::USER_REQUESTED) {
        if (state_ == ConnState::DISCONNECTED || state_ == ConnState::FAILED) {
            return;
        }
        
        transition_to(ConnState::CLOSING, reason);
        static_cast<Derived*>(this)->do_disconnect();
        
        // Update stats
        heartbeat_.stop();
        stats_.disconnects.fetch_add(1, std::memory_order_relaxed);
        stats_.last_disconnect_tsc.store(Timestamp::now_tsc(), std::memory_order_relaxed);
        
        transition_to(ConnState::DISCONNECTED, reason);
    }
    
    // Force immediate disconnect (no draining)
    void force_disconnect(DisconnectReason reason) {
        static_cast<Derived*>(this)->do_force_disconnect();
        transition_to(ConnState::DISCONNECTED, reason);
    }
    
    // Poll - call in event loop
    HOT_PATH void poll() {
        switch (state_) {
            case ConnState::CONNECTING:
                poll_connecting();
                break;
                
            case ConnState::CONNECTED:
                heartbeat_.poll(stats_);
                static_cast<Derived*>(this)->do_poll();
                break;
                
            case ConnState::RECONNECTING:
                poll_reconnecting();
                break;
                
            case ConnState::DRAINING:
                static_cast<Derived*>(this)->do_poll_draining();
                break;
                
            default:
                break;
        }
    }
    
protected:
    // Called by derived class when connection succeeds
    void on_connected() {
        backoff_.record_success();
        stats_.connects.fetch_add(1, std::memory_order_relaxed);
        stats_.last_connect_tsc.store(Timestamp::now_tsc(), std::memory_order_relaxed);
        
        heartbeat_.start();
        transition_to(ConnState::CONNECTED, DisconnectReason::NONE);
    }
    
    // Called by derived class on any disconnect
    void on_disconnected(DisconnectReason reason) {
        heartbeat_.stop();
        
        uint64_t now = Timestamp::now_tsc();
        uint64_t connected_since = stats_.last_connect_tsc.load(std::memory_order_relaxed);
        if (connected_since > 0) {
            uint64_t duration = Timestamp::tsc_to_ns(now - connected_since);
            stats_.total_connected_ns.fetch_add(duration, std::memory_order_relaxed);
        }
        
        stats_.disconnects.fetch_add(1, std::memory_order_relaxed);
        stats_.last_disconnect_tsc.store(now, std::memory_order_relaxed);
        
        // Attempt reconnect if enabled and not user-requested
        if (reconnect_config_.enabled && 
            reason != DisconnectReason::USER_REQUESTED &&
            !backoff_.max_attempts_exceeded()) {
            
            schedule_reconnect();
        } else if (backoff_.max_attempts_exceeded()) {
            transition_to(ConnState::FAILED, DisconnectReason::MAX_RETRIES_EXCEEDED);
        } else {
            transition_to(ConnState::DISCONNECTED, reason);
        }
    }
    
    // Called by derived class on data received
    HOT_PATH void on_data_received(size_t bytes) {
        stats_.bytes_received.fetch_add(bytes, std::memory_order_relaxed);
        stats_.last_activity_tsc.store(Timestamp::now_tsc(), std::memory_order_relaxed);
        heartbeat_.on_activity();
    }
    
    // Called by derived class on message received
    HOT_PATH void on_message_received() {
        stats_.messages_received.fetch_add(1, std::memory_order_relaxed);
    }
    
    // Called by derived class on data sent
    HOT_PATH void on_data_sent(size_t bytes) {
        stats_.bytes_sent.fetch_add(bytes, std::memory_order_relaxed);
    }
    
    // Called by derived class on message sent
    HOT_PATH void on_message_sent() {
        stats_.messages_sent.fetch_add(1, std::memory_order_relaxed);
    }
    
    PartialMessageBuffer& recv_buffer() noexcept { return recv_buffer_; }
    
private:
    void transition_to(ConnState new_state, DisconnectReason reason) {
        ConnState old_state = state_;
        if (old_state == new_state) return;
        
        state_ = new_state;
        disconnect_reason_ = reason;
        
        if (state_change_callback_) {
            state_change_callback_(old_state, new_state, reason);
        }
    }
    
    void poll_connecting() {
        // Check for connect timeout
        uint64_t elapsed = Timestamp::tsc_to_ns(
            Timestamp::now_tsc() - connect_start_tsc_);
        
        if (elapsed > reconnect_config_.connect_timeout_ns) {
            stats_.failed_connects.fetch_add(1, std::memory_order_relaxed);
            backoff_.record_failure();
            
            static_cast<Derived*>(this)->do_force_disconnect();
            
            if (reconnect_config_.enabled && !backoff_.max_attempts_exceeded()) {
                schedule_reconnect();
            } else if (backoff_.max_attempts_exceeded()) {
                transition_to(ConnState::FAILED, DisconnectReason::MAX_RETRIES_EXCEEDED);
            } else {
                transition_to(ConnState::FAILED, DisconnectReason::CONNECT_TIMEOUT);
            }
        } else {
            // Check if connection completed
            if (static_cast<Derived*>(this)->do_poll_connecting()) {
                on_connected();
            }
        }
    }
    
    void poll_reconnecting() {
        uint64_t now = Timestamp::now_tsc();
        uint64_t elapsed = Timestamp::tsc_to_ns(now - reconnect_scheduled_tsc_);
        uint64_t delay = backoff_.get_next_delay_ns();
        
        if (elapsed >= delay) {
            stats_.reconnect_attempts.fetch_add(1, std::memory_order_relaxed);
            connect();
        }
    }
    
    void schedule_reconnect() {
        reconnect_scheduled_tsc_ = Timestamp::now_tsc();
        transition_to(ConnState::RECONNECTING, disconnect_reason_);
    }
    
    void on_heartbeat_timeout() {
        if (state_ == ConnState::CONNECTED) {
            force_disconnect(DisconnectReason::HEARTBEAT_TIMEOUT);
            
            if (reconnect_config_.enabled) {
                backoff_.record_failure();
                schedule_reconnect();
            }
        }
    }
    
    ConnState state_;
    DisconnectReason disconnect_reason_;
    
    ExponentialBackoff backoff_;
    ConnectionHeartbeat heartbeat_;
    SequenceTracker sequence_;
    PartialMessageBuffer recv_buffer_;
    ConnStats stats_;
    
    ReconnectConfig reconnect_config_;
    uint64_t reconnect_scheduled_tsc_;
    uint64_t connect_start_tsc_;
    
    StateChangeCallback state_change_callback_;
};

} // namespace ptpx
