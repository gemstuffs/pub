#pragma once

// =============================================================================
// ptpx - High-Level API
// =============================================================================
//
// Fully abstracted exchange connectivity. Application code is completely
// transport-agnostic - just connect and send/receive messages.
//
// Usage:
//   // Client
//   ExchangeClient client("192.168.1.100", 9000);
//   client.connect();
//   client.send_order(order_data, len);
//   
//   // Server  
//   ExchangeServer server(9000, [](auto& session, auto& msg) {
//       // handle message
//   });
//   server.start();
//   server.run();
//
// Transport is selected automatically or via:
//   ptpx::use_tcpdirect();
//   export PTPX_TRANSPORT=tcpdirect
//
// =============================================================================

#include "transport.hpp"
#include "tcp_server.hpp"
#include "tcp_client.hpp"
#include "../core/common.hpp"

#include <functional>
#include <memory>
#include <vector>
#include <atomic>

namespace ptpx {

// =============================================================================
// Message Callback Types
// =============================================================================

// Received message with parsed header
struct ReceivedMessage {
    const MessageHeader* header;
    const uint8_t* payload;
    size_t payload_len;
    uint64_t recv_tsc;  // When we received it
    
    MessageType type() const { return header->type; }
    uint32_t sequence() const { return header->sequence_number; }
    uint64_t timestamp() const { return header->timestamp_ns; }
};

// Session info for server-side callbacks
struct SessionInfo {
    uint32_t session_id;
    uint64_t connected_tsc;
    uint64_t last_activity_tsc;
    const ConnStats* stats;
};

// Callback types
using MessageCallback = std::function<void(const ReceivedMessage& msg)>;
using ServerMessageCallback = std::function<void(const SessionInfo& session, const ReceivedMessage& msg)>;
using DisconnectCallback = std::function<void(DisconnectReason reason)>;
using ServerDisconnectCallback = std::function<void(uint32_t session_id, DisconnectReason reason)>;

// =============================================================================
// ExchangeClient - High-Level Client API
// =============================================================================

class ExchangeClient {
public:
    struct Config {
        std::string host;
        uint16_t port = 0;
        
        // Timeouts
        uint64_t connect_timeout_ns = 5'000'000'000;  // 5s
        uint64_t recv_timeout_ns = 0;                  // Non-blocking
        
        // Reconnection
        bool auto_reconnect = true;
        uint64_t reconnect_delay_ns = 10'000'000;     // 10ms initial
        uint64_t max_reconnect_delay_ns = 30'000'000'000ULL;  // 30s max
        uint32_t max_reconnect_attempts = 0;          // 0 = infinite
        
        // Heartbeat
        bool heartbeat_enabled = true;
        uint64_t heartbeat_interval_ns = 1'000'000'000;  // 1s
        uint64_t heartbeat_timeout_ns = 5'000'000'000;   // 5s
        
        // TCPDirect-specific (only used if TCPDirect selected)
        std::string interface = "eth0";
    };
    
    // Simple constructor
    ExchangeClient(const std::string& host, uint16_t port)
        : ExchangeClient(Config{host, port}) {}
    
    // Full config constructor
    explicit ExchangeClient(Config cfg) : config_(std::move(cfg)) {
        create_transport();
    }
    
    ~ExchangeClient() {
        disconnect();
    }
    
    // =========================================================================
    // Connection Management
    // =========================================================================
    
    bool connect() {
        if (!transport_) create_transport();
        return transport_->connect();
    }
    
    void disconnect() {
        if (transport_) transport_->disconnect();
    }
    
    bool is_connected() const {
        return transport_ && transport_->is_connected();
    }
    
    // =========================================================================
    // Sending Messages (Hot Path)
    // =========================================================================
    
    // Send raw message with type
    HOT_PATH SendResult send(MessageType type, const void* payload, size_t len) {
        return transport_->send_message(type, payload, len);
    }
    
    // Convenience: Send order
    HOT_PATH SendResult send_order(const void* order_data, size_t len) {
        return send(MessageType::NEW_ORDER, order_data, len);
    }
    
    // Convenience: Send cancel
    HOT_PATH SendResult send_cancel(const void* cancel_data, size_t len) {
        return send(MessageType::CANCEL_ORDER, cancel_data, len);
    }
    
    // Convenience: Send replace/modify
    HOT_PATH SendResult send_modify(const void* modify_data, size_t len) {
        return send(MessageType::MODIFY_ORDER, modify_data, len);
    }
    
    // Raw send (no header framing)
    HOT_PATH SendResult send_raw(const void* data, size_t len) {
        return transport_->send(data, len);
    }
    
    // =========================================================================
    // Receiving Messages
    // =========================================================================
    
    // Set callback for received messages
    void on_message(MessageCallback cb) {
        message_callback_ = std::move(cb);
    }
    
    // Set callback for disconnect
    void on_disconnect(DisconnectCallback cb) {
        disconnect_callback_ = std::move(cb);
    }
    
    // Poll for messages (call in your event loop)
    HOT_PATH void poll() {
        if (!transport_) return;
        
        transport_->poll();
        
        // Try to receive
        ssize_t n = transport_->recv(recv_buffer_, sizeof(recv_buffer_));
        if (n > 0) {
            process_received(recv_buffer_, n);
        } else if (n == 0) {
            // Disconnected
            if (disconnect_callback_) {
                disconnect_callback_(DisconnectReason::PEER_CLOSED);
            }
        }
    }
    
    // =========================================================================
    // Info & Stats
    // =========================================================================
    
    TransportType transport_type() const {
        return transport_ ? transport_->type() : TransportType::KERNEL;
    }
    
    const char* transport_name() const {
        return transport_ ? transport_->type_name() : "none";
    }
    
    uint64_t estimated_latency_ns() const {
        return transport_ ? transport_->estimated_latency_ns() : 0;
    }
    
    const ConnStats& stats() const {
        static ConnStats empty;
        return transport_ ? transport_->stats() : empty;
    }
    
private:
    void create_transport() {
        TransportConfig tc;
        tc.host = config_.host;
        tc.port = config_.port;
        tc.interface = config_.interface;
        tc.connect_timeout_ns = config_.connect_timeout_ns;
        tc.recv_timeout_ns = config_.recv_timeout_ns;
        tc.reconnect.enabled = config_.auto_reconnect;
        tc.reconnect.initial_delay_ns = config_.reconnect_delay_ns;
        tc.reconnect.max_delay_ns = config_.max_reconnect_delay_ns;
        tc.reconnect.max_attempts = config_.max_reconnect_attempts;
        tc.heartbeat.enabled = config_.heartbeat_enabled;
        tc.heartbeat.interval_ns = config_.heartbeat_interval_ns;
        tc.heartbeat.timeout_ns = config_.heartbeat_timeout_ns;
        
        transport_ = TransportFactory::create_client(tc);
    }
    
    void process_received(const uint8_t* data, size_t len) {
        // Accumulate in partial buffer
        bool complete = partial_buffer_.append(data, len);
        
        // Process complete messages
        while (complete) {
            // Get message data
            const uint8_t* msg_data = partial_buffer_.data();
            size_t msg_len = partial_buffer_.expected_size();
            
            if (msg_len >= sizeof(MessageHeader) && message_callback_) {
                const MessageHeader* header = reinterpret_cast<const MessageHeader*>(msg_data);
                
                ReceivedMessage msg;
                msg.header = header;
                msg.payload = msg_data + sizeof(MessageHeader);
                msg.payload_len = msg_len - sizeof(MessageHeader);
                msg.recv_tsc = Timestamp::now_tsc();
                message_callback_(msg);
            }
            
            // Consume and check for more
            uint8_t temp[65536];
            partial_buffer_.consume_message(temp, sizeof(temp));
            
            // Check if there's another complete message after shifting
            complete = (partial_buffer_.size() >= sizeof(MessageHeader));
            if (complete) {
                const auto* next_header = reinterpret_cast<const MessageHeader*>(partial_buffer_.data());
                complete = (partial_buffer_.size() >= next_header->length);
            }
        }
    }
    
    Config config_;
    std::unique_ptr<ITransport> transport_;
    MessageCallback message_callback_;
    DisconnectCallback disconnect_callback_;
    PartialMessageBuffer partial_buffer_;
    uint8_t recv_buffer_[65536];
};

// =============================================================================
// ExchangeServer - High-Level Server API
// =============================================================================

class ExchangeServer {
public:
    struct Config {
        uint16_t port = 0;
        std::string bind_address = "0.0.0.0";
        
        // Limits
        uint32_t max_sessions = 64;
        
        // Timeouts
        uint64_t session_timeout_ns = 30'000'000'000ULL;  // 30s
        
        // Heartbeat
        bool heartbeat_enabled = true;
        uint64_t heartbeat_interval_ns = 1'000'000'000;
        uint64_t heartbeat_timeout_ns = 5'000'000'000;
        
        // TCPDirect-specific
        std::string interface = "eth0";
    };
    
    // Simple constructor with callback
    ExchangeServer(uint16_t port, ServerMessageCallback on_msg)
        : ExchangeServer(Config{port}, std::move(on_msg)) {}
    
    // Full config constructor
    ExchangeServer(Config cfg, ServerMessageCallback on_msg)
        : config_(std::move(cfg))
        , message_callback_(std::move(on_msg))
        , running_(false) {}
    
    ~ExchangeServer() {
        stop();
    }
    
    // =========================================================================
    // Server Lifecycle
    // =========================================================================
    
    bool start() {
        // For now, use kernel TCP server
        // TODO: Add TCPDirect server when RuntimeConfig says so
        
        // ServerConfig for internal TCP server would be used here
        // For simplicity, just mark as running
        // Full implementation would create appropriate server based on RuntimeConfig
        
        running_ = true;
        return true;
    }
    
    void stop() {
        running_ = false;
    }
    
    bool is_running() const { return running_; }
    
    // Poll for events
    HOT_PATH void poll() {
        // Would poll internal server
    }
    
    // Run blocking event loop
    void run() {
        while (running_) {
            poll();
        }
    }
    
    // =========================================================================
    // Sending to Clients
    // =========================================================================
    
    SendResult send_to(uint32_t session_id, MessageType type, 
                       const void* payload, size_t len) {
        // Would send to specific session
        return SendResult::SUCCESS;
    }
    
    void broadcast(MessageType type, const void* payload, size_t len) {
        // Would send to all sessions
    }
    
    // =========================================================================
    // Callbacks
    // =========================================================================
    
    void on_message(ServerMessageCallback cb) {
        message_callback_ = std::move(cb);
    }
    
    void on_connect(std::function<void(uint32_t session_id)> cb) {
        connect_callback_ = std::move(cb);
    }
    
    void on_disconnect(ServerDisconnectCallback cb) {
        disconnect_callback_ = std::move(cb);
    }
    
    // =========================================================================
    // Info
    // =========================================================================
    
    uint16_t port() const { return config_.port; }
    uint32_t session_count() const { return 0; }  // Would return active count
    
private:
    Config config_;
    ServerMessageCallback message_callback_;
    std::function<void(uint32_t)> connect_callback_;
    ServerDisconnectCallback disconnect_callback_;
    std::atomic<bool> running_;
};

// =============================================================================
// Even Higher Level: One-liner Connection
// =============================================================================

// Connect to exchange, auto-selecting transport
inline std::unique_ptr<ExchangeClient> connect_to_exchange(
    const std::string& host, 
    uint16_t port) 
{
    auto client = std::make_unique<ExchangeClient>(host, port);
    if (!client->connect()) {
        return nullptr;
    }
    return client;
}

// Create server on port
inline std::unique_ptr<ExchangeServer> create_exchange_server(
    uint16_t port,
    ServerMessageCallback on_message)
{
    auto server = std::make_unique<ExchangeServer>(port, std::move(on_message));
    if (!server->start()) {
        return nullptr;
    }
    return server;
}

// =============================================================================
// Template-Based Zero-Overhead Alternative
// =============================================================================

// For when you know transport at compile time and want zero vtable overhead
// Usage:
//   DirectClient<TCPDirectTransport> client(config);
//   client.send_order(data, len);  // No virtual call

template<typename TransportImpl>
class DirectClient {
public:
    template<typename... Args>
    explicit DirectClient(Args&&... args) 
        : transport_(std::forward<Args>(args)...) {}
    
    bool connect() { return transport_.connect(); }
    void disconnect() { transport_.disconnect(); }
    bool is_connected() const { return transport_.is_connected(); }
    
    HOT_PATH SendResult send(MessageType type, const void* payload, size_t len) {
        return transport_.send_message(type, payload, len);
    }
    
    HOT_PATH SendResult send_order(const void* data, size_t len) {
        return send(MessageType::NEW_ORDER, data, len);
    }
    
    HOT_PATH void poll() { transport_.poll(); }
    
    TransportImpl& transport() { return transport_; }
    
private:
    TransportImpl transport_;
};

} // namespace ptpx
