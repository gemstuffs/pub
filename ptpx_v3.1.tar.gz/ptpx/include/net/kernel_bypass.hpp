#pragma once

#include "../core/common.hpp"

#include <dlfcn.h>
#include <cstring>
#include <cstdio>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>

// Hardware timestamping flags
#ifndef SOF_TIMESTAMPING_RX_HARDWARE
#define SOF_TIMESTAMPING_RX_HARDWARE (1 << 0)
#endif
#ifndef SOF_TIMESTAMPING_TX_HARDWARE
#define SOF_TIMESTAMPING_TX_HARDWARE (1 << 1)
#endif
#ifndef SOF_TIMESTAMPING_RAW_HARDWARE
#define SOF_TIMESTAMPING_RAW_HARDWARE (1 << 3)
#endif
#ifndef SO_TIMESTAMPING
#define SO_TIMESTAMPING 37
#endif

namespace ptpx {

// =============================================================================
// Kernel Bypass Mode Selection (TCP Order Entry/Execution)
// =============================================================================

enum class BypassMode : uint8_t {
    NONE = 0,           // Standard kernel sockets (epoll)
    ONLOAD,             // Solarflare OpenOnload (user-space TCP via LD_PRELOAD)
    TCPDIRECT,          // Solarflare TCPDirect (ZF API) - FASTEST
};

// =============================================================================
// Bypass Capability Information
// =============================================================================

struct BypassInfo {
    BypassMode mode;
    const char* library_name;
    const char* version;
    bool zero_copy_supported;
    bool timestamping_supported;
    bool tcpdirect_available;
    uint64_t min_latency_ns;
    
    static BypassInfo detect() noexcept;
    static bool is_solarflare_nic(const char* interface = "eth0") noexcept;
};

// =============================================================================
// Runtime Detection
// =============================================================================

inline bool BypassInfo::is_solarflare_nic(const char* interface) noexcept {
    char path[256];
    snprintf(path, sizeof(path), "/sys/class/net/%s/device/driver", interface);
    
    char driver_link[256];
    ssize_t len = readlink(path, driver_link, sizeof(driver_link) - 1);
    if (len > 0) {
        driver_link[len] = '\0';
        if (strstr(driver_link, "sfc") || strstr(driver_link, "xilinx")) {
            return true;
        }
    }
    return false;
}

inline BypassInfo BypassInfo::detect() noexcept {
    BypassInfo info{};
    info.mode = BypassMode::NONE;
    info.library_name = "kernel";
    info.version = "";
    info.zero_copy_supported = false;
    info.timestamping_supported = false;
    info.tcpdirect_available = false;
    info.min_latency_ns = 5000;  // ~5μs for kernel sockets
    
    // Check for TCPDirect (highest priority - fastest TCP)
    void* zf = dlopen("libzf.so", RTLD_LAZY | RTLD_NOLOAD);
    if (zf) {
        info.mode = BypassMode::TCPDIRECT;
        info.library_name = "Solarflare TCPDirect";
        info.zero_copy_supported = true;
        info.timestamping_supported = true;
        info.tcpdirect_available = true;
        info.min_latency_ns = 200;
        dlclose(zf);
        return info;
    }
    
    // Check for OpenOnload
    void* onload = dlopen("libonload.so", RTLD_LAZY | RTLD_NOLOAD);
    if (onload) {
        info.mode = BypassMode::ONLOAD;
        info.library_name = "OpenOnload";
        info.zero_copy_supported = true;
        info.timestamping_supported = true;
        info.tcpdirect_available = false;
        info.min_latency_ns = 500;
        
        auto version_fn = reinterpret_cast<const char*(*)()>(
            dlsym(onload, "onload_version"));
        if (version_fn) {
            info.version = version_fn();
        }
        
        dlclose(onload);
        return info;
    }
    
    // Check LD_PRELOAD
    const char* preload = getenv("LD_PRELOAD");
    if (preload && strstr(preload, "libonload.so")) {
        info.mode = BypassMode::ONLOAD;
        info.library_name = "OpenOnload (LD_PRELOAD)";
        info.min_latency_ns = 500;
    }
    
    return info;
}

// =============================================================================
// OpenOnload Extensions
// =============================================================================

#ifdef HAS_ONLOAD
#include <onload/extensions.h>

class OnloadExtensions {
public:
    static bool enable_zero_copy(int fd) noexcept {
        return onload_set_stackname(ONLOAD_ALL_THREADS, ONLOAD_SCOPE_PROCESS, 
                                    "lowlat") == 0;
    }
    
    static uint64_t get_hw_timestamp_ns(int fd, const struct msghdr* msg) noexcept {
        for (struct cmsghdr* cmsg = CMSG_FIRSTHDR(msg); 
             cmsg != nullptr; 
             cmsg = CMSG_NXTHDR(const_cast<msghdr*>(msg), cmsg)) {
            if (cmsg->cmsg_level == SOL_SOCKET && 
                cmsg->cmsg_type == SO_TIMESTAMPING) {
                struct timespec* ts = reinterpret_cast<struct timespec*>(CMSG_DATA(cmsg));
                return ts[2].tv_sec * 1'000'000'000ULL + ts[2].tv_nsec;
            }
        }
        return 0;
    }
    
    static bool set_stack_affinity(int cpu) noexcept {
        char stack_name[32];
        snprintf(stack_name, sizeof(stack_name), "stack_cpu%d", cpu);
        return onload_set_stackname(ONLOAD_THIS_THREAD, ONLOAD_SCOPE_THREAD,
                                    stack_name) == 0;
    }
    
    static void configure_spinning(int fd) noexcept {
        // Spinning configured via EF_POLL_USEC, EF_SPIN_USEC env vars
    }
    
    static bool enable_delegated_sends(int fd) noexcept {
        return true;
    }
};

#else

class OnloadExtensions {
public:
    static bool enable_zero_copy(int) noexcept { return false; }
    static uint64_t get_hw_timestamp_ns(int, const struct msghdr*) noexcept { return 0; }
    static bool set_stack_affinity(int) noexcept { return false; }
    static void configure_spinning(int) noexcept {}
    static bool enable_delegated_sends(int) noexcept { return false; }
};

#endif

// =============================================================================
// Bypass Socket Wrapper
// =============================================================================

class BypassSocket {
public:
    BypassSocket() noexcept : fd_(-1), mode_(BypassMode::NONE) {
        static BypassInfo info = BypassInfo::detect();
        mode_ = info.mode;
    }
    
    explicit BypassSocket(int fd) noexcept : fd_(fd), mode_(BypassMode::NONE) {
        static BypassInfo info = BypassInfo::detect();
        mode_ = info.mode;
        if (fd_ >= 0) configure_for_low_latency();
    }
    
    ~BypassSocket() {
        if (fd_ >= 0) ::close(fd_);
    }
    
    // Move only
    BypassSocket(BypassSocket&& other) noexcept 
        : fd_(other.fd_), mode_(other.mode_) {
        other.fd_ = -1;
    }
    
    BypassSocket& operator=(BypassSocket&& other) noexcept {
        if (this != &other) {
            if (fd_ >= 0) ::close(fd_);
            fd_ = other.fd_;
            mode_ = other.mode_;
            other.fd_ = -1;
        }
        return *this;
    }
    
    bool connect(const char* host, uint16_t port) noexcept {
        fd_ = ::socket(AF_INET, SOCK_STREAM | SOCK_NONBLOCK, 0);
        if (fd_ < 0) return false;
        
        configure_for_low_latency();
        
        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(port);
        inet_pton(AF_INET, host, &addr.sin_addr);
        
        int ret = ::connect(fd_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr));
        return (ret == 0 || errno == EINPROGRESS);
    }
    
    HOT_PATH ssize_t recv(void* buf, size_t len, int flags = 0) noexcept {
        return ::recv(fd_, buf, len, flags | MSG_DONTWAIT);
    }
    
    HOT_PATH ssize_t send(const void* buf, size_t len, int flags = 0) noexcept {
        return ::send(fd_, buf, len, flags | MSG_DONTWAIT | MSG_NOSIGNAL);
    }
    
    uint64_t get_hw_timestamp_ns(const struct msghdr* msg = nullptr) noexcept {
        if (mode_ == BypassMode::ONLOAD && msg) {
            return OnloadExtensions::get_hw_timestamp_ns(fd_, msg);
        }
        return 0;
    }
    
    int fd() const noexcept { return fd_; }
    BypassMode mode() const noexcept { return mode_; }
    bool is_bypassed() const noexcept { return mode_ != BypassMode::NONE; }
    
private:
    void configure_for_low_latency() noexcept {
        if (fd_ < 0) return;
        
        int one = 1;
        setsockopt(fd_, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
        setsockopt(fd_, IPPROTO_TCP, TCP_QUICKACK, &one, sizeof(one));
        
        int bufsize = 1024 * 1024;
        setsockopt(fd_, SOL_SOCKET, SO_SNDBUF, &bufsize, sizeof(bufsize));
        setsockopt(fd_, SOL_SOCKET, SO_RCVBUF, &bufsize, sizeof(bufsize));
        
        int busy = 50;
        setsockopt(fd_, SOL_SOCKET, SO_BUSY_POLL, &busy, sizeof(busy));
        
        int ts_flags = SOF_TIMESTAMPING_RX_HARDWARE | 
                       SOF_TIMESTAMPING_TX_HARDWARE |
                       SOF_TIMESTAMPING_RAW_HARDWARE;
        setsockopt(fd_, SOL_SOCKET, SO_TIMESTAMPING, &ts_flags, sizeof(ts_flags));
        
        if (mode_ == BypassMode::ONLOAD) {
            OnloadExtensions::configure_spinning(fd_);
            OnloadExtensions::enable_delegated_sends(fd_);
        }
    }
    
    int fd_;
    BypassMode mode_;
};

// =============================================================================
// Launch Script Generator
// =============================================================================

inline void print_launch_commands(BypassMode mode, const char* binary, int cpu) {
    printf("=== Launch Commands for Low Latency ===\n\n");
    
    printf("# CPU isolation (add to /etc/default/grub):\n");
    printf("GRUB_CMDLINE_LINUX=\"isolcpus=%d nohz_full=%d rcu_nocbs=%d\"\n\n", 
           cpu, cpu, cpu);
    
    switch (mode) {
        case BypassMode::TCPDIRECT:
            printf("# TCPDirect (requires libzf.so + Solarflare NIC):\n");
            printf("taskset -c %d %s\n\n", cpu, binary);
            printf("# TCPDirect uses ZF API directly - no LD_PRELOAD needed\n");
            printf("# Ensure OpenOnload is installed with TCPDirect enabled\n");
            break;
            
        case BypassMode::ONLOAD:
            printf("# OpenOnload launch:\n");
            printf("onload --profile=latency taskset -c %d %s\n\n", cpu, binary);
            printf("# Environment variables:\n");
            printf("export EF_POLL_USEC=-1        # Busy poll forever\n");
            printf("export EF_SPIN_USEC=-1        # Spin forever\n");
            printf("export EF_INT_DRIVEN=0        # No interrupts\n");
            printf("export EF_TCP_RECV_SPIN=1     # Spin on receive\n");
            printf("export EF_PKT_WAIT_SPIN=1     # Spin waiting for packets\n");
            break;
            
        default:
            printf("# Standard kernel socket launch:\n");
            printf("taskset -c %d chrt -f 99 %s\n\n", cpu, binary);
            printf("# Kernel parameters (sysctl.conf):\n");
            printf("net.core.busy_poll=50\n");
            printf("net.core.busy_read=50\n");
            printf("net.ipv4.tcp_low_latency=1\n");
            break;
    }
    
    printf("\n# Real-time priority:\n");
    printf("chrt -f 99 <command>\n");
}

} // namespace ptpx
