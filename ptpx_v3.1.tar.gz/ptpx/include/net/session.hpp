// =============================================================================
// ptpx v3.0 - Session Layer (Production-Ready)
// =============================================================================
//
// THREADING MODEL:
//   - Sessions bind to named poll threads (or get a dedicated thread)
//   - poll() is called by the poll thread - DO NOT call directly
//   - send() is THREAD-SAFE - can be called from ANY thread
//   - state() / stats() can be read from ANY thread (atomic)
//   - Callbacks are invoked synchronously from poll thread - DO NOT BLOCK
//
// THREAD CONFIGURATION:
//   - register_thread("name").cpu_affinity(N).priority(HIGH).create()
//   - session("name").thread("thread_name")... to use named thread
//   - session("name")... without .thread() gets dedicated thread
//
// LATENCY CONSIDERATIONS:
//   - Spinlock in send() for multi-thread serialization
//   - No heap allocation in hot path (send/poll)
//   - Callbacks must be fast - no I/O, no locks, no allocations
//   - Stats use relaxed memory ordering for performance
//
// =============================================================================

#pragma once

#include "../core/common.hpp"
#include "../core/thread_registry.hpp"
#include "connection_manager.hpp"
#include <string>
#include <memory>
#include <functional>
#include <optional>
#include <atomic>
#include <unordered_map>
#include <vector>
#include <cassert>

namespace ptpx {

// Forward declarations
class ITransport;
class ISession;
class SessionManager;

// =============================================================================
// Transport SubType
// =============================================================================

enum class TransportSubType : uint8_t {
    AUTO = 0,
    TCPDIRECT,
    ONLOAD,
    KERNEL
};

inline const char* to_string(TransportSubType t) {
    switch (t) {
        case TransportSubType::AUTO: return "auto";
        case TransportSubType::TCPDIRECT: return "tcpdirect";
        case TransportSubType::ONLOAD: return "onload";
        case TransportSubType::KERNEL: return "kernel";
        default: return "unknown";
    }
}

// =============================================================================
// Session Type
// =============================================================================

enum class SessionType : uint8_t {
    INITIATOR = 0,
    ACCEPTOR
};

inline const char* to_string(SessionType t) {
    return t == SessionType::INITIATOR ? "initiator" : "acceptor";
}

inline const char* to_string(SessionState s) {
    switch (s) {
        case SessionState::DISCONNECTED: return "DISCONNECTED";
        case SessionState::CONNECTING: return "CONNECTING";
        case SessionState::CONNECTED: return "CONNECTED";
        case SessionState::DRAINING: return "DRAINING";
        case SessionState::ERROR: return "ERROR";
        default: return "UNKNOWN";
    }
}

inline const char* to_string(DisconnectReason r) {
    return disconnect_reason_to_string(r);
}

// =============================================================================
// Endpoint Configuration
// =============================================================================

struct EndpointConfig {
    std::string host;
    uint16_t port = 0;
    std::string interface;
    
    bool is_valid() const noexcept { return !host.empty() && port > 0; }
    std::string to_string() const { return host + ":" + std::to_string(port); }
    
    bool operator==(const EndpointConfig& o) const noexcept {
        return host == o.host && port == o.port && interface == o.interface;
    }
};

// =============================================================================
// Session Configuration
// =============================================================================

struct SessionConfig {
    std::string name;
    SessionType type = SessionType::INITIATOR;
    TransportSubType transport_subtype = TransportSubType::AUTO;
    EndpointConfig primary;
    std::optional<EndpointConfig> failover;
    ReconnectConfig reconnect;
    HeartbeatCfg heartbeat;
    bool tcp_nodelay = true;
    int send_buffer_size = 65536;
    int recv_buffer_size = 65536;
    int cpu_affinity = -1;
    uint32_t initial_sequence = 1;
    std::optional<std::string> thread_name;  // Named thread for polling (empty = dedicated)
    
    bool is_valid() const noexcept {
        if (name.empty()) return false;
        if (name.length() > 64) return false;
        if (type == SessionType::INITIATOR && !primary.is_valid()) return false;
        if (type == SessionType::ACCEPTOR && primary.port == 0) return false;
        if (send_buffer_size < 1024 || send_buffer_size > 64 * 1024 * 1024) return false;
        if (recv_buffer_size < 1024 || recv_buffer_size > 64 * 1024 * 1024) return false;
        if (heartbeat.enabled) {
            if (heartbeat.interval_ns == 0) return false;
            if (heartbeat.timeout_ns <= heartbeat.interval_ns) return false;
            if (heartbeat.interval_ns > 3600'000'000'000ULL) return false;
        }
        if (reconnect.enabled) {
            if (reconnect.initial_delay_ns == 0) return false;
            if (reconnect.max_delay_ns < reconnect.initial_delay_ns) return false;
        }
        return true;
    }
    
    std::string validation_error() const {
        if (name.empty()) return "Session name is empty";
        if (name.length() > 64) return "Session name too long (max 64)";
        if (type == SessionType::INITIATOR && !primary.is_valid()) 
            return "Initiator requires valid primary endpoint";
        if (type == SessionType::ACCEPTOR && primary.port == 0) 
            return "Acceptor requires valid port";
        if (send_buffer_size < 1024 || send_buffer_size > 64 * 1024 * 1024) 
            return "send_buffer_size must be 1KB-64MB";
        if (recv_buffer_size < 1024 || recv_buffer_size > 64 * 1024 * 1024) 
            return "recv_buffer_size must be 1KB-64MB";
        if (heartbeat.enabled && heartbeat.interval_ns == 0) 
            return "Heartbeat interval cannot be 0";
        if (heartbeat.enabled && heartbeat.timeout_ns <= heartbeat.interval_ns) 
            return "Heartbeat timeout must be greater than interval";
        if (reconnect.enabled && reconnect.initial_delay_ns == 0)
            return "Reconnect initial_delay cannot be 0";
        if (reconnect.enabled && reconnect.max_delay_ns < reconnect.initial_delay_ns)
            return "Reconnect max_delay must be >= initial_delay";
        return "";
    }
    
    static SessionConfig initiator(const std::string& n) {
        SessionConfig cfg;
        cfg.name = n;
        cfg.type = SessionType::INITIATOR;
        return cfg;
    }
    
    static SessionConfig acceptor(const std::string& n) {
        SessionConfig cfg;
        cfg.name = n;
        cfg.type = SessionType::ACCEPTOR;
        return cfg;
    }
};

// =============================================================================
// Session Statistics (Lock-Free, Thread-Safe Reads)
// =============================================================================

struct alignas(64) SessionStats {
    std::atomic<uint64_t> connect_count{0};
    std::atomic<uint64_t> disconnect_count{0};
    std::atomic<uint64_t> reconnect_count{0};
    std::atomic<uint64_t> failover_count{0};
    std::atomic<uint64_t> messages_sent{0};
    std::atomic<uint64_t> messages_received{0};
    std::atomic<uint64_t> bytes_sent{0};
    std::atomic<uint64_t> bytes_received{0};
    std::atomic<uint64_t> send_errors{0};
    std::atomic<uint64_t> recv_errors{0};
    std::atomic<uint64_t> sequence_gaps{0};
    std::atomic<uint64_t> heartbeat_timeouts{0};
    std::atomic<uint64_t> invalid_messages{0};
    std::atomic<uint64_t> min_rtt_ns{UINT64_MAX};
    std::atomic<uint64_t> max_rtt_ns{0};
    std::atomic<uint64_t> sum_rtt_ns{0};
    std::atomic<uint64_t> rtt_count{0};
    std::atomic<uint64_t> last_rtt_ns{0};
    std::atomic<uint64_t> last_send_time_ns{0};
    std::atomic<uint64_t> last_recv_time_ns{0};
    std::atomic<uint64_t> session_start_time_ns{0};
    std::atomic<uint64_t> connected_time_ns{0};
    
    SessionStats() = default;
    SessionStats(const SessionStats&) = delete;
    SessionStats& operator=(const SessionStats&) = delete;
    
    void reset() noexcept {
        connect_count.store(0, std::memory_order_relaxed);
        disconnect_count.store(0, std::memory_order_relaxed);
        reconnect_count.store(0, std::memory_order_relaxed);
        failover_count.store(0, std::memory_order_relaxed);
        messages_sent.store(0, std::memory_order_relaxed);
        messages_received.store(0, std::memory_order_relaxed);
        bytes_sent.store(0, std::memory_order_relaxed);
        bytes_received.store(0, std::memory_order_relaxed);
        send_errors.store(0, std::memory_order_relaxed);
        recv_errors.store(0, std::memory_order_relaxed);
        sequence_gaps.store(0, std::memory_order_relaxed);
        heartbeat_timeouts.store(0, std::memory_order_relaxed);
        invalid_messages.store(0, std::memory_order_relaxed);
        min_rtt_ns.store(UINT64_MAX, std::memory_order_relaxed);
        max_rtt_ns.store(0, std::memory_order_relaxed);
        sum_rtt_ns.store(0, std::memory_order_relaxed);
        rtt_count.store(0, std::memory_order_relaxed);
        last_rtt_ns.store(0, std::memory_order_relaxed);
        last_send_time_ns.store(0, std::memory_order_relaxed);
        last_recv_time_ns.store(0, std::memory_order_relaxed);
        connected_time_ns.store(0, std::memory_order_relaxed);
    }
    
    void record_rtt(uint64_t rtt_ns) noexcept {
        last_rtt_ns.store(rtt_ns, std::memory_order_relaxed);
        sum_rtt_ns.fetch_add(rtt_ns, std::memory_order_relaxed);
        rtt_count.fetch_add(1, std::memory_order_relaxed);
        
        uint64_t cur = min_rtt_ns.load(std::memory_order_relaxed);
        while (rtt_ns < cur) {
            if (min_rtt_ns.compare_exchange_weak(cur, rtt_ns, std::memory_order_relaxed)) break;
        }
        
        cur = max_rtt_ns.load(std::memory_order_relaxed);
        while (rtt_ns > cur) {
            if (max_rtt_ns.compare_exchange_weak(cur, rtt_ns, std::memory_order_relaxed)) break;
        }
    }
    
    uint64_t avg_rtt_ns() const noexcept {
        uint64_t count = rtt_count.load(std::memory_order_relaxed);
        if (count == 0) return 0;
        return sum_rtt_ns.load(std::memory_order_relaxed) / count;
    }
};

// =============================================================================
// Session Callbacks (Called from poll thread - MUST BE FAST, NO BLOCKING)
// =============================================================================

struct SessionCallbacks {
    std::function<void(ISession&)> on_connect;
    std::function<void(ISession&, DisconnectReason)> on_disconnect;
    std::function<void(ISession&, SessionState, SessionState)> on_state_change;
    std::function<void(ISession&, const MessageHeader&, const uint8_t*, size_t)> on_message;
    std::function<void(ISession&, uint32_t expected, uint32_t received)> on_sequence_gap;
    std::function<void(ISession&, const std::string&)> on_error;
    std::function<void(ISession&, int attempt, uint64_t delay_ns)> on_reconnect_attempt;
    std::function<void(ISession&, const EndpointConfig&)> on_failover;
};

// =============================================================================
// ISession Interface
// =============================================================================

class ISession {
public:
    virtual ~ISession() = default;
    
    virtual const std::string& name() const noexcept = 0;
    virtual SessionType type() const noexcept = 0;
    virtual const SessionConfig& config() const noexcept = 0;
    
    virtual bool start() = 0;
    virtual void stop() noexcept = 0;
    
    virtual SessionState state() const noexcept = 0;
    virtual bool is_connected() const noexcept = 0;
    
    virtual SendResult send(MessageType type, const uint8_t* payload, size_t len) noexcept = 0;
    virtual void poll() noexcept = 0;
    
    virtual SendResult send_order(const uint8_t* p, size_t l) noexcept = 0;
    virtual SendResult send_cancel(const uint8_t* p, size_t l) noexcept = 0;
    virtual SendResult send_modify(const uint8_t* p, size_t l) noexcept = 0;
    
    virtual const EndpointConfig& current_endpoint() const noexcept = 0;
    virtual bool is_using_failover() const noexcept = 0;
    
    virtual ITransport* transport() noexcept = 0;
    virtual const char* transport_name() const noexcept = 0;
    virtual uint64_t estimated_latency_ns() const noexcept = 0;
    
    virtual const SessionStats& stats() const noexcept = 0;
    virtual void reset_stats() noexcept = 0;
    virtual void set_callbacks(SessionCallbacks callbacks) noexcept = 0;
    
    virtual uint32_t next_send_sequence() const noexcept = 0;
    virtual uint32_t last_recv_sequence() const noexcept = 0;
};

// =============================================================================
// Session Implementation
// =============================================================================

class Session : public ISession {
public:
    explicit Session(const SessionConfig& config);
    ~Session() override;
    
    Session(const Session&) = delete;
    Session& operator=(const Session&) = delete;
    Session(Session&&) = delete;
    Session& operator=(Session&&) = delete;
    
    const std::string& name() const noexcept override { return config_.name; }
    SessionType type() const noexcept override { return config_.type; }
    const SessionConfig& config() const noexcept override { return config_; }
    
    bool start() override;
    void stop() noexcept override;
    
    SessionState state() const noexcept override { 
        return state_.load(std::memory_order_acquire); 
    }
    bool is_connected() const noexcept override { 
        return state_.load(std::memory_order_acquire) == SessionState::CONNECTED; 
    }
    
    SendResult send(MessageType type, const uint8_t* payload, size_t len) noexcept override;
    void poll() noexcept override;
    
    SendResult send_order(const uint8_t* p, size_t l) noexcept override { 
        return send(MessageType::NEW_ORDER, p, l); 
    }
    SendResult send_cancel(const uint8_t* p, size_t l) noexcept override { 
        return send(MessageType::CANCEL_ORDER, p, l); 
    }
    SendResult send_modify(const uint8_t* p, size_t l) noexcept override { 
        return send(MessageType::MODIFY_ORDER, p, l); 
    }
    
    const EndpointConfig& current_endpoint() const noexcept override { 
        return current_endpoint_; 
    }
    bool is_using_failover() const noexcept override { return using_failover_; }
    
    ITransport* transport() noexcept override { return transport_.get(); }
    const char* transport_name() const noexcept override;
    uint64_t estimated_latency_ns() const noexcept override;
    
    const SessionStats& stats() const noexcept override { return stats_; }
    void reset_stats() noexcept override { stats_.reset(); }
    
    void set_callbacks(SessionCallbacks callbacks) noexcept override { 
        callbacks_ = std::move(callbacks); 
    }
    
    uint32_t next_send_sequence() const noexcept override { 
        return send_sequence_.load(std::memory_order_relaxed); 
    }
    uint32_t last_recv_sequence() const noexcept override { 
        return recv_sequence_.load(std::memory_order_relaxed); 
    }

private:
    void set_state(SessionState new_state) noexcept;
    bool connect_to_endpoint(const EndpointConfig& ep) noexcept;
    void handle_disconnect(DisconnectReason reason) noexcept;
    void schedule_reconnect() noexcept;
    void attempt_reconnect() noexcept;
    bool try_failover() noexcept;
    void send_heartbeat() noexcept;
    void check_heartbeat_timeout() noexcept;
    void process_received_data() noexcept;
    void process_message(const MessageHeader& hdr, const uint8_t* payload, size_t len) noexcept;
    void check_sequence(uint32_t seq) noexcept;
    std::unique_ptr<ITransport> create_transport(const EndpointConfig& ep) noexcept;
    
    template<typename Cb, typename... Args>
    void invoke(const Cb& cb, Args&&... args) noexcept {
        if (cb) { cb(std::forward<Args>(args)...); }
    }
    
    const SessionConfig config_;
    SessionCallbacks callbacks_;
    std::atomic<SessionState> state_{SessionState::DISCONNECTED};
    EndpointConfig current_endpoint_;
    bool using_failover_ = false;
    std::unique_ptr<ITransport> transport_;
    std::atomic<uint32_t> send_sequence_;
    std::atomic<uint32_t> recv_sequence_{0};
    uint64_t last_hb_sent_ns_ = 0;
    uint64_t last_hb_recv_ns_ = 0;
    uint32_t reconnect_attempts_ = 0;
    uint64_t next_reconnect_time_ns_ = 0;
    bool is_reconnecting_ = false;
    static constexpr size_t RECV_BUF_SIZE = 65536;
    static constexpr size_t MAX_MSG_SIZE = 65536;
    alignas(64) uint8_t recv_buf_[RECV_BUF_SIZE];
    size_t recv_buf_pos_ = 0;
    SessionStats stats_;
    PollThread* poll_thread_ = nullptr;  // Thread for polling (bound on start)
};

// =============================================================================
// Session Factory
// =============================================================================

class SessionFactory {
public:
    // All factory methods return nullptr on failure (no exceptions)
    static std::unique_ptr<ISession> create(const SessionConfig& cfg) noexcept;
    static std::unique_ptr<ISession> create(const SessionConfig& cfg, SessionCallbacks cb) noexcept;
    static std::unique_ptr<ISession> create_or_throw(const SessionConfig& cfg);  // Throws std::invalid_argument on invalid config
    
    static std::unique_ptr<ISession> create_initiator(
        const std::string& name, const std::string& host, uint16_t port, 
        TransportSubType t = TransportSubType::AUTO) noexcept;
    static std::unique_ptr<ISession> create_acceptor(
        const std::string& name, uint16_t port, 
        TransportSubType t = TransportSubType::AUTO) noexcept;
};

// =============================================================================
// Session Manager (NOT thread-safe - use from single thread)
// =============================================================================

class SessionManager {
public:
    SessionManager() = default;
    ~SessionManager();
    
    SessionManager(const SessionManager&) = delete;
    SessionManager& operator=(const SessionManager&) = delete;
    
    ISession* add_session(const SessionConfig& cfg) noexcept;
    ISession* add_session(std::unique_ptr<ISession> s) noexcept;
    
    void remove_session(const std::string& name) noexcept;
    ISession* get_session(const std::string& name) noexcept;
    bool has_session(const std::string& name) const noexcept;
    
    void start_all() noexcept;
    void stop_all() noexcept;
    void poll_all() noexcept;
    
    size_t session_count() const noexcept { return sessions_.size(); }
    
    template<typename Func>
    void for_each_session(Func&& func) noexcept {
        for (auto& [n, s] : sessions_) { func(*s); }
    }
    
    void set_global_callbacks(SessionCallbacks cb) noexcept;
    
private:
    std::unordered_map<std::string, std::unique_ptr<ISession>> sessions_;
    SessionCallbacks global_callbacks_;
};

// =============================================================================
// Fluent Builder
// =============================================================================

class SessionConfigBuilder {
public:
    explicit SessionConfigBuilder(const std::string& name) { cfg_.name = name; }
    
    SessionConfigBuilder& as_initiator() noexcept { cfg_.type = SessionType::INITIATOR; return *this; }
    SessionConfigBuilder& as_acceptor() noexcept { cfg_.type = SessionType::ACCEPTOR; return *this; }
    SessionConfigBuilder& transport(TransportSubType t) noexcept { cfg_.transport_subtype = t; return *this; }
    SessionConfigBuilder& connect_to(const std::string& h, uint16_t p) { 
        cfg_.primary.host = h; cfg_.primary.port = p; return *this; 
    }
    SessionConfigBuilder& listen_on(uint16_t p) noexcept { cfg_.primary.port = p; return *this; }
    SessionConfigBuilder& interface(const std::string& i) { cfg_.primary.interface = i; return *this; }
    SessionConfigBuilder& failover(const std::string& h, uint16_t p) { 
        cfg_.failover = EndpointConfig{h, p, ""}; return *this; 
    }
    SessionConfigBuilder& failover(const std::string& h, uint16_t p, const std::string& iface) { 
        cfg_.failover = EndpointConfig{h, p, iface}; return *this; 
    }
    
    SessionConfigBuilder& heartbeat(uint64_t interval_ms, uint64_t timeout_ms) noexcept {
        cfg_.heartbeat.enabled = true;
        cfg_.heartbeat.interval_ns = interval_ms * 1'000'000;
        cfg_.heartbeat.timeout_ns = timeout_ms * 1'000'000;
        return *this;
    }
    SessionConfigBuilder& no_heartbeat() noexcept { cfg_.heartbeat.enabled = false; return *this; }
    
    SessionConfigBuilder& reconnect(uint64_t init_ms, uint64_t max_ms, uint32_t max_attempts = 0) noexcept {
        cfg_.reconnect.enabled = true;
        cfg_.reconnect.initial_delay_ns = init_ms * 1'000'000;
        cfg_.reconnect.max_delay_ns = max_ms * 1'000'000;
        cfg_.reconnect.max_attempts = max_attempts;
        return *this;
    }
    SessionConfigBuilder& no_reconnect() noexcept { cfg_.reconnect.enabled = false; return *this; }
    SessionConfigBuilder& pin_to_cpu(int cpu) noexcept { cfg_.cpu_affinity = cpu; return *this; }
    SessionConfigBuilder& buffer_sizes(int snd, int rcv) noexcept { 
        cfg_.send_buffer_size = snd; cfg_.recv_buffer_size = rcv; return *this; 
    }
    SessionConfigBuilder& thread(const std::string& name) { 
        cfg_.thread_name = name; return *this; 
    }
    
    bool is_valid() const noexcept { return cfg_.is_valid(); }
    std::string validation_error() const { return cfg_.validation_error(); }
    SessionConfig build() const { return cfg_; }
    std::unique_ptr<ISession> create() const noexcept { return SessionFactory::create(cfg_); }
    std::unique_ptr<ISession> create_or_throw() const { return SessionFactory::create_or_throw(cfg_); }
    
private:
    SessionConfig cfg_;
};

inline SessionConfigBuilder session(const std::string& name) { 
    return SessionConfigBuilder(name); 
}

// =============================================================================
// Helper for sequence number comparison with wrap-around
// =============================================================================

namespace detail {

inline int32_t sequence_diff(uint32_t a, uint32_t b) noexcept {
    return static_cast<int32_t>(a - b);
}

inline bool sequence_less_than(uint32_t a, uint32_t b) noexcept {
    return sequence_diff(a, b) < 0;
}

inline bool time_elapsed(uint64_t start_ns, uint64_t duration_ns, uint64_t now_ns) noexcept {
    if (now_ns < start_ns) return true;
    return (now_ns - start_ns) >= duration_ns;
}

} // namespace detail

} // namespace ptpx
