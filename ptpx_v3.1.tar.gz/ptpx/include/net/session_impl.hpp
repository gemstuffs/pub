// =============================================================================
// ptpx v3.0 - Session Implementation (Production-Ready)
// =============================================================================
//
// THREADING MODEL:
//   - All methods except state()/stats() called from single poll thread
//   - No locks in hot path (send/poll)
//   - No exceptions (disabled for latency)
//   - Callbacks invoked synchronously - must not block
//
// =============================================================================

#pragma once

#include "session.hpp"
#include "transport.hpp"
#include <random>
#include <cstring>
#include <cerrno>
#include <algorithm>

namespace ptpx {

// =============================================================================
// Helper Functions
// =============================================================================

namespace detail {

inline TransportType subtype_to_type(TransportSubType subtype) noexcept {
    switch (subtype) {
        case TransportSubType::TCPDIRECT: return TransportType::TCPDIRECT;
        case TransportSubType::ONLOAD: return TransportType::ONLOAD;
        case TransportSubType::KERNEL: return TransportType::KERNEL;
        default: return TransportType::AUTO;
    }
}

inline std::unique_ptr<ITransport> create_transport_for_session(
    const SessionConfig& cfg, 
    const EndpointConfig& ep
) noexcept {
    TransportConfig tc;
    tc.preferred_type = subtype_to_type(cfg.transport_subtype);
    tc.host = ep.host;
    tc.port = ep.port;
    tc.interface = ep.interface.empty() ? cfg.primary.interface : ep.interface;
    tc.tcp_nodelay = cfg.tcp_nodelay;
    tc.send_buffer_size = cfg.send_buffer_size;
    tc.recv_buffer_size = cfg.recv_buffer_size;
    tc.reconnect = cfg.reconnect;
    tc.heartbeat = cfg.heartbeat;
    return TransportFactory::create_client(tc);
}

inline uint64_t calculate_reconnect_delay(const ReconnectConfig& cfg, uint32_t attempt) noexcept {
    if (cfg.initial_delay_ns == 0) return 0;
    
    uint64_t delay = cfg.initial_delay_ns;
    
    // Exponential backoff with overflow protection
    for (uint32_t i = 0; i < attempt && delay < cfg.max_delay_ns; ++i) {
        // Check for potential overflow before multiplication
        if (cfg.backoff_multiplier > 1.0 && 
            delay > cfg.max_delay_ns / cfg.backoff_multiplier) {
            delay = cfg.max_delay_ns;
            break;
        }
        delay = static_cast<uint64_t>(static_cast<double>(delay) * cfg.backoff_multiplier);
    }
    
    delay = std::min(delay, cfg.max_delay_ns);
    
    // Apply jitter
    if (cfg.jitter_factor > 0 && cfg.jitter_factor <= 1.0) {
        static thread_local std::mt19937 gen(std::random_device{}());
        std::uniform_real_distribution<double> dist(
            1.0 - cfg.jitter_factor, 
            1.0 + cfg.jitter_factor
        );
        double jittered = static_cast<double>(delay) * dist(gen);
        delay = static_cast<uint64_t>(std::max(0.0, jittered));
    }
    
    return delay;
}

} // namespace detail

// =============================================================================
// Session Implementation
// =============================================================================

inline Session::Session(const SessionConfig& config)
    : config_(config)
    , current_endpoint_(config.primary)
    , send_sequence_(config.initial_sequence)
{
    stats_.session_start_time_ns.store(Timestamp::now_ns(), std::memory_order_relaxed);
}

inline Session::~Session() { 
    stop(); 
}

inline bool Session::start() {
    // Must be in DISCONNECTED state
    SessionState expected = SessionState::DISCONNECTED;
    if (!state_.compare_exchange_strong(expected, SessionState::CONNECTING,
                                         std::memory_order_acq_rel)) {
        return false;  // Not in correct state
    }
    
    // Bind to poll thread
    if (config_.thread_name) {
        // Use named thread
        poll_thread_ = ThreadRegistry::instance().get_thread(*config_.thread_name);
        if (!poll_thread_) {
            state_.store(SessionState::ERROR, std::memory_order_release);
            invoke(callbacks_.on_error, *this, "Named thread not found: " + *config_.thread_name);
            return false;
        }
    } else {
        // Create dedicated thread for this session
        poll_thread_ = ThreadRegistry::instance().get_or_create_dedicated(config_.name);
        if (!poll_thread_) {
            state_.store(SessionState::ERROR, std::memory_order_release);
            invoke(callbacks_.on_error, *this, "Failed to create dedicated thread");
            return false;
        }
    }
    
    // Bind this session to poll thread
    poll_thread_->bind_session(this);
    
    // Start poll thread if not running
    if (!poll_thread_->is_running()) {
        poll_thread_->start();
    }
    
    if (config_.type == SessionType::ACCEPTOR) {
        // Acceptor mode - just mark as connected (simplified for now)
        state_.store(SessionState::CONNECTED, std::memory_order_release);
        return true;
    }
    
    // Initiator mode - attempt connection
    return connect_to_endpoint(config_.primary);
}

inline void Session::stop() noexcept {
    SessionState current = state_.load(std::memory_order_acquire);
    if (current == SessionState::DISCONNECTED) return;
    
    // Signal draining
    state_.store(SessionState::DRAINING, std::memory_order_release);
    invoke(callbacks_.on_state_change, *this, current, SessionState::DRAINING);
    
    // Unbind from poll thread
    if (poll_thread_) {
        poll_thread_->unbind_session(this);
        
        // Stop dedicated thread if no more sessions
        if (poll_thread_->session_count() == 0) {
            poll_thread_->stop();
        }
        poll_thread_ = nullptr;
    }
    
    // Disconnect transport
    if (transport_) {
        if (transport_->is_connected()) {
            transport_->disconnect();
        }
        transport_.reset();
    }
    
    // Reset state
    is_reconnecting_ = false;
    reconnect_attempts_ = 0;
    recv_buf_pos_ = 0;
    
    state_.store(SessionState::DISCONNECTED, std::memory_order_release);
    invoke(callbacks_.on_state_change, *this, SessionState::DRAINING, SessionState::DISCONNECTED);
}

inline void Session::set_state(SessionState new_state) noexcept {
    SessionState old = state_.exchange(new_state, std::memory_order_acq_rel);
    if (old != new_state) {
        invoke(callbacks_.on_state_change, *this, old, new_state);
    }
}

inline bool Session::connect_to_endpoint(const EndpointConfig& ep) noexcept {
    // Create transport for this endpoint
    transport_ = create_transport(ep);
    if (!transport_) {
        handle_disconnect(DisconnectReason::CONNECT_REFUSED);
        return false;
    }
    
    current_endpoint_ = ep;
    
    // Attempt connection
    if (!transport_->connect()) {
        handle_disconnect(DisconnectReason::CONNECT_TIMEOUT);
        return false;
    }
    
    // Success
    set_state(SessionState::CONNECTED);
    
    stats_.connect_count.fetch_add(1, std::memory_order_relaxed);
    
    uint64_t now = Timestamp::now_ns();
    stats_.connected_time_ns.store(now, std::memory_order_relaxed);
    last_hb_sent_ns_ = now;
    last_hb_recv_ns_ = now;
    reconnect_attempts_ = 0;
    is_reconnecting_ = false;
    
    invoke(callbacks_.on_connect, *this);
    return true;
}

inline void Session::handle_disconnect(DisconnectReason reason) noexcept {
    SessionState current = state_.load(std::memory_order_acquire);
    if (current == SessionState::DRAINING || current == SessionState::DISCONNECTED) {
        return;
    }
    
    stats_.disconnect_count.fetch_add(1, std::memory_order_relaxed);
    invoke(callbacks_.on_disconnect, *this, reason);
    
    // Clean up transport
    if (transport_) {
        transport_.reset();
    }
    
    // Check if should reconnect
    if (config_.reconnect.enabled && 
        config_.type == SessionType::INITIATOR &&
        reason != DisconnectReason::USER_REQUESTED) {
        schedule_reconnect();
    } else {
        set_state(SessionState::DISCONNECTED);
    }
}

inline void Session::schedule_reconnect() noexcept {
    // Check max attempts
    if (config_.reconnect.max_attempts > 0 && 
        reconnect_attempts_ >= config_.reconnect.max_attempts) {
        set_state(SessionState::ERROR);
        invoke(callbacks_.on_error, *this, std::string("Max reconnect attempts exceeded"));
        return;
    }
    
    is_reconnecting_ = true;
    set_state(SessionState::CONNECTING);
    
    uint64_t delay = detail::calculate_reconnect_delay(config_.reconnect, reconnect_attempts_);
    uint64_t now = Timestamp::now_ns();
    
    // Overflow-safe addition
    if (delay > UINT64_MAX - now) {
        next_reconnect_time_ns_ = UINT64_MAX;
    } else {
        next_reconnect_time_ns_ = now + delay;
    }
    
    reconnect_attempts_++;
    stats_.reconnect_count.fetch_add(1, std::memory_order_relaxed);
    
    invoke(callbacks_.on_reconnect_attempt, *this, static_cast<int>(reconnect_attempts_), delay);
}

inline void Session::attempt_reconnect() noexcept {
    // Try failover after failures on primary
    if (config_.failover.has_value() && 
        reconnect_attempts_ > 1 && 
        !using_failover_) {
        if (try_failover()) return;
    }
    
    // Try current endpoint
    if (!connect_to_endpoint(current_endpoint_)) {
        schedule_reconnect();
    }
}

inline bool Session::try_failover() noexcept {
    if (!config_.failover.has_value()) return false;
    
    const auto& failover_ep = config_.failover.value();
    invoke(callbacks_.on_failover, *this, failover_ep);
    
    using_failover_ = true;
    stats_.failover_count.fetch_add(1, std::memory_order_relaxed);
    
    if (connect_to_endpoint(failover_ep)) {
        return true;
    }
    
    // Failover failed, revert
    using_failover_ = false;
    current_endpoint_ = config_.primary;
    return false;
}

inline SendResult Session::send(MessageType type, const uint8_t* payload, size_t len) noexcept {
    // Fast path checks
    if (state_.load(std::memory_order_acquire) != SessionState::CONNECTED) {
        return SendResult::DISCONNECTED;
    }
    
    if (!transport_) {
        return SendResult::DISCONNECTED;
    }
    
    // Validate payload
    if (len > 0 && payload == nullptr) {
        return SendResult::ERROR;
    }
    
    if (len > MAX_MSG_SIZE - MessageHeader::SIZE) {
        return SendResult::ERROR;
    }
    
    // Send via transport
    auto result = transport_->send_message(type, payload, len);
    
    if (result != SendResult::SUCCESS) {
        stats_.send_errors.fetch_add(1, std::memory_order_relaxed);
        return result;
    }
    
    // Update stats
    stats_.messages_sent.fetch_add(1, std::memory_order_relaxed);
    stats_.bytes_sent.fetch_add(MessageHeader::SIZE + len, std::memory_order_relaxed);
    stats_.last_send_time_ns.store(Timestamp::now_ns(), std::memory_order_relaxed);
    send_sequence_.fetch_add(1, std::memory_order_relaxed);
    
    return SendResult::SUCCESS;
}

inline void Session::poll() noexcept {
    uint64_t now = Timestamp::now_ns();
    
    // Handle reconnection
    if (is_reconnecting_) {
        if (now >= next_reconnect_time_ns_) {
            attempt_reconnect();
        }
        return;
    }
    
    // Check transport
    if (!transport_) return;
    
    // Poll transport
    transport_->poll();
    
    // Check if disconnected
    SessionState current = state_.load(std::memory_order_acquire);
    if (!transport_->is_connected() && current == SessionState::CONNECTED) {
        handle_disconnect(DisconnectReason::READ_ERROR);
        return;
    }
    
    // Receive data
    if (recv_buf_pos_ < RECV_BUF_SIZE) {
        ssize_t n = transport_->recv(recv_buf_ + recv_buf_pos_, RECV_BUF_SIZE - recv_buf_pos_);
        if (n > 0) {
            recv_buf_pos_ += static_cast<size_t>(n);
            process_received_data();
        } else if (n < 0 && errno != EAGAIN && errno != EWOULDBLOCK) {
            stats_.recv_errors.fetch_add(1, std::memory_order_relaxed);
            handle_disconnect(DisconnectReason::READ_ERROR);
            return;
        }
    } else {
        // Buffer full - protocol error
        stats_.invalid_messages.fetch_add(1, std::memory_order_relaxed);
        handle_disconnect(DisconnectReason::PROTOCOL_ERROR);
        recv_buf_pos_ = 0;
        return;
    }
    
    // Heartbeat
    if (config_.heartbeat.enabled && current == SessionState::CONNECTED) {
        if (detail::time_elapsed(last_hb_sent_ns_, config_.heartbeat.interval_ns, now)) {
            send_heartbeat();
        }
        check_heartbeat_timeout();
    }
}

inline void Session::process_received_data() noexcept {
    size_t offset = 0;
    
    while (offset + MessageHeader::SIZE <= recv_buf_pos_) {
        auto* hdr = reinterpret_cast<MessageHeader*>(recv_buf_ + offset);
        
        // Validate message
        if (hdr->length == 0 || 
            hdr->length < MessageHeader::SIZE || 
            hdr->length > MAX_MSG_SIZE) {
            stats_.invalid_messages.fetch_add(1, std::memory_order_relaxed);
            handle_disconnect(DisconnectReason::PROTOCOL_ERROR);
            recv_buf_pos_ = 0;
            return;
        }
        
        // Check complete message
        if (offset + hdr->length > recv_buf_pos_) {
            break;  // Need more data
        }
        
        size_t payload_len = hdr->length - MessageHeader::SIZE;
        const uint8_t* payload = recv_buf_ + offset + MessageHeader::SIZE;
        
        process_message(*hdr, payload, payload_len);
        offset += hdr->length;
    }
    
    // Compact buffer
    if (offset > 0) {
        if (offset < recv_buf_pos_) {
            std::memmove(recv_buf_, recv_buf_ + offset, recv_buf_pos_ - offset);
            recv_buf_pos_ -= offset;
        } else {
            recv_buf_pos_ = 0;
        }
    }
}

inline void Session::process_message(const MessageHeader& hdr, const uint8_t* payload, size_t len) noexcept {
    stats_.messages_received.fetch_add(1, std::memory_order_relaxed);
    stats_.bytes_received.fetch_add(hdr.length, std::memory_order_relaxed);
    stats_.last_recv_time_ns.store(Timestamp::now_ns(), std::memory_order_relaxed);
    
    check_sequence(hdr.sequence_number);
    
    // Handle heartbeats internally
    if (hdr.type == MessageType::HEARTBEAT_REQUEST) {
        send(MessageType::HEARTBEAT_RESPONSE, nullptr, 0);
        return;
    }
    
    if (hdr.type == MessageType::HEARTBEAT_RESPONSE) {
        uint64_t now = Timestamp::now_ns();
        last_hb_recv_ns_ = now;
        
        // Calculate RTT (with sanity checks)
        if (hdr.timestamp_ns > 0 && hdr.timestamp_ns <= now) {
            uint64_t rtt = now - hdr.timestamp_ns;
            if (rtt < 60'000'000'000ULL) {  // < 60 seconds
                stats_.record_rtt(rtt);
            }
        }
        return;
    }
    
    // Dispatch to user
    invoke(callbacks_.on_message, *this, hdr, payload, len);
}

inline void Session::check_sequence(uint32_t seq) noexcept {
    uint32_t last = recv_sequence_.load(std::memory_order_relaxed);
    
    if (last != 0) {
        uint32_t expected = last + 1;
        int32_t diff = detail::sequence_diff(seq, expected);
        
        if (diff != 0) {
            stats_.sequence_gaps.fetch_add(1, std::memory_order_relaxed);
            invoke(callbacks_.on_sequence_gap, *this, expected, seq);
        }
    }
    
    recv_sequence_.store(seq, std::memory_order_relaxed);
}

inline void Session::send_heartbeat() noexcept {
    send(MessageType::HEARTBEAT_REQUEST, nullptr, 0);
    last_hb_sent_ns_ = Timestamp::now_ns();
}

inline void Session::check_heartbeat_timeout() noexcept {
    uint64_t now = Timestamp::now_ns();
    
    if (detail::time_elapsed(last_hb_recv_ns_, config_.heartbeat.timeout_ns, now)) {
        stats_.heartbeat_timeouts.fetch_add(1, std::memory_order_relaxed);
        handle_disconnect(DisconnectReason::HEARTBEAT_TIMEOUT);
    }
}

inline std::unique_ptr<ITransport> Session::create_transport(const EndpointConfig& ep) noexcept {
    return detail::create_transport_for_session(config_, ep);
}

inline const char* Session::transport_name() const noexcept {
    return transport_ ? transport_->type_name() : "none";
}

inline uint64_t Session::estimated_latency_ns() const noexcept {
    return transport_ ? transport_->estimated_latency_ns() : 0;
}

// =============================================================================
// Factory Implementation (No exceptions - returns nullptr on failure)
// =============================================================================

inline std::unique_ptr<ISession> SessionFactory::create(const SessionConfig& cfg) noexcept {
    if (!cfg.is_valid()) return nullptr;
    // Note: make_unique can technically throw, but with -fno-exceptions it will abort
    return std::make_unique<Session>(cfg);
}

inline std::unique_ptr<ISession> SessionFactory::create(const SessionConfig& cfg, SessionCallbacks cb) noexcept {
    auto s = create(cfg);
    if (s) s->set_callbacks(std::move(cb));
    return s;
}

inline std::unique_ptr<ISession> SessionFactory::create_or_throw(const SessionConfig& cfg) {
    // With -fno-exceptions, this just returns nullptr on invalid config
    // The "throw" version exists for API compatibility but doesn't actually throw
    return create(cfg);
}

inline std::unique_ptr<ISession> SessionFactory::create_initiator(
    const std::string& name, const std::string& host, uint16_t port, TransportSubType t) noexcept {
    return session(name).as_initiator().connect_to(host, port).transport(t).create();
}

inline std::unique_ptr<ISession> SessionFactory::create_acceptor(
    const std::string& name, uint16_t port, TransportSubType t) noexcept {
    return session(name).as_acceptor().listen_on(port).transport(t).create();
}

// =============================================================================
// Session Manager Implementation
// =============================================================================

inline SessionManager::~SessionManager() { 
    stop_all(); 
}

inline ISession* SessionManager::add_session(const SessionConfig& cfg) noexcept {
    if (!cfg.is_valid()) return nullptr;
    if (has_session(cfg.name)) return nullptr;
    
    auto s = SessionFactory::create(cfg);
    if (!s) return nullptr;
    
    s->set_callbacks(global_callbacks_);
    auto* ptr = s.get();
    sessions_[cfg.name] = std::move(s);
    return ptr;
}

inline ISession* SessionManager::add_session(std::unique_ptr<ISession> s) noexcept {
    if (!s) return nullptr;
    if (has_session(s->name())) return nullptr;
    
    s->set_callbacks(global_callbacks_);
    auto* ptr = s.get();
    std::string name = s->name();
    sessions_[name] = std::move(s);
    return ptr;
}

inline void SessionManager::remove_session(const std::string& name) noexcept {
    auto it = sessions_.find(name);
    if (it != sessions_.end()) {
        it->second->stop();
        sessions_.erase(it);
    }
}

inline ISession* SessionManager::get_session(const std::string& name) noexcept {
    auto it = sessions_.find(name);
    return it != sessions_.end() ? it->second.get() : nullptr;
}

inline bool SessionManager::has_session(const std::string& name) const noexcept {
    return sessions_.find(name) != sessions_.end();
}

inline void SessionManager::start_all() noexcept {
    for (auto& [n, s] : sessions_) {
        s->start();
    }
}

inline void SessionManager::stop_all() noexcept {
    for (auto& [n, s] : sessions_) {
        s->stop();
    }
}

inline void SessionManager::poll_all() noexcept {
    for (auto& [n, s] : sessions_) {
        s->poll();
    }
}

inline void SessionManager::set_global_callbacks(SessionCallbacks cb) noexcept {
    global_callbacks_ = std::move(cb);
    for (auto& [n, s] : sessions_) {
        s->set_callbacks(global_callbacks_);
    }
}

// =============================================================================
// PollThread::run() - Implemented here to avoid circular include with ISession
// =============================================================================

inline void PollThread::run() noexcept {
    thread_id_ = std::this_thread::get_id();
    running_.store(true, std::memory_order_release);
    
    apply_thread_config();
    
    // Take snapshot of sessions (they don't change after start)
    std::vector<ISession*> local_sessions;
    {
        std::lock_guard<std::mutex> lock(sessions_mutex_);
        local_sessions = sessions_;
    }
    
    while (!stop_requested_.load(std::memory_order_acquire)) {
        size_t events = 0;
        
        for (auto* session : local_sessions) {
            if (session) {
                session->poll();
                ++events;
            }
        }
        
        poll_count_.fetch_add(1, std::memory_order_relaxed);
        total_events_.fetch_add(events, std::memory_order_relaxed);
        
        // Yield if no sessions to avoid busy spin
        if (local_sessions.empty()) {
            std::this_thread::sleep_for(std::chrono::microseconds(100));
        }
    }
    
    running_.store(false, std::memory_order_release);
}

} // namespace ptpx
