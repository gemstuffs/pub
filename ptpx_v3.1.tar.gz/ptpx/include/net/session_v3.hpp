// =============================================================================
// ptpx v3.0 - Session Layer
// =============================================================================
//
// THREADING MODEL:
//   - Sessions bind to named poll threads (or get a dedicated thread)
//   - poll() is called by the poll thread - DO NOT call directly
//   - send() is THREAD-SAFE - can be called from ANY thread
//   - send_immediate() is CALLBACK-ONLY - zero overhead
//   - state() / stats() can be read from ANY thread (atomic)
//   - Callbacks are invoked synchronously from poll thread - DO NOT BLOCK
//
// SEND API:
//   send_immediate() - From callback only, zero overhead (~0ns)
//   send_async()     - From any thread, lock-free queue (~15ns)
//   send()           - Auto-detects context, uses best path (~2ns check)
//
// =============================================================================

#pragma once

#include "../core/common.hpp"
#include "../core/mpsc_queue.hpp"
#include "../core/hw_timestamp.hpp"
#include "../core/thread_registry.hpp"
#include "transport_v3.hpp"

#include <string>
#include <memory>
#include <functional>
#include <optional>
#include <atomic>
#include <thread>

namespace ptpx {

// Forward declarations
class ISession;
class Session;

// =============================================================================
// Disconnect Reason
// =============================================================================

enum class DisconnectReason : uint8_t {
    USER_INITIATED = 0,
    CONNECTION_LOST,
    READ_ERROR,
    WRITE_ERROR,
    HEARTBEAT_TIMEOUT,
    PROTOCOL_ERROR,
    CONNECT_REFUSED,
    CONNECT_TIMEOUT
};

inline const char* to_string(DisconnectReason r) {
    switch (r) {
        case DisconnectReason::USER_INITIATED: return "user_initiated";
        case DisconnectReason::CONNECTION_LOST: return "connection_lost";
        case DisconnectReason::READ_ERROR: return "read_error";
        case DisconnectReason::WRITE_ERROR: return "write_error";
        case DisconnectReason::HEARTBEAT_TIMEOUT: return "heartbeat_timeout";
        case DisconnectReason::PROTOCOL_ERROR: return "protocol_error";
        case DisconnectReason::CONNECT_REFUSED: return "connect_refused";
        case DisconnectReason::CONNECT_TIMEOUT: return "connect_timeout";
        default: return "unknown";
    }
}

// =============================================================================
// Session Type
// =============================================================================

enum class SessionType : uint8_t {
    INITIATOR = 0,  // Client - connects to server
    ACCEPTOR        // Server - accepts connections
};

inline const char* to_string(SessionType t) {
    return t == SessionType::INITIATOR ? "initiator" : "acceptor";
}

// =============================================================================
// Endpoint Configuration
// =============================================================================

struct EndpointConfig {
    std::string host;
    uint16_t port = 0;
    std::string interface;
    
    bool is_valid() const noexcept { return !host.empty() && port > 0; }
    std::string to_string() const { return host + ":" + std::to_string(port); }
    
    bool operator==(const EndpointConfig& o) const noexcept {
        return host == o.host && port == o.port && interface == o.interface;
    }
};

// =============================================================================
// Reconnection Configuration
// =============================================================================

struct ReconnectConfig {
    bool enabled = true;
    uint64_t initial_delay_ns = 100'000'000;    // 100ms
    uint64_t max_delay_ns = 30'000'000'000ULL;  // 30s
    double backoff_multiplier = 2.0;
    double jitter_factor = 0.1;
    uint32_t max_attempts = 0;  // 0 = unlimited
};

// =============================================================================
// Heartbeat Configuration
// =============================================================================

struct HeartbeatConfig {
    bool enabled = false;
    uint64_t interval_ns = 1'000'000'000;   // 1s
    uint64_t timeout_ns = 5'000'000'000ULL; // 5s
};

// =============================================================================
// Session Configuration
// =============================================================================

struct SessionConfig {
    std::string name;
    SessionType type = SessionType::INITIATOR;
    TransportType transport_type = TransportType::ONLOAD;
    EndpointConfig primary;
    std::optional<EndpointConfig> failover;
    std::optional<std::string> thread_name;  // Named poll thread (empty = dedicated)
    ReconnectConfig reconnect;
    HeartbeatConfig heartbeat;
    bool tcp_nodelay = true;
    int send_buffer_size = 65536;
    int recv_buffer_size = 65536;
    bool enable_stats = true;
    bool enable_hw_timestamps = true;
    uint32_t initial_sequence = 1;
    
    bool is_valid() const noexcept {
        if (name.empty() || name.length() > 64) return false;
        if (type == SessionType::INITIATOR && !primary.is_valid()) return false;
        if (type == SessionType::ACCEPTOR && primary.port == 0) return false;
        return true;
    }
    
    std::string validation_error() const {
        if (name.empty()) return "Session name is empty";
        if (name.length() > 64) return "Session name too long (max 64)";
        if (type == SessionType::INITIATOR && !primary.is_valid())
            return "Initiator requires valid primary endpoint";
        if (type == SessionType::ACCEPTOR && primary.port == 0)
            return "Acceptor requires valid port";
        return "";
    }
};

// =============================================================================
// Session Statistics
// =============================================================================

struct alignas(64) SessionStats {
    std::atomic<uint64_t> connect_count{0};
    std::atomic<uint64_t> disconnect_count{0};
    std::atomic<uint64_t> reconnect_count{0};
    std::atomic<uint64_t> messages_sent{0};
    std::atomic<uint64_t> messages_received{0};
    std::atomic<uint64_t> bytes_sent{0};
    std::atomic<uint64_t> bytes_received{0};
    std::atomic<uint64_t> send_errors{0};
    std::atomic<uint64_t> async_queue_pushes{0};
    std::atomic<uint64_t> async_queue_full{0};
    
    void reset() {
        connect_count.store(0, std::memory_order_relaxed);
        disconnect_count.store(0, std::memory_order_relaxed);
        reconnect_count.store(0, std::memory_order_relaxed);
        messages_sent.store(0, std::memory_order_relaxed);
        messages_received.store(0, std::memory_order_relaxed);
        bytes_sent.store(0, std::memory_order_relaxed);
        bytes_received.store(0, std::memory_order_relaxed);
        send_errors.store(0, std::memory_order_relaxed);
        async_queue_pushes.store(0, std::memory_order_relaxed);
        async_queue_full.store(0, std::memory_order_relaxed);
    }
};

// =============================================================================
// Session Callbacks
// =============================================================================

struct SessionCallbacks {
    std::function<void(ISession&)> on_connect;
    std::function<void(ISession&, DisconnectReason)> on_disconnect;
    std::function<void(ISession&, SessionState, SessionState)> on_state_change;
    std::function<void(ISession&, const MessageHeader&, const uint8_t*, size_t)> on_message;
    std::function<void(ISession&, uint32_t expected, uint32_t received)> on_sequence_gap;
    std::function<void(ISession&, const std::string&)> on_error;
};

// =============================================================================
// Session Interface
// =============================================================================

class ISession {
public:
    virtual ~ISession() = default;
    
    // Identity
    virtual const std::string& name() const noexcept = 0;
    virtual SessionType type() const noexcept = 0;
    virtual const SessionConfig& config() const noexcept = 0;
    
    // Lifecycle
    virtual bool start() = 0;
    virtual void stop() noexcept = 0;
    
    // State
    virtual SessionState state() const noexcept = 0;
    virtual bool is_connected() const noexcept = 0;
    
    // =========================================================================
    // SEND API
    // =========================================================================
    
    // From callback only - ZERO overhead
    // WARNING: Only call from on_message callback!
    virtual SendResult send_immediate(MessageType type, const void* payload, size_t len) noexcept = 0;
    
    // From any thread - lock-free queue
    virtual SendResult send_async(MessageType type, const void* payload, size_t len) noexcept = 0;
    
    // Auto-detect context - uses best path
    virtual SendResult send(MessageType type, const void* payload, size_t len) noexcept = 0;
    
    // Convenience wrappers
    virtual SendResult send_order(const void* payload, size_t len) noexcept = 0;
    virtual SendResult send_cancel(const void* payload, size_t len) noexcept = 0;
    
    // =========================================================================
    // Polling (called by poll thread)
    // =========================================================================
    virtual void poll() noexcept = 0;
    
    // =========================================================================
    // Info
    // =========================================================================
    virtual const EndpointConfig& current_endpoint() const noexcept = 0;
    virtual ITransport* transport() noexcept = 0;
    virtual const char* transport_name() const noexcept = 0;
    
    // =========================================================================
    // Stats
    // =========================================================================
    virtual const SessionStats& stats() const noexcept = 0;
    virtual const LatencyStats& latency_stats() const noexcept = 0;
    virtual void reset_stats() noexcept = 0;
    virtual void enable_stats(bool enable) noexcept = 0;
    
    // =========================================================================
    // Callbacks
    // =========================================================================
    virtual void set_callbacks(SessionCallbacks callbacks) noexcept = 0;
    
    // =========================================================================
    // Sequence numbers
    // =========================================================================
    virtual uint32_t next_send_sequence() const noexcept = 0;
    virtual uint32_t last_recv_sequence() const noexcept = 0;
};

// =============================================================================
// Session Implementation
// =============================================================================

class Session : public ISession {
public:
    explicit Session(const SessionConfig& config);
    ~Session() override;
    
    Session(const Session&) = delete;
    Session& operator=(const Session&) = delete;
    
    // Identity
    const std::string& name() const noexcept override { return config_.name; }
    SessionType type() const noexcept override { return config_.type; }
    const SessionConfig& config() const noexcept override { return config_; }
    
    // Lifecycle
    bool start() override;
    void stop() noexcept override;
    
    // State
    SessionState state() const noexcept override {
        return state_.load(std::memory_order_acquire);
    }
    bool is_connected() const noexcept override {
        return state_.load(std::memory_order_acquire) == SessionState::CONNECTED;
    }
    
    // =========================================================================
    // SEND API
    // =========================================================================
    
    // FAST PATH - From callback only, zero overhead
    SendResult send_immediate(MessageType type, const void* payload, size_t len) noexcept override {
        if (state_.load(std::memory_order_relaxed) != SessionState::CONNECTED) {
            return SendResult::DISCONNECTED;
        }
        
        // Direct send - no lock, no queue
        auto result = transport_->send_message(type, payload, len);
        
        if (result == SendResult::SUCCESS) {
            // Track send time for idle-aware heartbeat (skip for heartbeat messages themselves)
            if (type != MessageType::HEARTBEAT_REQUEST && type != MessageType::HEARTBEAT_RESPONSE) {
                last_send_ns_ = Timestamp::now_ns();
            }
            
            if (stats_enabled_) {
                stats_.messages_sent.fetch_add(1, std::memory_order_relaxed);
                stats_.bytes_sent.fetch_add(sizeof(MessageHeader) + len, std::memory_order_relaxed);
            }
        }
        
        return result;
    }
    
    // SAFE PATH - From any thread, lock-free queue
    SendResult send_async(MessageType type, const void* payload, size_t len) noexcept override {
        if (state_.load(std::memory_order_relaxed) != SessionState::CONNECTED) {
            return SendResult::DISCONNECTED;
        }
        
        // Build message in queue slot
        alignas(64) uint8_t buffer[SendRequest::MAX_PAYLOAD];
        
        auto* header = reinterpret_cast<MessageHeader*>(buffer);
        header->length = static_cast<uint32_t>(sizeof(MessageHeader) + len);
        header->sequence_number = 0;  // Will be assigned when dequeued
        header->timestamp_ns = Timestamp::now_tsc();
        header->type = type;
        
        if (len > 0 && payload) {
            if (sizeof(MessageHeader) + len > SendRequest::MAX_PAYLOAD) {
                return SendResult::ERROR;
            }
            std::memcpy(buffer + sizeof(MessageHeader), payload, len);
        }
        
        if (async_queue_.try_push(buffer, sizeof(MessageHeader) + len, Timestamp::now_tsc())) {
            // Track send time for idle-aware heartbeat (skip for heartbeat messages themselves)
            if (type != MessageType::HEARTBEAT_REQUEST && type != MessageType::HEARTBEAT_RESPONSE) {
                last_send_ns_ = Timestamp::now_ns();
            }
            
            if (stats_enabled_) {
                stats_.async_queue_pushes.fetch_add(1, std::memory_order_relaxed);
            }
            return SendResult::QUEUED;
        }
        
        if (stats_enabled_) {
            stats_.async_queue_full.fetch_add(1, std::memory_order_relaxed);
        }
        return SendResult::QUEUE_FULL;
    }
    
    // AUTO-DETECT - Uses best path based on calling thread
    SendResult send(MessageType type, const void* payload, size_t len) noexcept override {
        // Check if we're on the poll thread
        if (std::this_thread::get_id() == poll_thread_id_) [[likely]] {
            return send_immediate(type, payload, len);
        }
        return send_async(type, payload, len);
    }
    
    // Convenience wrappers
    SendResult send_order(const void* payload, size_t len) noexcept override {
        return send(MessageType::NEW_ORDER, payload, len);
    }
    
    SendResult send_cancel(const void* payload, size_t len) noexcept override {
        return send(MessageType::CANCEL_ORDER, payload, len);
    }
    
    // =========================================================================
    // Polling
    // =========================================================================
    
    void poll() noexcept override {
        // 1. Drain async send queue
        drain_async_queue();
        
        // 2. Poll transport
        if (transport_) {
            transport_->poll();
        }
        
        // 3. Receive and process messages
        process_received_data();
        
        // 4. Handle heartbeat
        if (config_.heartbeat.enabled) {
            handle_heartbeat();
        }
        
        // 5. Handle reconnection
        if (is_reconnecting_) {
            handle_reconnect();
        }
    }
    
    // =========================================================================
    // Info
    // =========================================================================
    
    const EndpointConfig& current_endpoint() const noexcept override {
        return current_endpoint_;
    }
    
    ITransport* transport() noexcept override { return transport_.get(); }
    
    const char* transport_name() const noexcept override {
        return transport_ ? transport_->name() : "none";
    }
    
    // =========================================================================
    // Stats
    // =========================================================================
    
    const SessionStats& stats() const noexcept override { return stats_; }
    const LatencyStats& latency_stats() const noexcept override { return latency_stats_; }
    
    void reset_stats() noexcept override {
        stats_.reset();
        latency_stats_.reset();
    }
    
    void enable_stats(bool enable) noexcept override {
        stats_enabled_ = enable;
    }
    
    // =========================================================================
    // Callbacks
    // =========================================================================
    
    void set_callbacks(SessionCallbacks callbacks) noexcept override {
        callbacks_ = std::move(callbacks);
    }
    
    // =========================================================================
    // Sequence
    // =========================================================================
    
    uint32_t next_send_sequence() const noexcept override {
        return send_sequence_;
    }
    
    uint32_t last_recv_sequence() const noexcept override {
        return recv_sequence_;
    }

private:
    // =========================================================================
    // Internal helpers
    // =========================================================================
    
    void drain_async_queue() noexcept {
        async_queue_.drain([this](const SendRequest& req) {
            if (transport_ && state_.load(std::memory_order_relaxed) == SessionState::CONNECTED) {
                transport_->send(req.payload, req.len);
                
                if (stats_enabled_) {
                    stats_.messages_sent.fetch_add(1, std::memory_order_relaxed);
                    stats_.bytes_sent.fetch_add(req.len, std::memory_order_relaxed);
                }
            }
        });
    }
    
    void process_received_data() noexcept {
        if (!transport_) return;
        
        ssize_t n = transport_->recv(recv_buf_ + recv_buf_pos_, RECV_BUF_SIZE - recv_buf_pos_);
        if (n > 0) {
            recv_buf_pos_ += static_cast<size_t>(n);
            
            // Process complete messages
            while (recv_buf_pos_ >= sizeof(MessageHeader)) {
                auto* header = reinterpret_cast<const MessageHeader*>(recv_buf_);
                
                if (header->length < sizeof(MessageHeader) ||
                    header->length > Config::MAX_MESSAGE_SIZE) {
                    // Invalid message
                    recv_buf_pos_ = 0;
                    break;
                }
                
                if (recv_buf_pos_ < header->length) {
                    break;  // Incomplete message
                }
                
                // Process message
                process_message(*header, recv_buf_ + sizeof(MessageHeader),
                               header->length - sizeof(MessageHeader));
                
                // Shift buffer
                size_t remaining = recv_buf_pos_ - header->length;
                if (remaining > 0) {
                    std::memmove(recv_buf_, recv_buf_ + header->length, remaining);
                }
                recv_buf_pos_ = remaining;
            }
        } else if (n < 0 && errno != EAGAIN && errno != EWOULDBLOCK) {
            handle_disconnect(DisconnectReason::READ_ERROR);
        }
    }
    
    void process_message(const MessageHeader& hdr, const uint8_t* payload, size_t len) noexcept {
        if (stats_enabled_) {
            stats_.messages_received.fetch_add(1, std::memory_order_relaxed);
            stats_.bytes_received.fetch_add(sizeof(MessageHeader) + len, std::memory_order_relaxed);
            
            // Record latency from HW timestamps
            auto rx_ts = transport_->get_last_rx_timestamp();
            if (rx_ts.valid && hdr.timestamp_ns > 0) {
                // One-way latency estimate
                uint64_t now = Timestamp::now_ns();
                if (now > hdr.timestamp_ns) {
                    latency_stats_.record_oneway(now - hdr.timestamp_ns, rx_ts.is_hw);
                }
            }
        }
        
        // Check sequence
        if (recv_sequence_ > 0 && hdr.sequence_number != recv_sequence_ + 1) {
            if (callbacks_.on_sequence_gap) {
                callbacks_.on_sequence_gap(*this, recv_sequence_ + 1, hdr.sequence_number);
            }
        }
        recv_sequence_ = hdr.sequence_number;
        
        // Handle heartbeat internally
        if (hdr.type == MessageType::HEARTBEAT_REQUEST) {
            send_immediate(MessageType::HEARTBEAT_RESPONSE, nullptr, 0);
            last_hb_recv_ns_ = Timestamp::now_ns();
            return;
        }
        
        if (hdr.type == MessageType::HEARTBEAT_RESPONSE) {
            last_hb_recv_ns_ = Timestamp::now_ns();
            return;
        }
        
        // Invoke callback
        if (callbacks_.on_message) {
            callbacks_.on_message(*this, hdr, payload, len);
        }
    }
    
    void handle_heartbeat() noexcept {
        uint64_t now = Timestamp::now_ns();
        
        // Check timeout based on last receive
        if (last_hb_recv_ns_ > 0 && 
            now - last_hb_recv_ns_ > config_.heartbeat.timeout_ns) {
            handle_disconnect(DisconnectReason::HEARTBEAT_TIMEOUT);
            return;
        }
        
        // Send heartbeat only if idle (no recent app sends or receives)
        // This avoids unnecessary heartbeat traffic when connection is active
        uint64_t last_activity = std::max(last_send_ns_, last_hb_recv_ns_);
        if (now - last_activity > config_.heartbeat.interval_ns) {
            send_immediate(MessageType::HEARTBEAT_REQUEST, nullptr, 0);
            last_hb_sent_ns_ = now;
        }
    }
    
    void handle_reconnect() noexcept {
        uint64_t now = Timestamp::now_ns();
        if (now < next_reconnect_time_ns_) return;
        
        if (connect_to_endpoint(current_endpoint_)) {
            is_reconnecting_ = false;
            reconnect_attempts_ = 0;
        } else {
            schedule_reconnect();
        }
    }
    
    void handle_disconnect(DisconnectReason reason) noexcept {
        if (transport_) {
            transport_->disconnect();
        }
        
        set_state(SessionState::DISCONNECTED);
        
        if (stats_enabled_) {
            stats_.disconnect_count.fetch_add(1, std::memory_order_relaxed);
        }
        
        if (callbacks_.on_disconnect) {
            callbacks_.on_disconnect(*this, reason);
        }
        
        // Schedule reconnect if enabled
        if (config_.reconnect.enabled) {
            schedule_reconnect();
        }
    }
    
    void schedule_reconnect() noexcept {
        if (config_.reconnect.max_attempts > 0 && 
            reconnect_attempts_ >= config_.reconnect.max_attempts) {
            set_state(SessionState::ERROR);
            return;
        }
        
        // Calculate delay with exponential backoff
        uint64_t delay = config_.reconnect.initial_delay_ns;
        for (uint32_t i = 0; i < reconnect_attempts_ && delay < config_.reconnect.max_delay_ns; ++i) {
            delay = static_cast<uint64_t>(static_cast<double>(delay) * config_.reconnect.backoff_multiplier);
        }
        delay = std::min(delay, config_.reconnect.max_delay_ns);
        
        next_reconnect_time_ns_ = Timestamp::now_ns() + delay;
        is_reconnecting_ = true;
        ++reconnect_attempts_;
        
        if (stats_enabled_) {
            stats_.reconnect_count.fetch_add(1, std::memory_order_relaxed);
        }
    }
    
    bool connect_to_endpoint(const EndpointConfig& ep) noexcept {
        TransportConfig tc;
        tc.host = ep.host;
        tc.port = ep.port;
        tc.interface = ep.interface;
        tc.type = config_.transport_type;
        tc.tcp_nodelay = config_.tcp_nodelay;
        tc.send_buffer_size = config_.send_buffer_size;
        tc.recv_buffer_size = config_.recv_buffer_size;
        tc.enable_hw_timestamps = config_.enable_hw_timestamps;
        
        transport_ = TransportFactory::create(tc);
        if (!transport_ || !transport_->connect()) {
            return false;
        }
        
        set_state(SessionState::CONNECTED);
        current_endpoint_ = ep;
        
        if (stats_enabled_) {
            stats_.connect_count.fetch_add(1, std::memory_order_relaxed);
        }
        
        if (callbacks_.on_connect) {
            callbacks_.on_connect(*this);
        }
        
        return true;
    }
    
    void set_state(SessionState new_state) noexcept {
        SessionState old = state_.exchange(new_state, std::memory_order_acq_rel);
        if (old != new_state && callbacks_.on_state_change) {
            callbacks_.on_state_change(*this, old, new_state);
        }
    }
    
    // =========================================================================
    // Data members
    // =========================================================================
    
    // Cache line 1: Hot send path
    alignas(64) struct {
        std::unique_ptr<ITransport> transport_;
        std::atomic<SessionState> state_{SessionState::DISCONNECTED};
        uint32_t send_sequence_;
        uint32_t recv_sequence_;
        std::thread::id poll_thread_id_;
        bool stats_enabled_;
    } hot_;
    
    // Use references for cleaner access
    std::unique_ptr<ITransport>& transport_ = hot_.transport_;
    std::atomic<SessionState>& state_ = hot_.state_;
    uint32_t& send_sequence_ = hot_.send_sequence_;
    uint32_t& recv_sequence_ = hot_.recv_sequence_;
    std::thread::id& poll_thread_id_ = hot_.poll_thread_id_;
    bool& stats_enabled_ = hot_.stats_enabled_;
    
    // Async send queue
    alignas(64) MPSCQueue<4096> async_queue_;
    
    // Cold data
    alignas(64) struct {
        SessionConfig config_;
        SessionCallbacks callbacks_;
        SessionStats stats_;
        LatencyStats latency_stats_;
        EndpointConfig current_endpoint_;
        PollThread* poll_thread_ = nullptr;
        
        // Receive buffer
        uint8_t recv_buf_[65536];
        size_t recv_buf_pos_ = 0;
        
        // Heartbeat
        uint64_t last_hb_sent_ns_ = 0;
        uint64_t last_hb_recv_ns_ = 0;
        uint64_t last_send_ns_ = 0;  // Track last app send for idle detection
        
        // Reconnection
        uint32_t reconnect_attempts_ = 0;
        uint64_t next_reconnect_time_ns_ = 0;
        bool is_reconnecting_ = false;
    } cold_;
    
    // References to cold data
    const SessionConfig& config_ = cold_.config_;
    SessionCallbacks& callbacks_ = cold_.callbacks_;
    SessionStats& stats_ = cold_.stats_;
    LatencyStats& latency_stats_ = cold_.latency_stats_;
    EndpointConfig& current_endpoint_ = cold_.current_endpoint_;
    PollThread*& poll_thread_ = cold_.poll_thread_;
    uint8_t* recv_buf_ = cold_.recv_buf_;
    size_t& recv_buf_pos_ = cold_.recv_buf_pos_;
    uint64_t& last_hb_sent_ns_ = cold_.last_hb_sent_ns_;
    uint64_t& last_hb_recv_ns_ = cold_.last_hb_recv_ns_;
    uint64_t& last_send_ns_ = cold_.last_send_ns_;
    uint32_t& reconnect_attempts_ = cold_.reconnect_attempts_;
    uint64_t& next_reconnect_time_ns_ = cold_.next_reconnect_time_ns_;
    bool& is_reconnecting_ = cold_.is_reconnecting_;
    
    static constexpr size_t RECV_BUF_SIZE = 65536;
};

// =============================================================================
// Session Implementation
// =============================================================================

inline Session::Session(const SessionConfig& config) {
    cold_.config_ = config;
    hot_.send_sequence_ = config.initial_sequence;
    hot_.recv_sequence_ = 0;
    hot_.stats_enabled_ = config.enable_stats;
}

inline Session::~Session() {
    stop();
}

inline bool Session::start() {
    SessionState expected = SessionState::DISCONNECTED;
    if (!state_.compare_exchange_strong(expected, SessionState::CONNECTING,
                                         std::memory_order_acq_rel)) {
        return false;
    }
    
    // Record poll thread ID for send() auto-detection
    poll_thread_id_ = std::this_thread::get_id();
    
    // Bind to poll thread if using thread registry
    if (config_.thread_name) {
        poll_thread_ = ThreadRegistry::instance().get_thread(*config_.thread_name);
        if (!poll_thread_) {
            state_.store(SessionState::ERROR, std::memory_order_release);
            if (callbacks_.on_error) {
                callbacks_.on_error(*this, "Named thread not found: " + *config_.thread_name);
            }
            return false;
        }
        poll_thread_->bind_session(this);
        poll_thread_id_ = std::thread::id();  // Will be set when thread starts
    }
    
    // Connect
    current_endpoint_ = config_.primary;
    return connect_to_endpoint(current_endpoint_);
}

inline void Session::stop() noexcept {
    SessionState current = state_.load(std::memory_order_acquire);
    if (current == SessionState::DISCONNECTED) return;
    
    state_.store(SessionState::DRAINING, std::memory_order_release);
    
    // Drain async queue
    drain_async_queue();
    
    // Unbind from poll thread
    if (poll_thread_) {
        poll_thread_->unbind_session(this);
        poll_thread_ = nullptr;
    }
    
    // Disconnect transport
    if (transport_) {
        transport_->disconnect();
        transport_.reset();
    }
    
    // Reset state
    is_reconnecting_ = false;
    reconnect_attempts_ = 0;
    cold_.recv_buf_pos_ = 0;
    
    state_.store(SessionState::DISCONNECTED, std::memory_order_release);
}

// =============================================================================
// Session Builder
// =============================================================================

class SessionBuilder {
public:
    explicit SessionBuilder(const std::string& name) { config_.name = name; }
    
    SessionBuilder& as_initiator() { config_.type = SessionType::INITIATOR; return *this; }
    SessionBuilder& as_acceptor() { config_.type = SessionType::ACCEPTOR; return *this; }
    
    SessionBuilder& transport(TransportType t) { config_.transport_type = t; return *this; }
    SessionBuilder& tcpdirect() { config_.transport_type = TransportType::TCPDIRECT; return *this; }
    SessionBuilder& onload() { config_.transport_type = TransportType::ONLOAD; return *this; }
    
    SessionBuilder& connect_to(const std::string& host, uint16_t port) {
        config_.primary.host = host;
        config_.primary.port = port;
        return *this;
    }
    
    SessionBuilder& interface(const std::string& iface) {
        config_.primary.interface = iface;
        return *this;
    }
    
    SessionBuilder& thread(const std::string& name) {
        config_.thread_name = name;
        return *this;
    }
    
    SessionBuilder& failover(const std::string& host, uint16_t port) {
        config_.failover = EndpointConfig{host, port, ""};
        return *this;
    }
    
    SessionBuilder& heartbeat(uint64_t interval_ms, uint64_t timeout_ms) {
        config_.heartbeat.enabled = true;
        config_.heartbeat.interval_ns = interval_ms * 1'000'000;
        config_.heartbeat.timeout_ns = timeout_ms * 1'000'000;
        return *this;
    }
    
    SessionBuilder& no_heartbeat() {
        config_.heartbeat.enabled = false;
        return *this;
    }
    
    SessionBuilder& reconnect(uint64_t init_ms, uint64_t max_ms, uint32_t max_attempts = 0) {
        config_.reconnect.enabled = true;
        config_.reconnect.initial_delay_ns = init_ms * 1'000'000;
        config_.reconnect.max_delay_ns = max_ms * 1'000'000;
        config_.reconnect.max_attempts = max_attempts;
        return *this;
    }
    
    SessionBuilder& no_reconnect() {
        config_.reconnect.enabled = false;
        return *this;
    }
    
    SessionBuilder& stats(bool enable) {
        config_.enable_stats = enable;
        return *this;
    }
    
    SessionBuilder& hw_timestamps(bool enable) {
        config_.enable_hw_timestamps = enable;
        return *this;
    }
    
    bool is_valid() const { return config_.is_valid(); }
    std::string validation_error() const { return config_.validation_error(); }
    
    SessionConfig build() const { return config_; }
    
    std::unique_ptr<Session> create() const {
        if (!config_.is_valid()) return nullptr;
        return std::make_unique<Session>(config_);
    }
    
private:
    SessionConfig config_;
};

// Convenience function
inline SessionBuilder session(const std::string& name) {
    return SessionBuilder(name);
}

} // namespace ptpx
