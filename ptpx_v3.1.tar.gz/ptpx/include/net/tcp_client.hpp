#pragma once

#include "../core/common.hpp"
#include "../core/timer_wheel.hpp"
#include "tcp_session.hpp"

#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <fcntl.h>
#include <poll.h>
#include <errno.h>
#include <cstring>
#include <string>
#include <functional>

namespace ptpx {

// =============================================================================
// Client Configuration
// =============================================================================

struct ClientConfig {
    std::string host = "127.0.0.1";
    uint16_t port = 9000;
    
    // Connection settings
    uint32_t connect_timeout_ms = 5000;
    uint32_t reconnect_delay_ms = 1000;
    uint32_t max_reconnect_attempts = 10;  // 0 = infinite
    bool auto_reconnect = true;
    
    // Socket options
    SocketOptions socket_opts = SocketOptions::low_latency();
    
    // Heartbeat settings (client-initiated)
    bool send_heartbeats = true;
    uint64_t heartbeat_interval_ns = Config::HEARTBEAT_INTERVAL_NS;
    uint64_t heartbeat_timeout_ns = Config::HEARTBEAT_TIMEOUT_NS;
};

// =============================================================================
// Client State
// =============================================================================

enum class ClientState : uint8_t {
    DISCONNECTED = 0,
    CONNECTING,
    CONNECTED,
    RECONNECTING,
    FAILED          // Max reconnects exceeded
};

// =============================================================================
// TCP Client (Initiator)
// =============================================================================

class TCPClient {
public:
    using MessageHandler = std::function<void(const MessageHeader&, const uint8_t*)>;
    using StateHandler = std::function<void(ClientState, ClientState)>;  // old, new
    using HeartbeatHandler = std::function<void(uint64_t rtt_ns)>;
    
    TCPClient() noexcept 
        : fd_(-1)
        , state_(ClientState::DISCONNECTED)
        , send_sequence_(0)
        , recv_sequence_(0)
        , reconnect_attempts_(0)
        , last_send_tsc_(0)
        , last_recv_tsc_(0)
        , last_heartbeat_tsc_(0)
        , heartbeat_pending_(false)
        , heartbeat_send_tsc_(0)
    {}
    
    ~TCPClient() {
        disconnect();
    }
    
    // Non-copyable
    TCPClient(const TCPClient&) = delete;
    TCPClient& operator=(const TCPClient&) = delete;
    
    // ==========================================================================
    // Configuration & Handlers
    // ==========================================================================
    
    void configure(const ClientConfig& config) {
        config_ = config;
    }
    
    void set_message_handler(MessageHandler handler) { on_message_ = std::move(handler); }
    void set_state_handler(StateHandler handler) { on_state_change_ = std::move(handler); }
    void set_heartbeat_handler(HeartbeatHandler handler) { on_heartbeat_ = std::move(handler); }
    
    // ==========================================================================
    // Connection Management
    // ==========================================================================
    
    // Initiate connection (non-blocking)
    COLD_PATH bool connect() {
        if (state_ == ClientState::CONNECTED || state_ == ClientState::CONNECTING) {
            return true;
        }
        
        return initiate_connect();
    }
    
    // Blocking connect with timeout
    COLD_PATH bool connect_sync() {
        if (!connect()) {
            return false;
        }
        
        // Wait for connection to complete
        uint64_t start = Timestamp::now_ns();
        uint64_t timeout_ns = config_.connect_timeout_ms * 1'000'000ULL;
        
        while (state_ == ClientState::CONNECTING) {
            poll_once();
            
            if (Timestamp::now_ns() - start > timeout_ns) {
                disconnect();
                return false;
            }
            
            _mm_pause();  // Reduce CPU spinning
        }
        
        return state_ == ClientState::CONNECTED;
    }
    
    void disconnect() {
        if (fd_ >= 0) {
            ::close(fd_);
            fd_ = -1;
        }
        
        set_state(ClientState::DISCONNECTED);
        recv_buffer_.reset();
        send_buffer_.reset();
        heartbeat_pending_ = false;
    }
    
    // ==========================================================================
    // Main Poll Loop - Hot Path
    // ==========================================================================
    
    // Call this repeatedly from your event loop
    HOT_PATH int poll_once() {
        switch (state_) {
            case ClientState::CONNECTING:
                return poll_connecting();
                
            case ClientState::CONNECTED:
                return poll_connected();
                
            case ClientState::RECONNECTING:
                return poll_reconnecting();
                
            default:
                return 0;
        }
    }
    
    // Blocking poll with timeout
    HOT_PATH int poll(int timeout_ms = 0) {
        if (state_ != ClientState::CONNECTED && state_ != ClientState::CONNECTING) {
            return -1;
        }
        
        pollfd pfd{};
        pfd.fd = fd_;
        pfd.events = POLLIN;
        
        if (send_buffer_.readable() > 0) {
            pfd.events |= POLLOUT;
        }
        
        int ret = ::poll(&pfd, 1, timeout_ms);
        
        if (ret > 0) {
            if (pfd.revents & (POLLERR | POLLHUP | POLLNVAL)) {
                handle_disconnect();
                return -1;
            }
            
            if (pfd.revents & POLLIN) {
                return recv_and_process();
            }
            
            if (pfd.revents & POLLOUT) {
                flush();
            }
        }
        
        // Check heartbeat
        check_heartbeat();
        
        return 0;
    }
    
    // ==========================================================================
    // Sending Messages - Hot Path
    // ==========================================================================
    
    HOT_PATH SendResult send(MessageType type, const uint8_t* payload, size_t len) {
        if (UNLIKELY(state_ != ClientState::CONNECTED)) {
            return SendResult::DISCONNECTED;
        }
        
        size_t total_len = MessageHeader::SIZE + len;
        
        if (UNLIKELY(total_len > Config::MAX_MESSAGE_SIZE)) {
            return SendResult::ERROR;
        }
        
        if (UNLIKELY(send_buffer_.writable() < total_len)) {
            flush();
            if (send_buffer_.writable() < total_len) {
                return SendResult::BUFFER_FULL;
            }
        }
        
        // Build header
        MessageHeader* header = reinterpret_cast<MessageHeader*>(send_buffer_.write_ptr());
        header->length = static_cast<uint32_t>(total_len);
        header->sequence_number = ++send_sequence_;
        header->timestamp_ns = Timestamp::now_tsc();
        header->type = type;
        header->flags = 0;
        header->reserved = 0;
        
        // Copy payload
        if (len > 0 && payload != nullptr) {
            std::memcpy(send_buffer_.write_ptr() + MessageHeader::SIZE, payload, len);
        }
        
        send_buffer_.advance_write(total_len);
        last_send_tsc_ = Timestamp::now_tsc();
        
        // Immediate flush for latency
        return flush();
    }
    
    // Convenience methods for order messages
    HOT_PATH SendResult send_new_order(const uint8_t* payload, size_t len) {
        return send(MessageType::NEW_ORDER, payload, len);
    }
    
    HOT_PATH SendResult send_cancel_order(const uint8_t* payload, size_t len) {
        return send(MessageType::CANCEL_ORDER, payload, len);
    }
    
    HOT_PATH SendResult send_modify_order(const uint8_t* payload, size_t len) {
        return send(MessageType::MODIFY_ORDER, payload, len);
    }
    
    // Flush send buffer
    HOT_PATH SendResult flush() {
        if (send_buffer_.readable() == 0 || fd_ < 0) {
            return SendResult::SUCCESS;
        }
        
        ssize_t n = ::send(fd_, send_buffer_.read_ptr(), send_buffer_.readable(),
                           MSG_DONTWAIT | MSG_NOSIGNAL);
        
        if (n > 0) {
            send_buffer_.advance_read(static_cast<size_t>(n));
            if (send_buffer_.readable() == 0) {
                send_buffer_.reset();
            }
            return SendResult::SUCCESS;
        } else if (errno == EAGAIN || errno == EWOULDBLOCK) {
            return SendResult::WOULD_BLOCK;
        } else {
            handle_disconnect();
            return SendResult::ERROR;
        }
    }
    
    // ==========================================================================
    // Accessors
    // ==========================================================================
    
    ClientState state() const noexcept { return state_; }
    bool is_connected() const noexcept { return state_ == ClientState::CONNECTED; }
    int fd() const noexcept { return fd_; }
    uint32_t send_sequence() const noexcept { return send_sequence_; }
    uint32_t recv_sequence() const noexcept { return recv_sequence_; }
    uint64_t last_rtt_ns() const noexcept { return last_rtt_ns_; }
    
    // Stats
    struct Stats {
        uint64_t messages_sent;
        uint64_t messages_received;
        uint64_t bytes_sent;
        uint64_t bytes_received;
        uint64_t heartbeats_sent;
        uint64_t heartbeats_received;
        uint64_t reconnect_count;
        uint64_t last_rtt_ns;
        uint64_t min_rtt_ns;
        uint64_t max_rtt_ns;
    };
    
    Stats get_stats() const noexcept { return stats_; }
    void reset_stats() noexcept { std::memset(&stats_, 0, sizeof(stats_)); }
    
private:
    // ==========================================================================
    // Connection Handling
    // ==========================================================================
    
    bool initiate_connect() {
        // Resolve address
        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(config_.port);
        
        if (inet_pton(AF_INET, config_.host.c_str(), &addr.sin_addr) != 1) {
            // Try DNS resolution
            struct addrinfo hints{}, *result;
            hints.ai_family = AF_INET;
            hints.ai_socktype = SOCK_STREAM;
            
            if (getaddrinfo(config_.host.c_str(), nullptr, &hints, &result) != 0) {
                return false;
            }
            
            addr.sin_addr = reinterpret_cast<sockaddr_in*>(result->ai_addr)->sin_addr;
            freeaddrinfo(result);
        }
        
        // Create socket
        fd_ = socket(AF_INET, SOCK_STREAM | SOCK_NONBLOCK | SOCK_CLOEXEC, 0);
        if (fd_ < 0) {
            return false;
        }
        
        // Configure socket
        configure_socket(fd_, config_.socket_opts);
        
        // Initiate connection
        int ret = ::connect(fd_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr));
        
        if (ret == 0) {
            // Immediate connection (unlikely for TCP)
            set_state(ClientState::CONNECTED);
            on_connected();
            return true;
        } else if (errno == EINPROGRESS) {
            // Connection in progress
            set_state(ClientState::CONNECTING);
            connect_start_tsc_ = Timestamp::now_tsc();
            return true;
        } else {
            ::close(fd_);
            fd_ = -1;
            return false;
        }
    }
    
    int poll_connecting() {
        // Check if connection completed
        pollfd pfd{};
        pfd.fd = fd_;
        pfd.events = POLLOUT;
        
        int ret = ::poll(&pfd, 1, 0);
        
        if (ret > 0) {
            if (pfd.revents & (POLLERR | POLLHUP)) {
                handle_connect_failure();
                return -1;
            }
            
            if (pfd.revents & POLLOUT) {
                // Check for actual connection success
                int error = 0;
                socklen_t len = sizeof(error);
                getsockopt(fd_, SOL_SOCKET, SO_ERROR, &error, &len);
                
                if (error == 0) {
                    set_state(ClientState::CONNECTED);
                    on_connected();
                    return 0;
                } else {
                    handle_connect_failure();
                    return -1;
                }
            }
        }
        
        // Check timeout
        uint64_t elapsed_ns = Timestamp::tsc_to_ns(Timestamp::now_tsc() - connect_start_tsc_);
        if (elapsed_ns > config_.connect_timeout_ms * 1'000'000ULL) {
            handle_connect_failure();
            return -1;
        }
        
        return 0;
    }
    
    int poll_connected() {
        int messages = recv_and_process();
        check_heartbeat();
        return messages;
    }
    
    int poll_reconnecting() {
        uint64_t elapsed_ns = Timestamp::tsc_to_ns(Timestamp::now_tsc() - reconnect_start_tsc_);
        
        if (elapsed_ns >= config_.reconnect_delay_ms * 1'000'000ULL) {
            ++reconnect_attempts_;
            
            if (config_.max_reconnect_attempts > 0 && 
                reconnect_attempts_ >= config_.max_reconnect_attempts) {
                set_state(ClientState::FAILED);
                return -1;
            }
            
            initiate_connect();
            ++stats_.reconnect_count;
        }
        
        return 0;
    }
    
    void on_connected() {
        recv_buffer_.reset();
        send_buffer_.reset();
        send_sequence_ = 0;
        recv_sequence_ = 0;
        reconnect_attempts_ = 0;
        heartbeat_pending_ = false;
        last_recv_tsc_ = Timestamp::now_tsc();
        last_send_tsc_ = last_recv_tsc_;
        last_heartbeat_tsc_ = last_recv_tsc_;
    }
    
    void handle_connect_failure() {
        if (fd_ >= 0) {
            ::close(fd_);
            fd_ = -1;
        }
        
        if (config_.auto_reconnect) {
            set_state(ClientState::RECONNECTING);
            reconnect_start_tsc_ = Timestamp::now_tsc();
        } else {
            set_state(ClientState::FAILED);
        }
    }
    
    void handle_disconnect() {
        if (fd_ >= 0) {
            ::close(fd_);
            fd_ = -1;
        }
        
        if (config_.auto_reconnect && state_ == ClientState::CONNECTED) {
            set_state(ClientState::RECONNECTING);
            reconnect_start_tsc_ = Timestamp::now_tsc();
        } else {
            set_state(ClientState::DISCONNECTED);
        }
    }
    
    void set_state(ClientState new_state) {
        if (state_ != new_state) {
            ClientState old_state = state_;
            state_ = new_state;
            
            if (on_state_change_) {
                on_state_change_(old_state, new_state);
            }
        }
    }
    
    // ==========================================================================
    // Receive Processing
    // ==========================================================================
    
    HOT_PATH int recv_and_process() {
        if (recv_buffer_.writable() < 4096) {
            recv_buffer_.compact();
        }
        
        ssize_t n = ::recv(fd_, recv_buffer_.write_ptr(), recv_buffer_.writable(), MSG_DONTWAIT);
        
        if (n > 0) {
            recv_buffer_.advance_write(static_cast<size_t>(n));
            last_recv_tsc_ = Timestamp::now_tsc();
            stats_.bytes_received += n;
            
            return process_messages();
        } else if (n == 0) {
            handle_disconnect();
            return -1;
        } else if (errno != EAGAIN && errno != EWOULDBLOCK) {
            handle_disconnect();
            return -1;
        }
        
        return 0;
    }
    
    HOT_PATH int process_messages() {
        int count = 0;
        
        while (recv_buffer_.readable() >= MessageHeader::SIZE) {
            const MessageHeader* header = reinterpret_cast<const MessageHeader*>(
                recv_buffer_.read_ptr());
            
            if (UNLIKELY(header->length < MessageHeader::SIZE ||
                         header->length > Config::MAX_MESSAGE_SIZE)) {
                handle_disconnect();
                return -1;
            }
            
            if (recv_buffer_.readable() < header->length) {
                break;
            }
            
            const uint8_t* payload = recv_buffer_.read_ptr() + MessageHeader::SIZE;
            
            // Handle heartbeats internally
            if (header->type == MessageType::HEARTBEAT_REQUEST) {
                send_heartbeat_response();
            } else if (header->type == MessageType::HEARTBEAT_RESPONSE) {
                handle_heartbeat_response(header);
            } else {
                // Dispatch to user handler
                if (on_message_) {
                    on_message_(*header, payload);
                }
            }
            
            recv_buffer_.advance_read(header->length);
            ++count;
            ++stats_.messages_received;
        }
        
        return count;
    }
    
    // ==========================================================================
    // Heartbeat Handling
    // ==========================================================================
    
    void check_heartbeat() {
        if (!config_.send_heartbeats || state_ != ClientState::CONNECTED) {
            return;
        }
        
        uint64_t now = Timestamp::now_tsc();
        uint64_t idle_ns = Timestamp::tsc_to_ns(now - std::max(last_send_tsc_, last_recv_tsc_));
        
        // Check timeout first
        if (heartbeat_pending_) {
            uint64_t pending_ns = Timestamp::tsc_to_ns(now - heartbeat_send_tsc_);
            if (pending_ns > config_.heartbeat_timeout_ns) {
                // Heartbeat timeout - connection dead
                handle_disconnect();
                return;
            }
        }
        
        // Send heartbeat if idle
        if (idle_ns >= config_.heartbeat_interval_ns && !heartbeat_pending_) {
            send_heartbeat();
        }
    }
    
    void send_heartbeat() {
        if (send(MessageType::HEARTBEAT_REQUEST, nullptr, 0) == SendResult::SUCCESS) {
            heartbeat_pending_ = true;
            heartbeat_send_tsc_ = Timestamp::now_tsc();
            ++stats_.heartbeats_sent;
        }
    }
    
    void send_heartbeat_response() {
        send(MessageType::HEARTBEAT_RESPONSE, nullptr, 0);
    }
    
    void handle_heartbeat_response(const MessageHeader* header) {
        if (heartbeat_pending_) {
            uint64_t rtt_tsc = Timestamp::now_tsc() - heartbeat_send_tsc_;
            last_rtt_ns_ = Timestamp::tsc_to_ns(rtt_tsc);
            
            stats_.last_rtt_ns = last_rtt_ns_;
            if (last_rtt_ns_ < stats_.min_rtt_ns || stats_.min_rtt_ns == 0) {
                stats_.min_rtt_ns = last_rtt_ns_;
            }
            if (last_rtt_ns_ > stats_.max_rtt_ns) {
                stats_.max_rtt_ns = last_rtt_ns_;
            }
            
            heartbeat_pending_ = false;
            ++stats_.heartbeats_received;
            
            if (on_heartbeat_) {
                on_heartbeat_(last_rtt_ns_);
            }
        }
    }
    
    // ==========================================================================
    // Member Variables
    // ==========================================================================
    
    // Configuration
    ClientConfig config_;
    
    // Connection state
    int fd_;
    ClientState state_;
    uint32_t send_sequence_;
    uint32_t recv_sequence_;
    uint32_t reconnect_attempts_;
    
    // Timestamps (TSC)
    uint64_t last_send_tsc_;
    uint64_t last_recv_tsc_;
    uint64_t last_heartbeat_tsc_;
    uint64_t connect_start_tsc_;
    uint64_t reconnect_start_tsc_;
    
    // Heartbeat state
    bool heartbeat_pending_;
    uint64_t heartbeat_send_tsc_;
    uint64_t last_rtt_ns_;
    
    // Buffers
    PreallocatedBuffer<Config::RECV_BUFFER_SIZE> recv_buffer_;
    PreallocatedBuffer<Config::SEND_BUFFER_SIZE> send_buffer_;
    
    // Stats
    Stats stats_{};
    
    // Handlers
    MessageHandler on_message_;
    StateHandler on_state_change_;
    HeartbeatHandler on_heartbeat_;
};

} // namespace ptpx
