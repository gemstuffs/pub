#pragma once

#include "tcp_session.hpp"
#include "../core/timer_wheel.hpp"

#include <sys/epoll.h>
#include <array>
#include <vector>
#include <memory>
#include <functional>

namespace ptpx {

// =============================================================================
// Connection Monitor - Track health metrics (cold path)
// =============================================================================

struct ConnectionStats {
    uint64_t messages_sent;
    uint64_t messages_received;
    uint64_t bytes_sent;
    uint64_t bytes_received;
    uint64_t heartbeats_sent;
    uint64_t heartbeats_missed;
    uint64_t connect_time_tsc;
    uint64_t last_latency_ns;
    uint64_t min_latency_ns;
    uint64_t max_latency_ns;
    uint64_t sum_latency_ns;
    uint64_t latency_samples;
    
    ConnectionStats() noexcept { reset(); }
    
    void reset() noexcept {
        messages_sent = 0;
        messages_received = 0;
        bytes_sent = 0;
        bytes_received = 0;
        heartbeats_sent = 0;
        heartbeats_missed = 0;
        connect_time_tsc = 0;
        last_latency_ns = 0;
        min_latency_ns = UINT64_MAX;
        max_latency_ns = 0;
        sum_latency_ns = 0;
        latency_samples = 0;
    }
    
    FORCE_INLINE void record_latency(uint64_t latency_ns) noexcept {
        last_latency_ns = latency_ns;
        min_latency_ns = std::min(min_latency_ns, latency_ns);
        max_latency_ns = std::max(max_latency_ns, latency_ns);
        sum_latency_ns += latency_ns;
        ++latency_samples;
    }
    
    FORCE_INLINE uint64_t avg_latency_ns() const noexcept {
        return latency_samples > 0 ? sum_latency_ns / latency_samples : 0;
    }
};

// =============================================================================
// TCP Server Configuration
// =============================================================================

struct ServerConfig {
    uint16_t port = 9000;
    const char* bind_address = "0.0.0.0";
    size_t max_sessions = Config::MAX_SESSIONS;
    int listen_backlog = 128;
    SocketOptions socket_opts = SocketOptions::low_latency();
    
    // Event loop tuning
    int epoll_timeout_ms = 0;        // 0 = busy poll
    size_t max_events_per_poll = 64;
    
    // CPU affinity (optional)
    int acceptor_cpu = -1;   // -1 = no affinity
};

// =============================================================================
// TCP Server with epoll
// =============================================================================

class TCPServer {
public:
    using MessageHandler = std::function<void(TCPSession&, const MessageHeader&, const uint8_t*)>;
    using ConnectHandler = std::function<void(TCPSession&)>;
    using DisconnectHandler = std::function<void(TCPSession&)>;
    using HeartbeatTimeoutHandler = std::function<void(TCPSession&)>;
    
    TCPServer() noexcept 
        : listen_fd_(-1)
        , epoll_fd_(-1)
        , running_(false)
        , next_session_id_(1)
    {}
    
    ~TCPServer() noexcept {
        stop();
    }
    
    // Non-copyable, non-movable
    TCPServer(const TCPServer&) = delete;
    TCPServer& operator=(const TCPServer&) = delete;
    
    // ==========================================================================
    // Initialization
    // ==========================================================================
    
    COLD_PATH bool initialize(const ServerConfig& config) {
        config_ = config;
        
        // Calibrate timing
        Timestamp::calibrate();
        
        // Initialize heartbeat manager
        heartbeat_manager_.initialize(config.max_sessions);
        
        // Pre-allocate sessions
        sessions_.resize(config.max_sessions);
        session_stats_.resize(config.max_sessions);
        active_sessions_.reserve(config.max_sessions);
        
        // Create epoll instance
        epoll_fd_ = epoll_create1(EPOLL_CLOEXEC);
        if (epoll_fd_ < 0) {
            return false;
        }
        
        // Create listen socket
        listen_fd_ = socket(AF_INET, SOCK_STREAM | SOCK_NONBLOCK | SOCK_CLOEXEC, 0);
        if (listen_fd_ < 0) {
            ::close(epoll_fd_);
            return false;
        }
        
        // Configure listen socket
        int one = 1;
        setsockopt(listen_fd_, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
        if (config.socket_opts.so_reuseport) {
            setsockopt(listen_fd_, SOL_SOCKET, SO_REUSEPORT, &one, sizeof(one));
        }
        
        // Bind
        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(config.port);
        inet_pton(AF_INET, config.bind_address, &addr.sin_addr);
        
        if (bind(listen_fd_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) < 0) {
            cleanup();
            return false;
        }
        
        // Listen
        if (listen(listen_fd_, config.listen_backlog) < 0) {
            cleanup();
            return false;
        }
        
        // Add listen socket to epoll
        epoll_event ev{};
        ev.events = EPOLLIN | EPOLLET;
        ev.data.fd = listen_fd_;
        if (epoll_ctl(epoll_fd_, EPOLL_CTL_ADD, listen_fd_, &ev) < 0) {
            cleanup();
            return false;
        }
        
        // Allocate event buffer
        events_.resize(config.max_events_per_poll);
        
        return true;
    }
    
    // ==========================================================================
    // Event Handlers
    // ==========================================================================
    
    void set_message_handler(MessageHandler handler) { on_message_ = std::move(handler); }
    void set_connect_handler(ConnectHandler handler) { on_connect_ = std::move(handler); }
    void set_disconnect_handler(DisconnectHandler handler) { on_disconnect_ = std::move(handler); }
    void set_heartbeat_timeout_handler(HeartbeatTimeoutHandler handler) { on_heartbeat_timeout_ = std::move(handler); }
    
    // ==========================================================================
    // Main Event Loop - Hot Path
    // ==========================================================================
    
    HOT_PATH void run() {
        running_ = true;
        
        while (LIKELY(running_)) {
            poll_once();
        }
    }
    
    // Single poll iteration - call this if integrating with external loop
    HOT_PATH void poll_once() {
        // Poll for events
        int nfds = epoll_wait(epoll_fd_, events_.data(), 
                              static_cast<int>(events_.size()), 
                              config_.epoll_timeout_ms);
        
        if (nfds > 0) {
            process_events(nfds);
        }
        
        // Process heartbeats
        process_heartbeats();
    }
    
    void stop() {
        running_ = false;
        cleanup();
    }
    
    // ==========================================================================
    // Session Access
    // ==========================================================================
    
    TCPSession* get_session(uint32_t session_id) noexcept {
        if (session_id == 0 || session_id > sessions_.size()) return nullptr;
        TCPSession& session = sessions_[session_id - 1];
        return session.is_connected() ? &session : nullptr;
    }
    
    const ConnectionStats* get_stats(uint32_t session_id) const noexcept {
        if (session_id == 0 || session_id > session_stats_.size()) return nullptr;
        return &session_stats_[session_id - 1];
    }
    
    size_t active_session_count() const noexcept { return active_sessions_.size(); }
    
    // Iterate over active sessions
    template<typename Func>
    void for_each_session(Func&& func) {
        for (uint32_t id : active_sessions_) {
            if (TCPSession* session = get_session(id)) {
                func(*session);
            }
        }
    }
    
    // ==========================================================================
    // Send to Session
    // ==========================================================================
    
    HOT_PATH SendResult send_to(uint32_t session_id, MessageType type, 
                                const uint8_t* payload, size_t len) noexcept {
        TCPSession* session = get_session(session_id);
        if (UNLIKELY(!session)) {
            return SendResult::DISCONNECTED;
        }
        
        SendResult result = session->send_message(type, payload, len);
        
        if (LIKELY(result == SendResult::SUCCESS)) {
            heartbeat_manager_.on_message_sent(session_id);
            ++session_stats_[session_id - 1].messages_sent;
        }
        
        return result;
    }
    
    // Broadcast to all sessions
    template<typename Predicate>
    void broadcast(MessageType type, const uint8_t* payload, size_t len, Predicate&& pred) {
        for (uint32_t id : active_sessions_) {
            if (TCPSession* session = get_session(id)) {
                if (pred(*session)) {
                    send_to(id, type, payload, len);
                }
            }
        }
    }
    
private:
    // ==========================================================================
    // Event Processing
    // ==========================================================================
    
    HOT_PATH void process_events(int nfds) {
        for (int i = 0; i < nfds; ++i) {
            const epoll_event& ev = events_[i];
            
            if (ev.data.fd == listen_fd_) {
                // Accept new connections
                accept_connections();
            } else {
                // Handle session events
                uint32_t session_id = static_cast<uint32_t>(ev.data.u64 >> 32);
                
                if (ev.events & (EPOLLERR | EPOLLHUP | EPOLLRDHUP)) {
                    close_session(session_id);
                } else if (ev.events & EPOLLIN) {
                    process_session_read(session_id);
                }
            }
        }
    }
    
    COLD_PATH void accept_connections() {
        while (true) {
            sockaddr_in client_addr{};
            socklen_t addr_len = sizeof(client_addr);
            
            int client_fd = accept4(listen_fd_, 
                                    reinterpret_cast<sockaddr*>(&client_addr), 
                                    &addr_len, 
                                    SOCK_NONBLOCK | SOCK_CLOEXEC);
            
            if (client_fd < 0) {
                if (errno == EAGAIN || errno == EWOULDBLOCK) {
                    break;  // No more pending connections
                }
                continue;  // Error, try next
            }
            
            // Find free session slot
            uint32_t session_id = allocate_session_id();
            if (session_id == 0) {
                ::close(client_fd);  // No slots available
                continue;
            }
            
            // Initialize session
            TCPSession& session = sessions_[session_id - 1];
            if (!session.initialize(client_fd, session_id, config_.socket_opts)) {
                ::close(client_fd);
                continue;
            }
            
            // Set callbacks
            session.set_callbacks(
                &TCPServer::static_on_message,
                &TCPServer::static_on_disconnect,
                this
            );
            
            // Add to epoll
            epoll_event ev{};
            ev.events = EPOLLIN | EPOLLET | EPOLLRDHUP;
            ev.data.u64 = (static_cast<uint64_t>(session_id) << 32) | client_fd;
            
            if (epoll_ctl(epoll_fd_, EPOLL_CTL_ADD, client_fd, &ev) < 0) {
                session.close();
                continue;
            }
            
            // Track active session
            active_sessions_.push_back(session_id);
            
            // Initialize stats
            session_stats_[session_id - 1].reset();
            session_stats_[session_id - 1].connect_time_tsc = Timestamp::now_tsc();
            
            // Start heartbeat tracking
            heartbeat_manager_.on_session_start(session_id);
            
            // Notify handler
            if (on_connect_) {
                on_connect_(session);
            }
        }
    }
    
    HOT_PATH void process_session_read(uint32_t session_id) {
        TCPSession* session = get_session(session_id);
        if (UNLIKELY(!session)) return;
        
        int result = session->recv_messages();
        
        if (result < 0) {
            close_session(session_id);
        } else if (result > 0) {
            session_stats_[session_id - 1].messages_received += result;
        }
    }
    
    COLD_PATH void close_session(uint32_t session_id) {
        if (session_id == 0 || session_id > sessions_.size()) return;
        
        TCPSession& session = sessions_[session_id - 1];
        if (!session.is_connected()) return;
        
        int fd = session.fd();
        
        // Remove from epoll
        epoll_ctl(epoll_fd_, EPOLL_CTL_DEL, fd, nullptr);
        
        // Stop heartbeat tracking
        heartbeat_manager_.on_session_end(session_id);
        
        // Notify handler
        if (on_disconnect_) {
            on_disconnect_(session);
        }
        
        // Close session
        session.close();
        
        // Remove from active list
        auto it = std::find(active_sessions_.begin(), active_sessions_.end(), session_id);
        if (it != active_sessions_.end()) {
            active_sessions_.erase(it);
        }
    }
    
    // ==========================================================================
    // Heartbeat Processing
    // ==========================================================================
    
    HOT_PATH void process_heartbeats() {
        heartbeat_manager_.process(
            // Send heartbeat callback
            [this](uint32_t session_id) {
                if (TCPSession* session = get_session(session_id)) {
                    session->send_heartbeat();
                    heartbeat_manager_.on_heartbeat_sent(session_id);
                    ++session_stats_[session_id - 1].heartbeats_sent;
                }
            },
            // Timeout callback
            [this](uint32_t session_id) {
                ++session_stats_[session_id - 1].heartbeats_missed;
                
                if (on_heartbeat_timeout_) {
                    if (TCPSession* session = get_session(session_id)) {
                        on_heartbeat_timeout_(*session);
                    }
                }
                
                // Close session on timeout
                close_session(session_id);
            }
        );
    }
    
    // ==========================================================================
    // Static Callbacks
    // ==========================================================================
    
    static void static_on_message(TCPSession* session, const MessageHeader* header, 
                                  const uint8_t* payload, void* user_data) {
        auto* server = static_cast<TCPServer*>(user_data);
        
        // Handle heartbeat internally
        if (header->type == MessageType::HEARTBEAT_REQUEST) {
            session->send_heartbeat_response();
            server->heartbeat_manager_.on_message_sent(session->session_id());
            return;
        }
        
        if (header->type == MessageType::HEARTBEAT_RESPONSE) {
            server->heartbeat_manager_.on_heartbeat_received(session->session_id());
            
            // Calculate RTT for stats
            uint64_t now = Timestamp::now_tsc();
            uint64_t rtt_tsc = now - header->timestamp_ns;  // timestamp contains sender TSC
            uint64_t rtt_ns = Timestamp::tsc_to_ns(rtt_tsc);
            server->session_stats_[session->session_id() - 1].record_latency(rtt_ns);
            return;
        }
        
        // Update heartbeat tracking
        server->heartbeat_manager_.on_message_received(session->session_id());
        
        // Dispatch to user handler
        if (server->on_message_) {
            server->on_message_(*session, *header, payload);
        }
    }
    
    static void static_on_disconnect(TCPSession* session, void* user_data) {
        auto* server = static_cast<TCPServer*>(user_data);
        server->close_session(session->session_id());
    }
    
    // ==========================================================================
    // Utilities
    // ==========================================================================
    
    uint32_t allocate_session_id() {
        // Simple linear search for free slot
        // For production, use a free list
        for (size_t i = 0; i < sessions_.size(); ++i) {
            if (!sessions_[i].is_connected()) {
                return static_cast<uint32_t>(i + 1);
            }
        }
        return 0;  // No free slots
    }
    
    void cleanup() {
        // Close all sessions
        for (auto& session : sessions_) {
            session.close();
        }
        active_sessions_.clear();
        
        if (epoll_fd_ >= 0) {
            ::close(epoll_fd_);
            epoll_fd_ = -1;
        }
        
        if (listen_fd_ >= 0) {
            ::close(listen_fd_);
            listen_fd_ = -1;
        }
    }
    
    // Configuration
    ServerConfig config_;
    
    // Sockets
    int listen_fd_;
    int epoll_fd_;
    
    // State
    std::atomic<bool> running_;
    uint32_t next_session_id_;
    
    // Sessions
    std::vector<TCPSession> sessions_;
    std::vector<ConnectionStats> session_stats_;
    std::vector<uint32_t> active_sessions_;  // List of active session IDs
    
    // Event buffer
    std::vector<epoll_event> events_;
    
    // Heartbeat management
    HeartbeatManager heartbeat_manager_;
    
    // Handlers
    MessageHandler on_message_;
    ConnectHandler on_connect_;
    DisconnectHandler on_disconnect_;
    HeartbeatTimeoutHandler on_heartbeat_timeout_;
};

} // namespace ptpx
