#pragma once

#include "../core/common.hpp"
#include "../core/ring_buffer.hpp"

#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <cstring>

namespace ptpx {

// =============================================================================
// Socket Configuration for Low Latency
// =============================================================================

struct SocketOptions {
    bool tcp_nodelay = true;
    bool so_keepalive = false;
    bool so_reuseaddr = true;
    bool so_reuseport = true;
    int so_sndbuf = 1024 * 1024;     // 1MB send buffer
    int so_rcvbuf = 1024 * 1024;     // 1MB receive buffer
    int so_busy_poll = Config::BUSY_POLL_US;
    int so_busy_read = Config::BUSY_READ_US;
    int so_incoming_cpu = -1;        // Pin to CPU (-1 = don't pin)
    int tcp_quickack = 1;
    
    static SocketOptions low_latency() noexcept {
        SocketOptions opts;
        opts.tcp_nodelay = true;
        opts.so_busy_poll = 50;
        opts.so_busy_read = 50;
        return opts;
    }
};

COLD_PATH inline bool configure_socket(int fd, const SocketOptions& opts) noexcept {
    int one = 1;
    int zero = 0;
    
    // Non-blocking
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0 || fcntl(fd, F_SETFL, flags | O_NONBLOCK) < 0) {
        return false;
    }
    
    // TCP_NODELAY - critical for latency
    if (opts.tcp_nodelay) {
        if (setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one)) < 0) {
            return false;
        }
    }
    
    // TCP_QUICKACK - disable delayed ACKs
    if (opts.tcp_quickack) {
        setsockopt(fd, IPPROTO_TCP, TCP_QUICKACK, &one, sizeof(one));
    }
    
    // SO_KEEPALIVE
    if (setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, 
                   opts.so_keepalive ? &one : &zero, sizeof(int)) < 0) {
        return false;
    }
    
    // Buffer sizes
    if (opts.so_sndbuf > 0) {
        setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &opts.so_sndbuf, sizeof(opts.so_sndbuf));
    }
    if (opts.so_rcvbuf > 0) {
        setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &opts.so_rcvbuf, sizeof(opts.so_rcvbuf));
    }
    
    // Busy polling (kernel 3.11+)
#ifdef SO_BUSY_POLL
    if (opts.so_busy_poll > 0) {
        setsockopt(fd, SOL_SOCKET, SO_BUSY_POLL, &opts.so_busy_poll, sizeof(opts.so_busy_poll));
    }
#endif

#ifdef SO_BUSY_POLL_BUDGET
    if (opts.so_busy_read > 0) {
        setsockopt(fd, SOL_SOCKET, SO_BUSY_POLL_BUDGET, &opts.so_busy_read, sizeof(opts.so_busy_read));
    }
#endif

#ifdef SO_INCOMING_CPU
    if (opts.so_incoming_cpu >= 0) {
        setsockopt(fd, SOL_SOCKET, SO_INCOMING_CPU, 
                   &opts.so_incoming_cpu, sizeof(opts.so_incoming_cpu));
    }
#endif
    
    return true;
}

// =============================================================================
// TCP Session - Per-Connection State
// =============================================================================

class TCPSession {
public:
    using MessageCallback = void(*)(TCPSession*, const MessageHeader*, const uint8_t*, void*);
    using DisconnectCallback = void(*)(TCPSession*, void*);
    
    TCPSession() noexcept 
        : fd_(-1)
        , session_id_(0)
        , state_(SessionState::DISCONNECTED)
        , send_sequence_(0)
        , recv_sequence_(0)
        , last_recv_tsc_(0)
        , last_send_tsc_(0)
        , user_data_(nullptr)
        , on_message_(nullptr)
        , on_disconnect_(nullptr)
    {}
    
    ~TCPSession() noexcept {
        close();
    }
    
    // Non-copyable
    TCPSession(const TCPSession&) = delete;
    TCPSession& operator=(const TCPSession&) = delete;
    
    // Movable
    TCPSession(TCPSession&& other) noexcept {
        move_from(std::move(other));
    }
    
    TCPSession& operator=(TCPSession&& other) noexcept {
        if (this != &other) {
            close();
            move_from(std::move(other));
        }
        return *this;
    }
    
    // Initialize session with accepted socket
    COLD_PATH bool initialize(int fd, uint32_t session_id, const SocketOptions& opts = SocketOptions::low_latency()) noexcept {
        if (fd < 0) return false;
        
        if (!configure_socket(fd, opts)) {
            ::close(fd);
            return false;
        }
        
        fd_ = fd;
        session_id_ = session_id;
        state_ = SessionState::CONNECTED;
        send_sequence_ = 0;
        recv_sequence_ = 0;
        last_recv_tsc_ = Timestamp::now_tsc();
        last_send_tsc_ = last_recv_tsc_;
        
        recv_buffer_.reset();
        send_buffer_.reset();
        
        return true;
    }
    
    // ==========================================================================
    // Hot Path - Receive
    // ==========================================================================
    
    // Non-blocking receive - call from event loop
    // Returns number of complete messages processed
    HOT_PATH int recv_messages() noexcept {
        if (UNLIKELY(state_ != SessionState::CONNECTED)) {
            return -1;
        }
        
        int messages_processed = 0;
        
        // Compact buffer if needed
        if (recv_buffer_.writable() < 4096) {
            recv_buffer_.compact();
        }
        
        // Read from socket
        ssize_t n = ::recv(fd_, recv_buffer_.write_ptr(), recv_buffer_.writable(), MSG_DONTWAIT);
        
        if (n > 0) {
            recv_buffer_.advance_write(static_cast<size_t>(n));
            last_recv_tsc_ = Timestamp::now_tsc();
            
            // Process complete messages
            while (recv_buffer_.readable() >= MessageHeader::SIZE) {
                const MessageHeader* header = reinterpret_cast<const MessageHeader*>(recv_buffer_.read_ptr());
                
                // Validate message length
                if (UNLIKELY(header->length < MessageHeader::SIZE || 
                             header->length > Config::MAX_MESSAGE_SIZE)) {
                    state_ = SessionState::ERROR;
                    return -1;
                }
                
                // Check if complete message is available
                if (recv_buffer_.readable() < header->length) {
                    break;  // Need more data
                }
                
                // Sequence check
                if (UNLIKELY(recv_sequence_ != 0 && header->sequence_number != recv_sequence_ + 1)) {
                    // Gap detected - could implement recovery here
                }
                recv_sequence_ = header->sequence_number;
                
                // Dispatch message
                const uint8_t* payload = recv_buffer_.read_ptr() + MessageHeader::SIZE;
                
                if (on_message_) {
                    on_message_(this, header, payload, user_data_);
                }
                
                recv_buffer_.advance_read(header->length);
                ++messages_processed;
            }
        } else if (n == 0) {
            // Peer closed connection
            state_ = SessionState::DISCONNECTED;
            if (on_disconnect_) {
                on_disconnect_(this, user_data_);
            }
            return -1;
        } else if (errno != EAGAIN && errno != EWOULDBLOCK) {
            // Real error
            state_ = SessionState::ERROR;
            if (on_disconnect_) {
                on_disconnect_(this, user_data_);
            }
            return -1;
        }
        
        return messages_processed;
    }
    
    // ==========================================================================
    // Hot Path - Send
    // ==========================================================================
    
    // Send message with payload (application manages serialization)
    // Returns SendResult
    HOT_PATH SendResult send_message(MessageType type, const uint8_t* payload, size_t payload_len) noexcept {
        if (UNLIKELY(state_ != SessionState::CONNECTED)) {
            return SendResult::DISCONNECTED;
        }
        
        size_t total_len = MessageHeader::SIZE + payload_len;
        
        if (UNLIKELY(total_len > Config::MAX_MESSAGE_SIZE)) {
            return SendResult::ERROR;
        }
        
        // Check send buffer space
        if (UNLIKELY(send_buffer_.writable() < total_len)) {
            // Try to flush first
            flush();
            if (send_buffer_.writable() < total_len) {
                return SendResult::BUFFER_FULL;
            }
        }
        
        // Build header
        MessageHeader* header = reinterpret_cast<MessageHeader*>(send_buffer_.write_ptr());
        header->length = static_cast<uint32_t>(total_len);
        header->sequence_number = ++send_sequence_;
        header->timestamp_ns = Timestamp::now_tsc();  // Use TSC for minimal overhead
        header->type = type;
        header->flags = 0;
        header->reserved = 0;
        
        // Copy payload
        if (payload_len > 0 && payload != nullptr) {
            std::memcpy(send_buffer_.write_ptr() + MessageHeader::SIZE, payload, payload_len);
        }
        
        send_buffer_.advance_write(total_len);
        
        // Immediate send for latency
        return flush();
    }
    
    // Send heartbeat request
    HOT_PATH SendResult send_heartbeat() noexcept {
        return send_message(MessageType::HEARTBEAT_REQUEST, nullptr, 0);
    }
    
    // Send heartbeat response
    HOT_PATH SendResult send_heartbeat_response() noexcept {
        return send_message(MessageType::HEARTBEAT_RESPONSE, nullptr, 0);
    }
    
    // Flush send buffer to socket
    HOT_PATH SendResult flush() noexcept {
        if (send_buffer_.readable() == 0) {
            return SendResult::SUCCESS;
        }
        
        ssize_t n = ::send(fd_, send_buffer_.read_ptr(), send_buffer_.readable(), 
                           MSG_DONTWAIT | MSG_NOSIGNAL);
        
        if (n > 0) {
            send_buffer_.advance_read(static_cast<size_t>(n));
            last_send_tsc_ = Timestamp::now_tsc();
            
            // Compact if we've consumed significant data
            if (send_buffer_.readable() == 0) {
                send_buffer_.reset();
            }
            
            return SendResult::SUCCESS;
        } else if (n == 0 || (errno == EAGAIN || errno == EWOULDBLOCK)) {
            return SendResult::WOULD_BLOCK;
        } else {
            state_ = SessionState::ERROR;
            return SendResult::ERROR;
        }
    }
    
    // ==========================================================================
    // Session Management
    // ==========================================================================
    
    void close() noexcept {
        if (fd_ >= 0) {
            ::close(fd_);
            fd_ = -1;
        }
        state_ = SessionState::DISCONNECTED;
    }
    
    void set_callbacks(MessageCallback on_message, DisconnectCallback on_disconnect, void* user_data) noexcept {
        on_message_ = on_message;
        on_disconnect_ = on_disconnect;
        user_data_ = user_data;
    }
    
    // Accessors
    FORCE_INLINE int fd() const noexcept { return fd_; }
    FORCE_INLINE uint32_t session_id() const noexcept { return session_id_; }
    FORCE_INLINE SessionState state() const noexcept { return state_; }
    FORCE_INLINE uint64_t last_recv_tsc() const noexcept { return last_recv_tsc_; }
    FORCE_INLINE uint64_t last_send_tsc() const noexcept { return last_send_tsc_; }
    FORCE_INLINE bool is_connected() const noexcept { return state_ == SessionState::CONNECTED; }
    
private:
    void move_from(TCPSession&& other) noexcept {
        fd_ = other.fd_;
        session_id_ = other.session_id_;
        state_ = other.state_;
        send_sequence_ = other.send_sequence_;
        recv_sequence_ = other.recv_sequence_;
        last_recv_tsc_ = other.last_recv_tsc_;
        last_send_tsc_ = other.last_send_tsc_;
        user_data_ = other.user_data_;
        on_message_ = other.on_message_;
        on_disconnect_ = other.on_disconnect_;
        
        other.fd_ = -1;
        other.state_ = SessionState::DISCONNECTED;
    }
    
    // Hot data - frequently accessed
    int fd_;
    uint32_t session_id_;
    SessionState state_;
    uint32_t send_sequence_;
    uint32_t recv_sequence_;
    uint64_t last_recv_tsc_;
    uint64_t last_send_tsc_;
    
    // Callbacks
    void* user_data_;
    MessageCallback on_message_;
    DisconnectCallback on_disconnect_;
    
    // Buffers - larger, less frequently accessed
    PreallocatedBuffer<Config::RECV_BUFFER_SIZE> recv_buffer_;
    PreallocatedBuffer<Config::SEND_BUFFER_SIZE> send_buffer_;
};

} // namespace ptpx
