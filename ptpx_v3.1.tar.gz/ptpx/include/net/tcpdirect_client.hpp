// =============================================================================
// TCPDirect Client - ef_vi Based Ultra-Low-Latency TCP Client
// For order entry: ~200-400ns send latency
// =============================================================================

#pragma once

#include "../core/common.hpp"

#ifdef HAS_TCPDIRECT
#include <zf/zf.h>
#include <etherfabric/ef_vi.h>
#endif

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <functional>
#include <cstring>
#include <stdexcept>

namespace ptpx {

// =============================================================================
// TCPDirect Client Configuration
// =============================================================================

struct TCPDirectClientConfig {
    const char* interface = "eth0";      // Solarflare interface
    const char* server_host = nullptr;
    uint16_t server_port = 9000;
    
    // ef_vi tuning  
    size_t rx_ring_size = 512;
    size_t tx_ring_size = 512;
    
    // Behavior
    bool busy_poll = true;
    int spin_usec = 1000000;
    int cpu_affinity = -1;
    
    // Reconnection
    bool auto_reconnect = true;
    uint64_t reconnect_delay_ns = 100'000'000;  // 100ms
};

// =============================================================================
// TCPDirect Client Implementation
// =============================================================================

#ifdef HAS_TCPDIRECT

template<typename MessageHandler>
class TCPDirectClient {
public:
    using DisconnectHandler = std::function<void()>;
    using ConnectHandler = std::function<void()>;
    
    explicit TCPDirectClient(const TCPDirectClientConfig& config)
        : config_(config)
        , stack_(nullptr)
        , zocket_(nullptr)
        , state_(SessionState::DISCONNECTED)
        , send_sequence_(0)
        , recv_sequence_(0) {
    }
    
    ~TCPDirectClient() {
        disconnect();
    }
    
    // Non-copyable
    TCPDirectClient(const TCPDirectClient&) = delete;
    TCPDirectClient& operator=(const TCPDirectClient&) = delete;
    
    // =========================================================================
    // Connection Management
    // =========================================================================
    
    bool connect() {
        if (state_ == SessionState::CONNECTED) {
            return true;
        }
        
        // Initialize ZF if needed
        if (!stack_) {
            int rc = zf_init();
            if (rc < 0) return false;
            
            // Create attributes
            struct zf_attr* attr;
            rc = zf_attr_alloc(&attr);
            if (rc < 0) return false;
            
            // Configure for minimum latency
            zf_attr_set_str(attr, "interface", config_.interface);
            zf_attr_set_int(attr, "reactor_spin_count", config_.spin_usec);
            zf_attr_set_int(attr, "rx_ring_max", config_.rx_ring_size);
            zf_attr_set_int(attr, "tx_ring_max", config_.tx_ring_size);
            
            // Allocate stack
            rc = zf_stack_alloc(attr, &stack_);
            zf_attr_free(attr);
            
            if (rc < 0) {
                return false;
            }
        }
        
        // Resolve server address
        struct sockaddr_in server_addr = {};
        server_addr.sin_family = AF_INET;
        server_addr.sin_port = htons(config_.server_port);
        
        if (inet_pton(AF_INET, config_.server_host, &server_addr.sin_addr) != 1) {
            return false;
        }
        
        // Create TCP zocket and connect
        state_ = SessionState::CONNECTING;
        
        int rc = zft_alloc(stack_, nullptr, &zocket_);
        if (rc < 0) {
            state_ = SessionState::ERROR;
            return false;
        }
        
        rc = zft_connect(zocket_,
                        reinterpret_cast<sockaddr*>(&server_addr),
                        sizeof(server_addr),
                        nullptr, nullptr);
        
        if (rc < 0 && rc != -EINPROGRESS) {
            zft_free(zocket_);
            zocket_ = nullptr;
            state_ = SessionState::ERROR;
            return false;
        }
        
        // Wait for connection (could be async in production)
        while (zft_state(zocket_) == TCP_SYN_SENT) {
            zf_reactor_perform(stack_);
        }
        
        if (zft_state(zocket_) != TCP_ESTABLISHED) {
            zft_free(zocket_);
            zocket_ = nullptr;
            state_ = SessionState::ERROR;
            return false;
        }
        
        state_ = SessionState::CONNECTED;
        send_sequence_ = 0;
        recv_sequence_ = 0;
        last_activity_tsc_ = Timestamp::now_tsc();
        
        if (connect_handler_) {
            connect_handler_();
        }
        
        return true;
    }
    
    void disconnect() {
        if (zocket_) {
            zft_free(zocket_);
            zocket_ = nullptr;
        }
        
        if (stack_) {
            zf_stack_free(stack_);
            stack_ = nullptr;
        }
        
        if (state_ == SessionState::CONNECTED && disconnect_handler_) {
            disconnect_handler_();
        }
        
        state_ = SessionState::DISCONNECTED;
    }
    
    // =========================================================================
    // Zero-Copy Send - Hot Path
    // =========================================================================
    
    HOT_PATH SendResult send(const uint8_t* data, size_t len) {
        if (UNLIKELY(state_ != SessionState::CONNECTED)) {
            return SendResult::DISCONNECTED;
        }
        
        struct iovec iov = { const_cast<uint8_t*>(data), len };
        
        int rc = zft_send(zocket_, &iov, 1, 0);
        
        if (LIKELY(rc == static_cast<int>(len))) {
            ++send_sequence_;
            last_activity_tsc_ = Timestamp::now_tsc();
            return SendResult::SUCCESS;
        }
        else if (rc == -EAGAIN) {
            return SendResult::WOULD_BLOCK;
        }
        else if (rc == -ENOTCONN || rc == -EPIPE) {
            handle_disconnect();
            return SendResult::DISCONNECTED;
        }
        else {
            return SendResult::ERROR;
        }
    }
    
    // Send order with header - optimized for HFT
    HOT_PATH SendResult send_order(MessageType type,
                                   const uint8_t* payload,
                                   size_t payload_len) {
        if (UNLIKELY(state_ != SessionState::CONNECTED)) {
            return SendResult::DISCONNECTED;
        }
        
        // Build header on stack
        MessageHeader header;
        header.length = MessageHeader::SIZE + payload_len;
        header.sequence_number = send_sequence_;
        header.timestamp_ns = Timestamp::now_tsc();
        header.type = type;
        header.flags = 0;
        header.reserved = 0;
        
        // Scatter-gather send
        struct iovec iov[2] = {
            { &header, MessageHeader::SIZE },
            { const_cast<uint8_t*>(payload), payload_len }
        };
        
        int iovcnt = (payload_len > 0) ? 2 : 1;
        size_t total = MessageHeader::SIZE + payload_len;
        
        int rc = zft_send(zocket_, iov, iovcnt, 0);
        
        if (LIKELY(rc == static_cast<int>(total))) {
            ++send_sequence_;
            last_activity_tsc_ = Timestamp::now_tsc();
            return SendResult::SUCCESS;
        }
        else if (rc == -EAGAIN) {
            return SendResult::WOULD_BLOCK;
        }
        else {
            handle_disconnect();
            return SendResult::DISCONNECTED;
        }
    }
    
    // =========================================================================
    // Zero-Copy Receive - Hot Path
    // =========================================================================
    
    HOT_PATH void poll() {
        if (UNLIKELY(state_ != SessionState::CONNECTED)) {
            return;
        }
        
        // Process stack events
        zf_reactor_perform(stack_);
        
        // Zero-copy receive
        recv_msg_.iovcnt = 8;
        recv_msg_.iov = recv_iov_;
        
        zft_zc_recv(zocket_, &recv_msg_, 0);
        
        if (recv_msg_.iovcnt == 0) {
            return;  // No data
        }
        
        // Check for disconnect
        if (recv_msg_.pkts_left < 0) {
            zft_zc_recv_done(zocket_, &recv_msg_);
            handle_disconnect();
            return;
        }
        
        last_activity_tsc_ = Timestamp::now_tsc();
        
        // Process received data
        for (int i = 0; i < recv_msg_.iovcnt; ++i) {
            process_data(
                static_cast<const uint8_t*>(recv_msg_.iov[i].iov_base),
                recv_msg_.iov[i].iov_len
            );
        }
        
        // Release buffers
        zft_zc_recv_done(zocket_, &recv_msg_);
    }
    
    // Blocking poll with timeout
    void poll_blocking(int timeout_us) {
        if (state_ != SessionState::CONNECTED) return;
        
        zf_muxer_wait(stack_, nullptr, nullptr, timeout_us * 1000);
        poll();
    }
    
    // =========================================================================
    // Handlers
    // =========================================================================
    
    void set_message_handler(MessageHandler handler) {
        message_handler_ = std::move(handler);
    }
    
    void set_connect_handler(ConnectHandler handler) {
        connect_handler_ = std::move(handler);
    }
    
    void set_disconnect_handler(DisconnectHandler handler) {
        disconnect_handler_ = std::move(handler);
    }
    
    // =========================================================================
    // Accessors
    // =========================================================================
    
    bool is_connected() const noexcept { 
        return state_ == SessionState::CONNECTED; 
    }
    
    SessionState state() const noexcept { return state_; }
    
    uint32_t send_sequence() const noexcept { return send_sequence_; }
    uint32_t recv_sequence() const noexcept { return recv_sequence_; }
    
    uint64_t last_activity_tsc() const noexcept { return last_activity_tsc_; }
    
private:
    // =========================================================================
    // Message Processing
    // =========================================================================
    
    HOT_PATH void process_data(const uint8_t* data, size_t len) {
        size_t offset = 0;
        
        while (offset + MessageHeader::SIZE <= len) {
            const MessageHeader* header = 
                reinterpret_cast<const MessageHeader*>(data + offset);
            
            if (header->length < MessageHeader::SIZE ||
                header->length > Config::MAX_MESSAGE_SIZE) {
                handle_disconnect();
                return;
            }
            
            if (offset + header->length > len) {
                break;  // Incomplete
            }
            
            const uint8_t* payload = data + offset + MessageHeader::SIZE;
            size_t payload_len = header->length - MessageHeader::SIZE;
            
            recv_sequence_ = header->sequence_number + 1;
            
            // Handle heartbeats internally
            if (header->type == MessageType::HEARTBEAT_REQUEST) {
                send_order(MessageType::HEARTBEAT_RESPONSE, nullptr, 0);
            }
            else if (message_handler_) {
                message_handler_(*header, payload, payload_len);
            }
            
            offset += header->length;
        }
    }
    
    void handle_disconnect() {
        if (state_ == SessionState::DISCONNECTED) return;
        
        state_ = SessionState::DISCONNECTED;
        
        if (zocket_) {
            zft_free(zocket_);
            zocket_ = nullptr;
        }
        
        if (disconnect_handler_) {
            disconnect_handler_();
        }
        
        // Auto-reconnect if configured
        if (config_.auto_reconnect) {
            // Could implement exponential backoff here
        }
    }
    
    // =========================================================================
    // Members
    // =========================================================================
    
    TCPDirectClientConfig config_;
    
    struct zf_stack* stack_;
    struct zft* zocket_;
    
    SessionState state_;
    uint32_t send_sequence_;
    uint32_t recv_sequence_;
    uint64_t last_activity_tsc_;
    
    // Zero-copy receive buffers
    struct zft_msg recv_msg_;
    struct iovec recv_iov_[8];
    
    // Handlers
    MessageHandler message_handler_;
    ConnectHandler connect_handler_;
    DisconnectHandler disconnect_handler_;
};

#else // !HAS_TCPDIRECT

// =============================================================================
// Stub when TCPDirect headers not available at compile time
// Users should prefer ExchangeClient which uses runtime dlopen
// =============================================================================

template<typename MessageHandler>
class TCPDirectClient {
public:
    explicit TCPDirectClient(const TCPDirectClientConfig&) {
        // Runtime error instead of compile-time - allows code to compile
        // but fails if actually instantiated without TCPDirect
        throw std::runtime_error(
            "TCPDirectClient: TCPDirect not available at compile time. "
            "Use ExchangeClient instead (runtime transport selection) or "
            "rebuild with OpenOnload SDK headers installed.");
    }
    
    bool connect() { return false; }
    void disconnect() {}
    void poll() {}
    SendResult send(const uint8_t*, size_t) { return SendResult::ERROR; }
    SendResult send_order(MessageType, const uint8_t*, size_t) { return SendResult::ERROR; }
    bool is_connected() const { return false; }
};

#endif // HAS_TCPDIRECT

} // namespace ptpx
