// =============================================================================
// TCPDirect Server - ef_vi Based Ultra-Low-Latency TCP Server
// Solarflare TCPDirect: ~200-400ns latency (vs 500-800ns OpenOnload)
// =============================================================================

#pragma once

#include "../core/common.hpp"
#include "../core/timer_wheel.hpp"

// TCPDirect / ef_vi headers (Solarflare SDK required)
#ifdef HAS_TCPDIRECT
#include <zf/zf.h>
#include <etherfabric/ef_vi.h>
#include <etherfabric/pd.h>
#include <etherfabric/memreg.h>
#endif

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <functional>
#include <array>
#include <cstring>
#include <stdexcept>

namespace ptpx {

// =============================================================================
// TCPDirect Configuration
// =============================================================================

struct TCPDirectConfig {
    const char* interface = "eth0";      // Solarflare interface
    uint16_t port = 9000;
    size_t max_sessions = 64;
    
    // ef_vi tuning
    size_t rx_ring_size = 512;           // RX descriptor ring size
    size_t tx_ring_size = 512;           // TX descriptor ring size
    size_t pkt_buf_count = 1024;         // Packet buffer count
    size_t pkt_buf_size = 2048;          // Per-packet buffer size
    
    // Behavior
    bool busy_poll = true;               // Spin vs block
    int spin_usec = 1000000;             // Spin duration before blocking
    int cpu_affinity = -1;               // CPU to pin to (-1 = no pin)
};

// =============================================================================
// TCPDirect Session
// =============================================================================

#ifdef HAS_TCPDIRECT

struct TCPDirectSession {
    struct zft* zocket = nullptr;        // TCPDirect TCP zocket
    uint32_t session_id = 0;
    SessionState state = SessionState::DISCONNECTED;
    
    // Zero-copy receive IOVs
    struct zft_msg recv_msg;
    struct iovec recv_iov[8];
    
    // Send tracking
    uint32_t send_sequence = 0;
    uint32_t recv_sequence = 0;
    
    // Timestamps
    uint64_t last_activity_tsc = 0;
    uint64_t last_heartbeat_tsc = 0;
    
    // Remote address info
    sockaddr_in remote_addr;
    
    void reset() noexcept {
        if (zocket) {
            zft_free(zocket);
            zocket = nullptr;
        }
        state = SessionState::DISCONNECTED;
        send_sequence = 0;
        recv_sequence = 0;
    }
};

// =============================================================================
// TCPDirect Server Implementation
// =============================================================================

template<typename MessageHandler>
class TCPDirectServer {
public:
    using ConnectHandler = std::function<void(uint32_t session_id)>;
    using DisconnectHandler = std::function<void(uint32_t session_id)>;
    
    explicit TCPDirectServer(const TCPDirectConfig& config)
        : config_(config)
        , running_(false)
        , stack_(nullptr)
        , listener_(nullptr) {
        sessions_.resize(config.max_sessions);
    }
    
    ~TCPDirectServer() {
        stop();
    }
    
    // Non-copyable
    TCPDirectServer(const TCPDirectServer&) = delete;
    TCPDirectServer& operator=(const TCPDirectServer&) = delete;
    
    // =========================================================================
    // Lifecycle
    // =========================================================================
    
    bool start() {
        // Initialize ZF library
        int rc = zf_init();
        if (rc < 0) {
            return false;
        }
        
        // Create attributes
        struct zf_attr* attr;
        rc = zf_attr_alloc(&attr);
        if (rc < 0) {
            return false;
        }
        
        // Configure attributes for minimum latency
        zf_attr_set_str(attr, "interface", config_.interface);
        zf_attr_set_int(attr, "reactor_spin_count", config_.spin_usec);
        zf_attr_set_int(attr, "rx_ring_max", config_.rx_ring_size);
        zf_attr_set_int(attr, "tx_ring_max", config_.tx_ring_size);
        zf_attr_set_int(attr, "alt_count", 0);  // No alternatives
        
        // Allocate stack
        rc = zf_stack_alloc(attr, &stack_);
        zf_attr_free(attr);
        
        if (rc < 0) {
            return false;
        }
        
        // Create listening zocket
        struct sockaddr_in listen_addr = {};
        listen_addr.sin_family = AF_INET;
        listen_addr.sin_port = htons(config_.port);
        listen_addr.sin_addr.s_addr = INADDR_ANY;
        
        rc = zftl_listen(stack_, 
                         reinterpret_cast<sockaddr*>(&listen_addr),
                         sizeof(listen_addr),
                         nullptr,  // Use default attributes
                         &listener_);
        
        if (rc < 0) {
            zf_stack_free(stack_);
            stack_ = nullptr;
            return false;
        }
        
        // Initialize timer wheel
        timer_wheel_.initialize(config_.max_sessions);
        timer_wheel_.calibrate();
        
        running_ = true;
        return true;
    }
    
    void stop() {
        running_ = false;
        
        // Close all sessions
        for (auto& session : sessions_) {
            session.reset();
        }
        
        // Close listener
        if (listener_) {
            zftl_free(listener_);
            listener_ = nullptr;
        }
        
        // Free stack
        if (stack_) {
            zf_stack_free(stack_);
            stack_ = nullptr;
        }
        
        zf_deinit();
    }
    
    // =========================================================================
    // Main Event Loop - Call This Continuously
    // =========================================================================
    
    HOT_PATH void poll() {
        if (UNLIKELY(!running_)) return;
        
        uint64_t now_tsc = Timestamp::now_tsc();
        
        // 1. Process stack events (RX, TX completions, accepts)
        zf_reactor_perform(stack_);
        
        // 2. Check for new connections
        accept_connections();
        
        // 3. Process receives on all active sessions
        for (auto& session : sessions_) {
            if (session.state == SessionState::CONNECTED) {
                process_recv(session, now_tsc);
            }
        }
        
        // 4. Process timer expirations (heartbeats, timeouts)
        timer_wheel_.advance(now_tsc, [this](uint32_t session_id) {
            handle_timeout(session_id);
        });
    }
    
    // Tight spin loop for minimum latency
    void run() {
        while (LIKELY(running_)) {
            poll();
        }
    }
    
    // =========================================================================
    // Zero-Copy Send - Returns Immediately
    // =========================================================================
    
    HOT_PATH SendResult send(uint32_t session_id, 
                             const uint8_t* data, 
                             size_t len) {
        if (UNLIKELY(session_id >= sessions_.size())) {
            return SendResult::ERROR;
        }
        
        TCPDirectSession& session = sessions_[session_id];
        
        if (UNLIKELY(session.state != SessionState::CONNECTED)) {
            return SendResult::DISCONNECTED;
        }
        
        // Zero-copy send via TCPDirect
        struct iovec iov = { const_cast<uint8_t*>(data), len };
        
        int rc = zft_send(session.zocket, &iov, 1, 0);
        
        if (LIKELY(rc == static_cast<int>(len))) {
            ++session.send_sequence;
            return SendResult::SUCCESS;
        }
        else if (rc == -EAGAIN) {
            return SendResult::WOULD_BLOCK;
        }
        else {
            return SendResult::ERROR;
        }
    }
    
    // Send with pre-built header
    HOT_PATH SendResult send_message(uint32_t session_id,
                                     MessageType type,
                                     const uint8_t* payload,
                                     size_t payload_len) {
        if (UNLIKELY(session_id >= sessions_.size())) {
            return SendResult::ERROR;
        }
        
        TCPDirectSession& session = sessions_[session_id];
        
        if (UNLIKELY(session.state != SessionState::CONNECTED)) {
            return SendResult::DISCONNECTED;
        }
        
        // Build header on stack (20 bytes - fits in registers)
        MessageHeader header;
        header.length = MessageHeader::SIZE + payload_len;
        header.sequence_number = session.send_sequence;
        header.timestamp_ns = Timestamp::now_tsc();  // Use TSC directly
        header.type = type;
        header.flags = 0;
        header.reserved = 0;
        
        // Scatter-gather send: header + payload
        struct iovec iov[2] = {
            { &header, MessageHeader::SIZE },
            { const_cast<uint8_t*>(payload), payload_len }
        };
        
        int iovcnt = (payload_len > 0) ? 2 : 1;
        size_t total_len = MessageHeader::SIZE + payload_len;
        
        int rc = zft_send(session.zocket, iov, iovcnt, 0);
        
        if (LIKELY(rc == static_cast<int>(total_len))) {
            ++session.send_sequence;
            return SendResult::SUCCESS;
        }
        else if (rc == -EAGAIN) {
            return SendResult::WOULD_BLOCK;
        }
        else {
            return SendResult::ERROR;
        }
    }
    
    // =========================================================================
    // Handlers
    // =========================================================================
    
    void set_message_handler(MessageHandler handler) {
        message_handler_ = std::move(handler);
    }
    
    void set_connect_handler(ConnectHandler handler) {
        connect_handler_ = std::move(handler);
    }
    
    void set_disconnect_handler(DisconnectHandler handler) {
        disconnect_handler_ = std::move(handler);
    }
    
    // =========================================================================
    // Accessors
    // =========================================================================
    
    size_t active_sessions() const noexcept {
        size_t count = 0;
        for (const auto& s : sessions_) {
            if (s.state == SessionState::CONNECTED) ++count;
        }
        return count;
    }
    
    bool is_running() const noexcept { return running_; }
    
private:
    // =========================================================================
    // Accept New Connections
    // =========================================================================
    
    void accept_connections() {
        struct zft* new_zocket = nullptr;
        
        while (zftl_accept(listener_, &new_zocket) == 0) {
            // Find free session slot
            uint32_t session_id = find_free_session();
            if (session_id == INVALID_SESSION) {
                // No free slots - close connection
                zft_free(new_zocket);
                continue;
            }
            
            TCPDirectSession& session = sessions_[session_id];
            session.zocket = new_zocket;
            session.session_id = session_id;
            session.state = SessionState::CONNECTED;
            session.send_sequence = 0;
            session.recv_sequence = 0;
            session.last_activity_tsc = Timestamp::now_tsc();
            
            // Get remote address
            socklen_t addr_len = sizeof(session.remote_addr);
            zft_getname(new_zocket, nullptr, nullptr,
                       reinterpret_cast<sockaddr*>(&session.remote_addr),
                       &addr_len);
            
            // Schedule heartbeat timeout
            timer_wheel_.reschedule(session_id, Config::HEARTBEAT_TIMEOUT_NS);
            
            // Notify application
            if (connect_handler_) {
                connect_handler_(session_id);
            }
        }
    }
    
    // =========================================================================
    // Process Receive - Zero-Copy
    // =========================================================================
    
    HOT_PATH void process_recv(TCPDirectSession& session, uint64_t now_tsc) {
        // Setup zero-copy receive
        session.recv_msg.iovcnt = 8;
        session.recv_msg.iov = session.recv_iov;
        
        // Try to receive (non-blocking)
        zft_zc_recv(session.zocket, &session.recv_msg, 0);
        
        if (session.recv_msg.iovcnt == 0) {
            // No data available
            return;
        }
        
        // Check for disconnect
        if (session.recv_msg.pkts_left < 0) {
            handle_disconnect(session);
            return;
        }
        
        session.last_activity_tsc = now_tsc;
        
        // Process received data - zero copy!
        // Data is directly in NIC buffers, pointed to by IOVs
        for (int i = 0; i < session.recv_msg.iovcnt; ++i) {
            const uint8_t* data = static_cast<const uint8_t*>(session.recv_iov[i].iov_base);
            size_t len = session.recv_iov[i].iov_len;
            
            process_data(session, data, len);
        }
        
        // Release buffers back to NIC
        zft_zc_recv_done(session.zocket, &session.recv_msg);
        
        // Reschedule timeout
        timer_wheel_.reschedule(session.session_id, Config::HEARTBEAT_TIMEOUT_NS);
    }
    
    // =========================================================================
    // Message Framing & Dispatch
    // =========================================================================
    
    HOT_PATH void process_data(TCPDirectSession& session, 
                               const uint8_t* data, 
                               size_t len) {
        size_t offset = 0;
        
        while (offset + MessageHeader::SIZE <= len) {
            const MessageHeader* header = 
                reinterpret_cast<const MessageHeader*>(data + offset);
            
            // Validate length
            if (header->length < MessageHeader::SIZE || 
                header->length > Config::MAX_MESSAGE_SIZE) {
                // Invalid message - disconnect
                handle_disconnect(session);
                return;
            }
            
            // Check if complete message available
            if (offset + header->length > len) {
                // Incomplete message - need buffering
                // (For simplicity, TCPDirect typically delivers complete messages)
                break;
            }
            
            // Extract payload
            const uint8_t* payload = data + offset + MessageHeader::SIZE;
            size_t payload_len = header->length - MessageHeader::SIZE;
            
            // Update sequence tracking
            if (header->sequence_number != session.recv_sequence) {
                // Gap detected - could log/handle
            }
            session.recv_sequence = header->sequence_number + 1;
            
            // Dispatch to handler
            if (message_handler_) {
                message_handler_(session.session_id, *header, payload, payload_len);
            }
            
            offset += header->length;
        }
    }
    
    // =========================================================================
    // Connection Management
    // =========================================================================
    
    void handle_disconnect(TCPDirectSession& session) {
        if (session.state == SessionState::DISCONNECTED) return;
        
        uint32_t session_id = session.session_id;
        
        timer_wheel_.cancel(session_id);
        session.reset();
        
        if (disconnect_handler_) {
            disconnect_handler_(session_id);
        }
    }
    
    void handle_timeout(uint32_t session_id) {
        if (session_id >= sessions_.size()) return;
        
        TCPDirectSession& session = sessions_[session_id];
        
        if (session.state != SessionState::CONNECTED) return;
        
        uint64_t now = Timestamp::now_tsc();
        uint64_t idle_ns = Timestamp::tsc_to_ns(now - session.last_activity_tsc);
        
        if (idle_ns > Config::CONNECTION_TIMEOUT_NS) {
            // Connection timed out
            handle_disconnect(session);
        }
        else if (idle_ns > Config::HEARTBEAT_INTERVAL_NS) {
            // Send heartbeat
            send_message(session_id, MessageType::HEARTBEAT_REQUEST, nullptr, 0);
            timer_wheel_.reschedule(session_id, Config::HEARTBEAT_INTERVAL_NS);
        }
        else {
            // Reschedule check
            timer_wheel_.reschedule(session_id, Config::HEARTBEAT_INTERVAL_NS);
        }
    }
    
    uint32_t find_free_session() const noexcept {
        for (uint32_t i = 0; i < sessions_.size(); ++i) {
            if (sessions_[i].state == SessionState::DISCONNECTED) {
                return i;
            }
        }
        return INVALID_SESSION;
    }
    
    static constexpr uint32_t INVALID_SESSION = ~uint32_t(0);
    
    // =========================================================================
    // Members
    // =========================================================================
    
    TCPDirectConfig config_;
    bool running_;
    
    // TCPDirect stack and listener
    struct zf_stack* stack_;
    struct zftl* listener_;
    
    // Sessions
    std::vector<TCPDirectSession> sessions_;
    
    // Timer management
    TimerWheel timer_wheel_;
    
    // Handlers
    MessageHandler message_handler_;
    ConnectHandler connect_handler_;
    DisconnectHandler disconnect_handler_;
};

#else // !HAS_TCPDIRECT

// =============================================================================
// Stub when TCPDirect headers not available at compile time
// Users should prefer ExchangeServer which uses runtime dlopen
// =============================================================================

template<typename MessageHandler>
class TCPDirectServer {
public:
    explicit TCPDirectServer(const TCPDirectConfig&) {
        // Runtime error instead of compile-time - allows code to compile
        throw std::runtime_error(
            "TCPDirectServer: TCPDirect not available at compile time. "
            "Use ExchangeServer instead (runtime transport selection) or "
            "rebuild with OpenOnload SDK headers installed.");
    }
    
    bool start() { return false; }
    void stop() {}
    void poll() {}
    void run() {}
    SendResult send(uint32_t, const uint8_t*, size_t) { return SendResult::ERROR; }
};

#endif // HAS_TCPDIRECT

} // namespace ptpx
