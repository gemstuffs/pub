#pragma once

// =============================================================================
// ptpx - Runtime Transport Selection
// =============================================================================
//
// Single binary that auto-selects optimal transport at runtime:
//   1. TCPDirect (if libzf.so available + Solarflare NIC)
//   2. OpenOnload (if running under onload wrapper)
//   3. Plain TCP (fallback)
//
// Usage:
//   auto client = TransportFactory::create_client(config);
//   client->connect("192.168.1.1", 9000);
//   client->send(data, len);
//
// =============================================================================

#include "../core/common.hpp"
#include "connection_manager.hpp"
#include "kernel_bypass.hpp"

#include <memory>
#include <functional>
#include <string>
#include <cstring>
#include <cctype>
#include <dlfcn.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <poll.h>
#include <sys/uio.h>
#include <errno.h>

namespace ptpx {

// =============================================================================
// Transport Type
// =============================================================================

enum class TransportType : uint8_t {
    AUTO = 0,       // Auto-detect best available
    TCPDIRECT,      // Solarflare TCPDirect (lowest latency)
    ONLOAD,         // Solarflare OpenOnload 
    KERNEL          // Standard kernel TCP
};

inline const char* transport_type_to_string(TransportType t) {
    switch (t) {
        case TransportType::AUTO:      return "AUTO";
        case TransportType::TCPDIRECT: return "TCPDIRECT";
        case TransportType::ONLOAD:    return "ONLOAD";
        case TransportType::KERNEL:    return "KERNEL";
        default:                       return "UNKNOWN";
    }
}

// =============================================================================
// Runtime Transport Control
// =============================================================================

// Global runtime configuration - can be set before creating transports
// Also checks environment variable: PTPX_TRANSPORT
//   export PTPX_TRANSPORT=tcpdirect  # Force TCPDirect
//   export PTPX_TRANSPORT=onload     # Force OpenOnload
//   export PTPX_TRANSPORT=kernel     # Force kernel TCP
//   export PTPX_TRANSPORT=auto       # Auto-detect (default)

class RuntimeConfig {
public:
    // Singleton access
    static RuntimeConfig& instance() {
        static RuntimeConfig config;
        return config;
    }
    
    // Set transport type programmatically
    void set_transport(TransportType type) {
        transport_type_ = type;
        explicit_set_ = true;
    }
    
    // Convenience setters
    void use_tcpdirect(bool enable = true) {
        transport_type_ = enable ? TransportType::TCPDIRECT : TransportType::KERNEL;
        explicit_set_ = true;
    }
    
    void use_onload(bool enable = true) {
        transport_type_ = enable ? TransportType::ONLOAD : TransportType::KERNEL;
        explicit_set_ = true;
    }
    
    void use_kernel(bool enable = true) {
        transport_type_ = TransportType::KERNEL;
        explicit_set_ = true;
    }
    
    void use_auto() {
        transport_type_ = TransportType::AUTO;
        explicit_set_ = true;
    }
    
    // Get effective transport type (checks env var if not explicitly set)
    TransportType get_transport() const {
        if (explicit_set_) {
            return transport_type_;
        }
        
        // Check environment variable
        const char* env = getenv("PTPX_TRANSPORT");
        if (env) {
            std::string val(env);
            // Convert to lowercase
            for (auto& c : val) c = std::tolower(c);
            
            if (val == "tcpdirect" || val == "zf") {
                return TransportType::TCPDIRECT;
            } else if (val == "onload" || val == "ef_vi") {
                return TransportType::ONLOAD;
            } else if (val == "kernel" || val == "socket" || val == "tcp") {
                return TransportType::KERNEL;
            } else if (val == "auto" || val == "detect") {
                return TransportType::AUTO;
            }
        }
        
        return TransportType::AUTO;
    }
    
    bool is_explicit() const { return explicit_set_; }
    
    // Reset to default (auto-detect)
    void reset() {
        transport_type_ = TransportType::AUTO;
        explicit_set_ = false;
    }
    
private:
    RuntimeConfig() = default;
    TransportType transport_type_ = TransportType::AUTO;
    bool explicit_set_ = false;
};

// Convenience global functions
inline void use_tcpdirect(bool enable = true) {
    RuntimeConfig::instance().use_tcpdirect(enable);
}

inline void use_onload(bool enable = true) {
    RuntimeConfig::instance().use_onload(enable);
}

inline void use_kernel(bool enable = true) {
    RuntimeConfig::instance().use_kernel(enable);
}

inline void use_auto() {
    RuntimeConfig::instance().use_auto();
}

inline void set_transport(TransportType type) {
    RuntimeConfig::instance().set_transport(type);
}

// =============================================================================
// Transport Configuration
// =============================================================================

struct TransportConfig {
    // If AUTO, uses RuntimeConfig setting (which may come from env var)
    // If specific type, overrides RuntimeConfig for this transport only
    TransportType preferred_type = TransportType::AUTO;
    
    // TCPDirect-specific
    std::string interface = "eth0";      // Solarflare interface name
    bool tcpdirect_ctpio = true;         // Cut-through PIO (sub-μs sends)
    
    // Connection settings
    std::string host;
    uint16_t port = 0;
    
    // Timeouts (nanoseconds)
    uint64_t connect_timeout_ns = 5'000'000'000;   // 5s
    uint64_t recv_timeout_ns = 0;                   // 0 = non-blocking
    
    // Socket options
    bool tcp_nodelay = true;
    int recv_buffer_size = 1024 * 1024;  // 1MB
    int send_buffer_size = 1024 * 1024;  // 1MB
    
    // Reconnection
    ReconnectConfig reconnect;
    HeartbeatCfg heartbeat;
};

// =============================================================================
// Abstract Transport Interface
// =============================================================================

class ITransport {
public:
    virtual ~ITransport() = default;
    
    // Connection management
    virtual bool connect() = 0;
    virtual void disconnect() = 0;
    virtual bool is_connected() const = 0;
    
    // I/O
    virtual SendResult send(const void* data, size_t len) = 0;
    virtual ssize_t recv(void* buf, size_t max_len) = 0;
    
    // Message-based I/O (with header framing)
    virtual SendResult send_message(MessageType type, const void* payload, size_t len) = 0;
    
    // Polling
    virtual void poll() = 0;
    
    // Info
    virtual TransportType type() const = 0;
    virtual const char* type_name() const = 0;
    virtual uint64_t estimated_latency_ns() const = 0;
    
    // Stats
    virtual const ConnStats& stats() const = 0;
};

// =============================================================================
// TCPDirect Function Pointers (loaded via dlopen)
// =============================================================================

namespace tcpdirect {

// ZF types (opaque pointers for ABI compatibility)
struct zf_stack;
struct zf_attr;
struct zft;
struct zft_handle;
struct zft_msg;
struct iovec;

// Function pointer types matching ZF API
using zf_init_fn = int(*)();
using zf_deinit_fn = void(*)();
using zf_attr_alloc_fn = int(*)(zf_attr**);
using zf_attr_free_fn = void(*)(zf_attr*);
using zf_attr_set_str_fn = int(*)(zf_attr*, const char*, const char*);
using zf_attr_set_int_fn = int(*)(zf_attr*, const char*, int);
using zf_stack_alloc_fn = int(*)(zf_attr*, zf_stack**);
using zf_stack_free_fn = int(*)(zf_stack*);
using zf_reactor_perform_fn = int(*)(zf_stack*);
using zft_alloc_fn = int(*)(zf_stack*, zf_attr*, zft_handle**);
using zft_addr_bind_fn = int(*)(zft_handle*, const sockaddr*, socklen_t, int);
using zft_connect_fn = int(*)(zft_handle*, const sockaddr*, socklen_t, zft**);
using zft_shutdown_tx_fn = int(*)(zft*);
using zft_free_fn = int(*)(zft*);
using zft_state_fn = int(*)(zft*);
using zft_send_fn = int(*)(zft*, const iovec*, int, int);
using zft_send_single_fn = int(*)(zft*, const void*, size_t, int);
using zft_recv_fn = int(*)(zft*, zft_msg*, int);
using zft_zc_recv_done_fn = void(*)(zft*, zft_msg*);
using zft_error_fn = int(*)(zft*);
using zft_to_waitable_fn = void*(*)(zft*);
using zft_handle_free_fn = int(*)(zft_handle*);

// ZF constants
constexpr int ZF_ENODATA = 1;
constexpr int ZFT_STATE_EST = 1;

// Library handle and function pointers
struct ZFLibrary {
    void* handle = nullptr;
    bool initialized = false;
    
    zf_init_fn zf_init = nullptr;
    zf_deinit_fn zf_deinit = nullptr;
    zf_attr_alloc_fn zf_attr_alloc = nullptr;
    zf_attr_free_fn zf_attr_free = nullptr;
    zf_attr_set_str_fn zf_attr_set_str = nullptr;
    zf_attr_set_int_fn zf_attr_set_int = nullptr;
    zf_stack_alloc_fn zf_stack_alloc = nullptr;
    zf_stack_free_fn zf_stack_free = nullptr;
    zf_reactor_perform_fn zf_reactor_perform = nullptr;
    zft_alloc_fn zft_alloc = nullptr;
    zft_addr_bind_fn zft_addr_bind = nullptr;
    zft_connect_fn zft_connect = nullptr;
    zft_shutdown_tx_fn zft_shutdown_tx = nullptr;
    zft_free_fn zft_free = nullptr;
    zft_state_fn zft_state = nullptr;
    zft_send_fn zft_send = nullptr;
    zft_send_single_fn zft_send_single = nullptr;
    zft_recv_fn zft_recv = nullptr;
    zft_zc_recv_done_fn zft_zc_recv_done = nullptr;
    zft_error_fn zft_error = nullptr;
    zft_to_waitable_fn zft_to_waitable = nullptr;
    zft_handle_free_fn zft_handle_free = nullptr;
    
    bool load() {
        if (handle) return true;
        
        // Try to load libzf
        handle = dlopen("libzf.so", RTLD_NOW | RTLD_LOCAL);
        if (!handle) {
            handle = dlopen("libzf.so.1", RTLD_NOW | RTLD_LOCAL);
        }
        if (!handle) {
            return false;
        }
        
        // Load all symbols
        #define LOAD_SYM(name) \
            name = reinterpret_cast<name##_fn>(dlsym(handle, #name)); \
            if (!name) { unload(); return false; }
        
        LOAD_SYM(zf_init)
        LOAD_SYM(zf_deinit)
        LOAD_SYM(zf_attr_alloc)
        LOAD_SYM(zf_attr_free)
        LOAD_SYM(zf_attr_set_str)
        LOAD_SYM(zf_attr_set_int)
        LOAD_SYM(zf_stack_alloc)
        LOAD_SYM(zf_stack_free)
        LOAD_SYM(zf_reactor_perform)
        LOAD_SYM(zft_alloc)
        LOAD_SYM(zft_addr_bind)
        LOAD_SYM(zft_connect)
        LOAD_SYM(zft_shutdown_tx)
        LOAD_SYM(zft_free)
        LOAD_SYM(zft_state)
        LOAD_SYM(zft_send_single)
        LOAD_SYM(zft_zc_recv_done)
        LOAD_SYM(zft_error)
        
        // Optional symbols (not all versions have these)
        zft_send = reinterpret_cast<zft_send_fn>(dlsym(handle, "zft_send"));
        zft_recv = reinterpret_cast<zft_recv_fn>(dlsym(handle, "zft_recv"));
        zft_to_waitable = reinterpret_cast<zft_to_waitable_fn>(dlsym(handle, "zft_to_waitable"));
        zft_handle_free = reinterpret_cast<zft_handle_free_fn>(dlsym(handle, "zft_handle_free"));
        
        #undef LOAD_SYM
        
        // Initialize ZF
        if (zf_init() != 0) {
            unload();
            return false;
        }
        
        initialized = true;
        return true;
    }
    
    void unload() {
        if (initialized && zf_deinit) {
            zf_deinit();
            initialized = false;
        }
        if (handle) {
            dlclose(handle);
            handle = nullptr;
        }
    }
    
    ~ZFLibrary() {
        unload();
    }
    
    static ZFLibrary& instance() {
        static ZFLibrary lib;
        return lib;
    }
};

inline bool is_available() {
    return ZFLibrary::instance().load();
}

} // namespace tcpdirect

// =============================================================================
// Runtime Capability Detection
// =============================================================================

struct TransportCapabilities {
    bool tcpdirect_available = false;
    bool onload_active = false;
    bool solarflare_nic_present = false;
    std::string solarflare_interface;
    
    static TransportCapabilities detect() {
        TransportCapabilities caps;
        
        // Check for TCPDirect library
        caps.tcpdirect_available = tcpdirect::is_available();
        
        // Check if running under Onload
        caps.onload_active = (getenv("LD_PRELOAD") != nullptr && 
                              strstr(getenv("LD_PRELOAD"), "libonload") != nullptr) ||
                             (getenv("EF_POLL_USEC") != nullptr);
        
        // Check for Solarflare NIC (look for /sys/class/net/*/device/vendor)
        // Solarflare vendor ID: 0x1924 (now AMD/Xilinx)
        const char* interfaces[] = {"eth0", "eth1", "eth2", "eth3", 
                                     "enp1s0f0", "enp1s0f1", "ens1f0", "ens1f1"};
        
        for (const char* iface : interfaces) {
            char path[256];
            snprintf(path, sizeof(path), "/sys/class/net/%s/device/vendor", iface);
            
            FILE* f = fopen(path, "r");
            if (f) {
                char vendor[32];
                if (fgets(vendor, sizeof(vendor), f)) {
                    // Check for Solarflare/Xilinx vendor IDs
                    if (strstr(vendor, "0x1924") || strstr(vendor, "0x10ee")) {
                        caps.solarflare_nic_present = true;
                        caps.solarflare_interface = iface;
                    }
                }
                fclose(f);
                
                if (caps.solarflare_nic_present) break;
            }
        }
        
        return caps;
    }
};

// =============================================================================
// Kernel TCP Transport
// =============================================================================

class KernelTransport : public ITransport {
public:
    explicit KernelTransport(const TransportConfig& config)
        : config_(config)
        , fd_(-1)
        , connected_(false) {}
    
    ~KernelTransport() override {
        disconnect();
    }
    
    bool connect() override {
        if (connected_) return true;
        
        fd_ = socket(AF_INET, SOCK_STREAM, 0);
        if (fd_ < 0) return false;
        
        // Set socket options
        if (config_.tcp_nodelay) {
            int opt = 1;
            setsockopt(fd_, IPPROTO_TCP, TCP_NODELAY, &opt, sizeof(opt));
        }
        
        setsockopt(fd_, SOL_SOCKET, SO_RCVBUF, &config_.recv_buffer_size, sizeof(int));
        setsockopt(fd_, SOL_SOCKET, SO_SNDBUF, &config_.send_buffer_size, sizeof(int));
        
        // Non-blocking connect
        int flags = fcntl(fd_, F_GETFL, 0);
        fcntl(fd_, F_SETFL, flags | O_NONBLOCK);
        
        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(config_.port);
        inet_pton(AF_INET, config_.host.c_str(), &addr.sin_addr);
        
        int ret = ::connect(fd_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr));
        if (ret < 0 && errno != EINPROGRESS) {
            close(fd_);
            fd_ = -1;
            return false;
        }
        
        // Wait for connect with timeout
        int timeout_ms = config_.connect_timeout_ns / 1'000'000;
        pollfd pfd = {fd_, POLLOUT, 0};
        ret = ::poll(&pfd, 1, timeout_ms);
        
        if (ret <= 0) {
            close(fd_);
            fd_ = -1;
            return false;
        }
        
        // Check for errors
        int err = 0;
        socklen_t len = sizeof(err);
        getsockopt(fd_, SOL_SOCKET, SO_ERROR, &err, &len);
        if (err != 0) {
            close(fd_);
            fd_ = -1;
            return false;
        }
        
        connected_ = true;
        stats_.connects.fetch_add(1, std::memory_order_relaxed);
        stats_.last_connect_tsc.store(Timestamp::now_tsc(), std::memory_order_relaxed);
        
        return true;
    }
    
    void disconnect() override {
        if (fd_ >= 0) {
            close(fd_);
            fd_ = -1;
        }
        if (connected_) {
            connected_ = false;
            stats_.disconnects.fetch_add(1, std::memory_order_relaxed);
        }
    }
    
    bool is_connected() const override { return connected_; }
    
    HOT_PATH SendResult send(const void* data, size_t len) override {
        if (!connected_ || fd_ < 0) return SendResult::DISCONNECTED;
        
        ssize_t sent = ::send(fd_, data, len, MSG_NOSIGNAL);
        if (sent < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                return SendResult::WOULD_BLOCK;
            }
            connected_ = false;
            return SendResult::DISCONNECTED;
        }
        
        stats_.bytes_sent.fetch_add(sent, std::memory_order_relaxed);
        return (static_cast<size_t>(sent) == len) ? SendResult::SUCCESS : SendResult::WOULD_BLOCK;
    }
    
    HOT_PATH ssize_t recv(void* buf, size_t max_len) override {
        if (!connected_ || fd_ < 0) return -1;
        
        ssize_t received = ::recv(fd_, buf, max_len, MSG_DONTWAIT);
        if (received > 0) {
            stats_.bytes_received.fetch_add(received, std::memory_order_relaxed);
            stats_.last_activity_tsc.store(Timestamp::now_tsc(), std::memory_order_relaxed);
        } else if (received == 0) {
            connected_ = false;
        }
        
        return received;
    }
    
    // Thread-safe send - can be called from any thread
    HOT_PATH SendResult send_message(MessageType type, const void* payload, size_t len) override {
        if (!connected_ || fd_ < 0) return SendResult::DISCONNECTED;
        
        // Validate payload
        if (len > 0 && payload == nullptr) return SendResult::ERROR;
        if (len > Config::MAX_MESSAGE_SIZE - sizeof(MessageHeader)) return SendResult::ERROR;
        
        // Build message header
        MessageHeader header{};
        header.length = static_cast<uint32_t>(sizeof(MessageHeader) + len);
        header.sequence_number = send_sequence_.fetch_add(1, std::memory_order_relaxed) + 1;
        header.timestamp_ns = Timestamp::now_tsc();
        header.type = type;
        
        // Use writev for atomic header+payload send (fixes partial send corruption)
        struct iovec iov[2];
        iov[0].iov_base = &header;
        iov[0].iov_len = sizeof(header);
        
        int iovcnt = 1;
        if (len > 0 && payload) {
            iov[1].iov_base = const_cast<void*>(payload);
            iov[1].iov_len = len;
            iovcnt = 2;
        }
        
        const size_t total_len = sizeof(header) + len;
        
        // Spinlock for send serialization (multiple threads may call send)
        while (send_lock_.test_and_set(std::memory_order_acquire)) {
            // Spin with pause to reduce contention
            #if defined(__x86_64__) || defined(__i386__)
            __builtin_ia32_pause();
            #endif
        }
        
        ssize_t sent = ::writev(fd_, iov, iovcnt);
        
        send_lock_.clear(std::memory_order_release);
        
        if (sent < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) return SendResult::WOULD_BLOCK;
            connected_ = false;
            return SendResult::DISCONNECTED;
        }
        
        if (static_cast<size_t>(sent) != total_len) {
            // Partial send - this shouldn't happen with small messages but handle it
            connected_ = false;
            return SendResult::DISCONNECTED;
        }
        
        stats_.bytes_sent.fetch_add(total_len, std::memory_order_relaxed);
        stats_.messages_sent.fetch_add(1, std::memory_order_relaxed);
        
        return SendResult::SUCCESS;
    }
    
    void poll() override {
        // Nothing to do for kernel sockets
    }
    
    TransportType type() const override { return TransportType::KERNEL; }
    const char* type_name() const override { return "kernel"; }
    uint64_t estimated_latency_ns() const override { return 5000; }  // ~5μs
    
    const ConnStats& stats() const override { return stats_; }
    
private:
    TransportConfig config_;
    int fd_;
    bool connected_;
    std::atomic<uint32_t> send_sequence_{0};
    std::atomic_flag send_lock_ = ATOMIC_FLAG_INIT;
    ConnStats stats_;
};

// =============================================================================
// TCPDirect Transport (dynamically loaded)
// =============================================================================

class TCPDirectTransport : public ITransport {
public:
    explicit TCPDirectTransport(const TransportConfig& config)
        : config_(config)
        , stack_(nullptr)
        , attr_(nullptr)
        , zock_(nullptr)
        , zock_handle_(nullptr)
        , connected_(false) {
        
        zf_ = &tcpdirect::ZFLibrary::instance();
    }
    
    ~TCPDirectTransport() override {
        disconnect();
        cleanup_stack();
    }
    
    bool connect() override {
        if (connected_) return true;
        
        if (!zf_->load()) {
            return false;
        }
        
        // Allocate attributes
        if (zf_->zf_attr_alloc(&attr_) != 0) {
            return false;
        }
        
        // Set interface
        zf_->zf_attr_set_str(attr_, "interface", config_.interface.c_str());
        
        // Enable CTPIO for ultra-low latency sends
        if (config_.tcpdirect_ctpio) {
            zf_->zf_attr_set_int(attr_, "ctpio_mode", 2);  // sf-always
        }
        
        // Allocate stack
        if (zf_->zf_stack_alloc(attr_, &stack_) != 0) {
            cleanup_stack();
            return false;
        }
        
        // Allocate TCP zocket
        if (zf_->zft_alloc(stack_, attr_, &zock_handle_) != 0) {
            cleanup_stack();
            return false;
        }
        
        // Connect
        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(config_.port);
        inet_pton(AF_INET, config_.host.c_str(), &addr.sin_addr);
        
        if (zf_->zft_connect(zock_handle_, 
                             reinterpret_cast<sockaddr*>(&addr), 
                             sizeof(addr), &zock_) != 0) {
            cleanup_stack();
            return false;
        }
        
        // Poll until connected
        uint64_t start_ns = Timestamp::now_ns();
        
        while (zf_->zft_state(zock_) != tcpdirect::ZFT_STATE_EST) {
            zf_->zf_reactor_perform(stack_);
            
            if (Timestamp::now_ns() - start_ns > config_.connect_timeout_ns) {
                cleanup_stack();
                return false;
            }
            
            // Check for errors
            if (zf_->zft_error(zock_) != 0) {
                cleanup_stack();
                return false;
            }
        }
        
        connected_ = true;
        stats_.connects.fetch_add(1, std::memory_order_relaxed);
        stats_.last_connect_tsc.store(Timestamp::now_tsc(), std::memory_order_relaxed);
        
        return true;
    }
    
    void disconnect() override {
        if (zock_) {
            zf_->zft_shutdown_tx(zock_);
            zf_->zft_free(zock_);
            zock_ = nullptr;
        }
        if (connected_) {
            connected_ = false;
            stats_.disconnects.fetch_add(1, std::memory_order_relaxed);
        }
    }
    
    bool is_connected() const override { return connected_; }
    
    HOT_PATH SendResult send(const void* data, size_t len) override {
        if (!connected_) return SendResult::DISCONNECTED;
        
        int ret = zf_->zft_send_single(zock_, data, len, 0);
        if (ret < 0) {
            if (ret == -EAGAIN) return SendResult::WOULD_BLOCK;
            connected_ = false;
            return SendResult::DISCONNECTED;
        }
        
        stats_.bytes_sent.fetch_add(len, std::memory_order_relaxed);
        return SendResult::SUCCESS;
    }
    
    HOT_PATH ssize_t recv(void* buf, size_t max_len) override {
        if (!connected_) return -1;
        
        // TCPDirect uses zero-copy receive with zft_msg
        // For simplicity, we copy to the provided buffer
        // In production, you'd use the ZC API directly
        
        // Poll first
        zf_->zf_reactor_perform(stack_);
        
        // Check if we have data (simplified - real impl uses zft_recv)
        // This is a placeholder - actual implementation would use zft_zc_recv
        return -1;  // Would need actual ZC recv implementation
    }
    
    // Thread-safe send - can be called from any thread
    HOT_PATH SendResult send_message(MessageType type, const void* payload, size_t len) override {
        if (!connected_) return SendResult::DISCONNECTED;
        
        // Build message
        alignas(64) uint8_t buffer[Config::MAX_MESSAGE_SIZE];
        
        MessageHeader* header = reinterpret_cast<MessageHeader*>(buffer);
        header->length = sizeof(MessageHeader) + len;
        header->sequence_number = send_sequence_.fetch_add(1, std::memory_order_relaxed) + 1;
        header->timestamp_ns = Timestamp::now_tsc();
        header->type = type;
        
        if (len > 0 && payload) {
            std::memcpy(buffer + sizeof(MessageHeader), payload, len);
        }
        
        // Spinlock for send serialization
        while (send_lock_.test_and_set(std::memory_order_acquire)) {
            #if defined(__x86_64__) || defined(__i386__)
            __builtin_ia32_pause();
            #endif
        }
        
        int ret = zf_->zft_send_single(zock_, buffer, sizeof(MessageHeader) + len, 0);
        
        send_lock_.clear(std::memory_order_release);
        
        if (ret < 0) {
            if (ret == -EAGAIN) return SendResult::WOULD_BLOCK;
            connected_ = false;
            return SendResult::DISCONNECTED;
        }
        
        stats_.bytes_sent.fetch_add(sizeof(MessageHeader) + len, std::memory_order_relaxed);
        stats_.messages_sent.fetch_add(1, std::memory_order_relaxed);
        
        return SendResult::SUCCESS;
    }
    
    HOT_PATH void poll() override {
        if (stack_) {
            zf_->zf_reactor_perform(stack_);
        }
    }
    
    TransportType type() const override { return TransportType::TCPDIRECT; }
    const char* type_name() const override { return "tcpdirect"; }
    uint64_t estimated_latency_ns() const override { return 300; }  // ~300ns
    
    const ConnStats& stats() const override { return stats_; }
    
private:
    void cleanup_stack() {
        if (zock_handle_ && zf_->zft_handle_free) {
            zf_->zft_handle_free(zock_handle_);
            zock_handle_ = nullptr;
        }
        if (stack_) {
            zf_->zf_stack_free(stack_);
            stack_ = nullptr;
        }
        if (attr_) {
            zf_->zf_attr_free(attr_);
            attr_ = nullptr;
        }
    }
    
    TransportConfig config_;
    tcpdirect::ZFLibrary* zf_;
    tcpdirect::zf_stack* stack_;
    tcpdirect::zf_attr* attr_;
    tcpdirect::zft* zock_;
    tcpdirect::zft_handle* zock_handle_;
    bool connected_;
    std::atomic<uint32_t> send_sequence_{0};
    std::atomic_flag send_lock_ = ATOMIC_FLAG_INIT;
    ConnStats stats_;
};

// =============================================================================
// Transport Factory
// =============================================================================

class TransportFactory {
public:
    // Create client transport with auto-detection
    static std::unique_ptr<ITransport> create_client(TransportConfig config) {
        TransportType effective_type = config.preferred_type;
        
        // If config says AUTO, check RuntimeConfig (which may use env var)
        if (effective_type == TransportType::AUTO) {
            effective_type = RuntimeConfig::instance().get_transport();
        }
        
        // If still AUTO after RuntimeConfig, detect best available
        if (effective_type == TransportType::AUTO) {
            effective_type = detect_best_transport(config);
        }
        
        return create_transport(effective_type, std::move(config));
    }
    
    // Get capabilities
    static TransportCapabilities get_capabilities() {
        return TransportCapabilities::detect();
    }
    
    // Check if specific transport is available
    static bool is_available(TransportType type) {
        auto caps = TransportCapabilities::detect();
        
        switch (type) {
            case TransportType::TCPDIRECT:
                return caps.tcpdirect_available && caps.solarflare_nic_present;
            case TransportType::ONLOAD:
                return caps.onload_active || caps.solarflare_nic_present;
            case TransportType::KERNEL:
                return true;
            case TransportType::AUTO:
                return true;
            default:
                return false;
        }
    }
    
    // Print available transports and current config
    static void print_available() {
        auto caps = TransportCapabilities::detect();
        auto& cfg = RuntimeConfig::instance();
        
        printf("Transport Configuration:\n");
        printf("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
        
        // Show current setting
        TransportType effective = cfg.get_transport();
        const char* source = cfg.is_explicit() ? "programmatic" : 
                            (getenv("PTPX_TRANSPORT") ? "environment" : "default");
        printf("  Current: %s (source: %s)\n", transport_type_to_string(effective), source);
        
        if (getenv("PTPX_TRANSPORT")) {
            printf("  PTPX_TRANSPORT=%s\n", getenv("PTPX_TRANSPORT"));
        }
        printf("\n");
        
        printf("Available Transports:\n");
        
        if (caps.tcpdirect_available && caps.solarflare_nic_present) {
            printf("  ✓ TCPDirect (libzf.so loaded, NIC: %s) - ~300ns\n",
                   caps.solarflare_interface.c_str());
        } else if (caps.tcpdirect_available) {
            printf("  ✗ TCPDirect (libzf.so loaded, no Solarflare NIC)\n");
        } else {
            printf("  ✗ TCPDirect (libzf.so not found)\n");
        }
        
        if (caps.onload_active) {
            printf("  ✓ OpenOnload (active via LD_PRELOAD) - ~500ns\n");
        } else if (caps.solarflare_nic_present) {
            printf("  ○ OpenOnload (available, run with 'onload ./app') - ~500ns\n");
        } else {
            printf("  ✗ OpenOnload (no Solarflare NIC)\n");
        }
        
        printf("  ✓ Kernel TCP (always available) - ~5μs\n");
        printf("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
        printf("\n");
        printf("To override:\n");
        printf("  ptpx::use_tcpdirect();  // Programmatic\n");
        printf("  export PTPX_TRANSPORT=tcpdirect  // Environment\n");
        printf("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
    }
    
private:
    static TransportType detect_best_transport(const TransportConfig& config) {
        auto caps = TransportCapabilities::detect();
        
        // Prefer TCPDirect if available
        if (caps.tcpdirect_available && caps.solarflare_nic_present) {
            return TransportType::TCPDIRECT;
        }
        
        // Fall back to OpenOnload if active or NIC present
        // (OpenOnload uses same socket API, just accelerated)
        if (caps.onload_active) {
            return TransportType::ONLOAD;
        }
        
        // Default to kernel
        return TransportType::KERNEL;
    }
    
    static std::unique_ptr<ITransport> create_transport(TransportType type, 
                                                        TransportConfig config) {
        switch (type) {
            case TransportType::TCPDIRECT:
                if (tcpdirect::is_available()) {
                    return std::make_unique<TCPDirectTransport>(std::move(config));
                }
                // Fall through to kernel
                [[fallthrough]];
                
            case TransportType::ONLOAD:
                // OpenOnload uses same API as kernel, just faster
                [[fallthrough]];
                
            case TransportType::KERNEL:
            case TransportType::AUTO:
            default:
                return std::make_unique<KernelTransport>(std::move(config));
        }
    }
};

// =============================================================================
// Convenience Macros for Hot Path
// =============================================================================

// Use transport directly in hot path without virtual call overhead
// (for when you know the type at compile time in your critical path)
template<typename Transport>
class DirectTransport {
public:
    template<typename... Args>
    explicit DirectTransport(Args&&... args) : transport_(std::forward<Args>(args)...) {}
    
    HOT_PATH SendResult send(const void* data, size_t len) {
        return transport_.send(data, len);
    }
    
    HOT_PATH ssize_t recv(void* buf, size_t len) {
        return transport_.recv(buf, len);
    }
    
    HOT_PATH void poll() {
        transport_.poll();
    }
    
    Transport& get() { return transport_; }
    
private:
    Transport transport_;
};

} // namespace ptpx
