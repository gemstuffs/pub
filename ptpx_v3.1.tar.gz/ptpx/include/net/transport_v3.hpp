// =============================================================================
// ptpx v3.0 - Transport Layer
// =============================================================================
//
// Two kernel-bypass transports for Solarflare NICs:
//   1. TCPDirect - ZF API, lowest latency (~200-400ns)
//   2. Onload    - Socket API accelerated via LD_PRELOAD (~500ns-1µs)
//
// Both support hardware timestamps for accurate latency measurement.
//
// THREADING:
//   - send() is thread-safe (spinlock protected)
//   - recv()/poll() called from poll thread only
//
// =============================================================================

#pragma once

#include "../core/common.hpp"
#include "../core/hw_timestamp.hpp"

#include <memory>
#include <string>
#include <atomic>
#include <cstring>
#include <dlfcn.h>

#ifdef __linux__
#include <sys/socket.h>
#include <sys/uio.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#endif

namespace ptpx {

// =============================================================================
// Transport Type
// =============================================================================

enum class TransportType : uint8_t {
    TCPDIRECT = 0,   // ZF API (Solarflare)
    ONLOAD           // Socket API + Onload (Solarflare)
};

inline const char* to_string(TransportType t) {
    switch (t) {
        case TransportType::TCPDIRECT: return "tcpdirect";
        case TransportType::ONLOAD: return "onload";
        default: return "unknown";
    }
}

// =============================================================================
// Transport Configuration
// =============================================================================

struct TransportConfig {
    std::string host;
    uint16_t port = 0;
    std::string interface;           // Network interface (e.g., "enp1s0f0")
    TransportType type = TransportType::ONLOAD;  // Default to Onload
    bool tcp_nodelay = true;
    int send_buffer_size = 65536;
    int recv_buffer_size = 65536;
    bool enable_hw_timestamps = true;
    
    bool is_valid() const {
        return !host.empty() && port > 0;
    }
};

// =============================================================================
// Transport Statistics
// =============================================================================

struct alignas(64) TransportStats {
    std::atomic<uint64_t> bytes_sent{0};
    std::atomic<uint64_t> bytes_received{0};
    std::atomic<uint64_t> messages_sent{0};
    std::atomic<uint64_t> messages_received{0};
    std::atomic<uint64_t> send_errors{0};
    std::atomic<uint64_t> recv_errors{0};
    
    void reset() {
        bytes_sent.store(0, std::memory_order_relaxed);
        bytes_received.store(0, std::memory_order_relaxed);
        messages_sent.store(0, std::memory_order_relaxed);
        messages_received.store(0, std::memory_order_relaxed);
        send_errors.store(0, std::memory_order_relaxed);
        recv_errors.store(0, std::memory_order_relaxed);
    }
};

// =============================================================================
// Transport Interface
// =============================================================================

class ITransport {
public:
    virtual ~ITransport() = default;
    
    // Connection
    virtual bool connect() = 0;
    virtual void disconnect() = 0;
    virtual bool is_connected() const = 0;
    
    // I/O - send() is thread-safe, recv()/poll() from poll thread only
    virtual SendResult send(const void* data, size_t len) = 0;
    virtual ssize_t recv(void* buf, size_t max_len) = 0;
    virtual void poll() = 0;
    
    // Message-based I/O
    virtual SendResult send_message(MessageType type, const void* payload, size_t len) = 0;
    
    // Hardware timestamps
    virtual HWTimestamp get_last_tx_timestamp() = 0;
    virtual HWTimestamp get_last_rx_timestamp() = 0;
    virtual bool hw_timestamps_supported() const = 0;
    
    // Info
    virtual TransportType type() const = 0;
    virtual const char* name() const = 0;
    virtual uint64_t estimated_latency_ns() const = 0;
    
    // Stats
    virtual const TransportStats& stats() const = 0;
    virtual void reset_stats() = 0;
};

// =============================================================================
// TCPDirect ZF API Types
// =============================================================================

namespace zf {

// Opaque types
struct zf_stack;
struct zf_attr;
struct zft;
struct zft_handle;

// Message structure (simplified, matches ZF API layout)
struct zft_msg {
    struct iovec iov;
    int iovcnt;
    int flags;
    int pkts;
};

// Function pointer types
using zf_init_fn = int(*)();
using zf_deinit_fn = void(*)();
using zf_attr_alloc_fn = int(*)(zf_attr**);
using zf_attr_free_fn = void(*)(zf_attr*);
using zf_attr_set_str_fn = int(*)(zf_attr*, const char*, const char*);
using zf_attr_set_int_fn = int(*)(zf_attr*, const char*, int);
using zf_stack_alloc_fn = int(*)(zf_attr*, zf_stack**);
using zf_stack_free_fn = int(*)(zf_stack*);
using zf_reactor_perform_fn = int(*)(zf_stack*);
using zft_alloc_fn = int(*)(zf_stack*, zf_attr*, zft_handle**);
using zft_addr_bind_fn = int(*)(zft_handle*, const sockaddr*, socklen_t, int);
using zft_connect_fn = int(*)(zft_handle*, const sockaddr*, socklen_t, zft**);
using zft_shutdown_tx_fn = int(*)(zft*);
using zft_free_fn = int(*)(zft*);
using zft_state_fn = int(*)(zft*);
using zft_send_fn = int(*)(zft*, const iovec*, int, int);
using zft_send_single_fn = int(*)(zft*, const void*, size_t, int);
using zft_recv_fn = int(*)(zft*, zft_msg*, int);
using zft_zc_recv_done_fn = void(*)(zft*, zft_msg*);
using zft_pkt_get_timestamp_fn = uint64_t(*)(zft*, const zft_msg*);
using zft_handle_free_fn = int(*)(zft_handle*);

// Constants
constexpr int ZFT_STATE_EST = 1;

// Library handle
struct Library {
    void* handle = nullptr;
    bool initialized = false;
    
    zf_init_fn init = nullptr;
    zf_deinit_fn deinit = nullptr;
    zf_attr_alloc_fn attr_alloc = nullptr;
    zf_attr_free_fn attr_free = nullptr;
    zf_attr_set_str_fn attr_set_str = nullptr;
    zf_attr_set_int_fn attr_set_int = nullptr;
    zf_stack_alloc_fn stack_alloc = nullptr;
    zf_stack_free_fn stack_free = nullptr;
    zf_reactor_perform_fn reactor_perform = nullptr;
    zft_alloc_fn zft_alloc = nullptr;
    zft_addr_bind_fn zft_addr_bind = nullptr;
    zft_connect_fn zft_connect = nullptr;
    zft_shutdown_tx_fn zft_shutdown_tx = nullptr;
    zft_free_fn zft_free = nullptr;
    zft_state_fn zft_state = nullptr;
    zft_send_fn zft_send = nullptr;
    zft_send_single_fn zft_send_single = nullptr;
    zft_recv_fn zft_recv = nullptr;
    zft_zc_recv_done_fn zft_zc_recv_done = nullptr;
    zft_pkt_get_timestamp_fn zft_pkt_get_timestamp = nullptr;
    zft_handle_free_fn zft_handle_free = nullptr;
    
    static Library& instance() {
        static Library lib;
        return lib;
    }
    
    bool load() {
        if (handle) return initialized;
        
        handle = dlopen("libzf.so", RTLD_NOW);
        if (!handle) return false;
        
        #define LOAD_SYM(name) \
            name = reinterpret_cast<decltype(name)>(dlsym(handle, "zf_" #name)); \
            if (!name) name = reinterpret_cast<decltype(name)>(dlsym(handle, #name))
        
        LOAD_SYM(init);
        LOAD_SYM(deinit);
        LOAD_SYM(attr_alloc);
        LOAD_SYM(attr_free);
        LOAD_SYM(attr_set_str);
        LOAD_SYM(attr_set_int);
        LOAD_SYM(stack_alloc);
        LOAD_SYM(stack_free);
        LOAD_SYM(reactor_perform);
        LOAD_SYM(zft_alloc);
        LOAD_SYM(zft_addr_bind);
        LOAD_SYM(zft_connect);
        LOAD_SYM(zft_shutdown_tx);
        LOAD_SYM(zft_free);
        LOAD_SYM(zft_state);
        LOAD_SYM(zft_send);
        LOAD_SYM(zft_send_single);
        LOAD_SYM(zft_recv);
        LOAD_SYM(zft_zc_recv_done);
        LOAD_SYM(zft_pkt_get_timestamp);
        LOAD_SYM(zft_handle_free);
        
        #undef LOAD_SYM
        
        if (init && init() == 0) {
            initialized = true;
        }
        
        return initialized;
    }
    
    ~Library() {
        if (initialized && deinit) {
            deinit();
        }
        if (handle) {
            dlclose(handle);
        }
    }
};

}  // namespace zf

// =============================================================================
// TCPDirect Transport
// =============================================================================

class TCPDirectTransport : public ITransport {
public:
    explicit TCPDirectTransport(const TransportConfig& config)
        : config_(config)
        , stack_(nullptr)
        , attr_(nullptr)
        , zock_(nullptr)
        , zock_handle_(nullptr)
        , connected_(false)
        , zf_(&zf::Library::instance()) 
    {
    }
    
    ~TCPDirectTransport() override {
        disconnect();
    }
    
    bool connect() override {
        if (connected_) return true;
        
        // Load ZF library
        if (!zf_->load()) {
            return false;
        }
        
        // Allocate attributes
        if (zf_->attr_alloc(&attr_) != 0) {
            return false;
        }
        
        // Set interface
        if (!config_.interface.empty()) {
            zf_->attr_set_str(attr_, "interface", config_.interface.c_str());
        }
        
        // Allocate stack
        if (zf_->stack_alloc(attr_, &stack_) != 0) {
            cleanup();
            return false;
        }
        
        // Allocate zocket handle
        if (zf_->zft_alloc(stack_, attr_, &zock_handle_) != 0) {
            cleanup();
            return false;
        }
        
        // Connect
        struct sockaddr_in addr;
        std::memset(&addr, 0, sizeof(addr));
        addr.sin_family = AF_INET;
        addr.sin_port = htons(config_.port);
        inet_pton(AF_INET, config_.host.c_str(), &addr.sin_addr);
        
        if (zf_->zft_connect(zock_handle_, 
                             reinterpret_cast<sockaddr*>(&addr), 
                             sizeof(addr), 
                             &zock_) != 0) {
            cleanup();
            return false;
        }
        
        // Wait for connection
        for (int i = 0; i < 100; ++i) {
            zf_->reactor_perform(stack_);
            if (zf_->zft_state(zock_) == zf::ZFT_STATE_EST) {
                connected_ = true;
                return true;
            }
            usleep(10000);  // 10ms
        }
        
        cleanup();
        return false;
    }
    
    void disconnect() override {
        if (zock_) {
            zf_->zft_shutdown_tx(zock_);
            zf_->zft_free(zock_);
            zock_ = nullptr;
        }
        cleanup();
        connected_ = false;
    }
    
    bool is_connected() const override { return connected_; }
    
    // Thread-safe send
    SendResult send(const void* data, size_t len) override {
        if (!connected_) return SendResult::DISCONNECTED;
        
        while (send_lock_.test_and_set(std::memory_order_acquire)) {
            #if defined(__x86_64__) || defined(__i386__)
            __builtin_ia32_pause();
            #endif
        }
        
        int ret = zf_->zft_send_single(zock_, data, len, 0);
        last_tx_ts_ = HWTimestamp::now_sw();  // TODO: Get actual HW timestamp
        
        send_lock_.clear(std::memory_order_release);
        
        if (ret < 0) {
            stats_.send_errors.fetch_add(1, std::memory_order_relaxed);
            if (ret == -EAGAIN) return SendResult::WOULD_BLOCK;
            connected_ = false;
            return SendResult::DISCONNECTED;
        }
        
        stats_.bytes_sent.fetch_add(len, std::memory_order_relaxed);
        return SendResult::SUCCESS;
    }
    
    // Thread-safe send_message
    SendResult send_message(MessageType type, const void* payload, size_t len) override {
        if (!connected_) return SendResult::DISCONNECTED;
        
        alignas(64) uint8_t buffer[Config::MAX_MESSAGE_SIZE];
        
        auto* header = reinterpret_cast<MessageHeader*>(buffer);
        header->length = static_cast<uint32_t>(sizeof(MessageHeader) + len);
        header->sequence_number = send_sequence_.fetch_add(1, std::memory_order_relaxed) + 1;
        header->timestamp_ns = Timestamp::now_tsc();
        header->type = type;
        
        if (len > 0 && payload) {
            std::memcpy(buffer + sizeof(MessageHeader), payload, len);
        }
        
        while (send_lock_.test_and_set(std::memory_order_acquire)) {
            #if defined(__x86_64__) || defined(__i386__)
            __builtin_ia32_pause();
            #endif
        }
        
        int ret = zf_->zft_send_single(zock_, buffer, sizeof(MessageHeader) + len, 0);
        last_tx_ts_ = HWTimestamp::now_sw();
        
        send_lock_.clear(std::memory_order_release);
        
        if (ret < 0) {
            stats_.send_errors.fetch_add(1, std::memory_order_relaxed);
            if (ret == -EAGAIN) return SendResult::WOULD_BLOCK;
            connected_ = false;
            return SendResult::DISCONNECTED;
        }
        
        stats_.bytes_sent.fetch_add(sizeof(MessageHeader) + len, std::memory_order_relaxed);
        stats_.messages_sent.fetch_add(1, std::memory_order_relaxed);
        return SendResult::SUCCESS;
    }
    
    ssize_t recv(void* buf, size_t max_len) override {
        if (!connected_) return -1;
        
        struct {
            zf::zft_msg msg;
            struct iovec iov;
        } msg_buf;
        
        msg_buf.msg.iovcnt = 1;
        
        int rc = zf_->zft_recv(zock_, &msg_buf.msg, 1);
        if (rc <= 0) return rc;
        
        size_t to_copy = msg_buf.iov.iov_len;
        if (to_copy > max_len) to_copy = max_len;
        
        std::memcpy(buf, msg_buf.iov.iov_base, to_copy);
        
        // Get HW timestamp if available
        if (zf_->zft_pkt_get_timestamp) {
            last_rx_ts_ = HWTimestamp(
                zf_->zft_pkt_get_timestamp(zock_, &msg_buf.msg),
                true, true
            );
        } else {
            last_rx_ts_ = HWTimestamp::now_sw();
        }
        
        zf_->zft_zc_recv_done(zock_, &msg_buf.msg);
        
        stats_.bytes_received.fetch_add(to_copy, std::memory_order_relaxed);
        return static_cast<ssize_t>(to_copy);
    }
    
    void poll() override {
        if (stack_) {
            zf_->reactor_perform(stack_);
        }
    }
    
    HWTimestamp get_last_tx_timestamp() override { return last_tx_ts_; }
    HWTimestamp get_last_rx_timestamp() override { return last_rx_ts_; }
    bool hw_timestamps_supported() const override { return zf_->zft_pkt_get_timestamp != nullptr; }
    
    TransportType type() const override { return TransportType::TCPDIRECT; }
    const char* name() const override { return "tcpdirect"; }
    uint64_t estimated_latency_ns() const override { return 300; }
    
    const TransportStats& stats() const override { return stats_; }
    void reset_stats() override { stats_.reset(); }
    
private:
    void cleanup() {
        if (zock_handle_ && zf_->zft_handle_free) {
            zf_->zft_handle_free(zock_handle_);
            zock_handle_ = nullptr;
        }
        if (stack_) {
            zf_->stack_free(stack_);
            stack_ = nullptr;
        }
        if (attr_) {
            zf_->attr_free(attr_);
            attr_ = nullptr;
        }
    }
    
    TransportConfig config_;
    zf::zf_stack* stack_;
    zf::zf_attr* attr_;
    zf::zft* zock_;
    zf::zft_handle* zock_handle_;
    bool connected_;
    zf::Library* zf_;
    
    std::atomic_flag send_lock_ = ATOMIC_FLAG_INIT;
    std::atomic<uint32_t> send_sequence_{0};
    
    HWTimestamp last_tx_ts_;
    HWTimestamp last_rx_ts_;
    TransportStats stats_;
};

// =============================================================================
// Onload Transport (Socket API, accelerated by Onload)
// =============================================================================

class OnloadTransport : public ITransport {
public:
    explicit OnloadTransport(const TransportConfig& config)
        : config_(config)
        , fd_(-1)
        , connected_(false)
        , hw_timestamps_enabled_(false)
    {
    }
    
    ~OnloadTransport() override {
        disconnect();
    }
    
    bool connect() override {
        if (connected_) return true;
        
        fd_ = socket(AF_INET, SOCK_STREAM, 0);
        if (fd_ < 0) return false;
        
        // Set TCP_NODELAY
        if (config_.tcp_nodelay) {
            int flag = 1;
            setsockopt(fd_, IPPROTO_TCP, TCP_NODELAY, &flag, sizeof(flag));
        }
        
        // Set buffer sizes
        setsockopt(fd_, SOL_SOCKET, SO_SNDBUF, &config_.send_buffer_size, sizeof(int));
        setsockopt(fd_, SOL_SOCKET, SO_RCVBUF, &config_.recv_buffer_size, sizeof(int));
        
        // Enable hardware timestamps if requested
        if (config_.enable_hw_timestamps) {
            hw_timestamps_enabled_ = hw_timestamp::enable(fd_);
            if (!hw_timestamps_enabled_) {
                // Fall back to software timestamps
                hw_timestamp::enable_software(fd_);
            }
        }
        
        // Connect
        struct sockaddr_in addr;
        std::memset(&addr, 0, sizeof(addr));
        addr.sin_family = AF_INET;
        addr.sin_port = htons(config_.port);
        inet_pton(AF_INET, config_.host.c_str(), &addr.sin_addr);
        
        if (::connect(fd_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) < 0) {
            close(fd_);
            fd_ = -1;
            return false;
        }
        
        // Set non-blocking after connect
        int flags = fcntl(fd_, F_GETFL, 0);
        fcntl(fd_, F_SETFL, flags | O_NONBLOCK);
        
        connected_ = true;
        return true;
    }
    
    void disconnect() override {
        if (fd_ >= 0) {
            close(fd_);
            fd_ = -1;
        }
        connected_ = false;
    }
    
    bool is_connected() const override { return connected_; }
    
    // Thread-safe send
    SendResult send(const void* data, size_t len) override {
        if (!connected_ || fd_ < 0) return SendResult::DISCONNECTED;
        
        while (send_lock_.test_and_set(std::memory_order_acquire)) {
            #if defined(__x86_64__) || defined(__i386__)
            __builtin_ia32_pause();
            #endif
        }
        
        ssize_t sent = ::send(fd_, data, len, MSG_NOSIGNAL);
        
        // Record TX timestamp
        if (hw_timestamps_enabled_) {
            last_tx_ts_ = hw_timestamp::get_tx_timestamp(fd_);
        } else {
            last_tx_ts_ = HWTimestamp::now_sw();
        }
        
        send_lock_.clear(std::memory_order_release);
        
        if (sent < 0) {
            stats_.send_errors.fetch_add(1, std::memory_order_relaxed);
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                return SendResult::WOULD_BLOCK;
            }
            connected_ = false;
            return SendResult::DISCONNECTED;
        }
        
        stats_.bytes_sent.fetch_add(static_cast<uint64_t>(sent), std::memory_order_relaxed);
        return SendResult::SUCCESS;
    }
    
    // Thread-safe send_message with framing
    SendResult send_message(MessageType type, const void* payload, size_t len) override {
        if (!connected_ || fd_ < 0) return SendResult::DISCONNECTED;
        if (len > Config::MAX_MESSAGE_SIZE - sizeof(MessageHeader)) return SendResult::ERROR;
        
        MessageHeader header{};
        header.length = static_cast<uint32_t>(sizeof(MessageHeader) + len);
        header.sequence_number = send_sequence_.fetch_add(1, std::memory_order_relaxed) + 1;
        header.timestamp_ns = Timestamp::now_tsc();
        header.type = type;
        
        struct iovec iov[2];
        iov[0].iov_base = &header;
        iov[0].iov_len = sizeof(header);
        
        int iovcnt = 1;
        if (len > 0 && payload) {
            iov[1].iov_base = const_cast<void*>(payload);
            iov[1].iov_len = len;
            iovcnt = 2;
        }
        
        const size_t total_len = sizeof(header) + len;
        
        while (send_lock_.test_and_set(std::memory_order_acquire)) {
            #if defined(__x86_64__) || defined(__i386__)
            __builtin_ia32_pause();
            #endif
        }
        
        ssize_t sent = writev(fd_, iov, iovcnt);
        
        if (hw_timestamps_enabled_) {
            last_tx_ts_ = hw_timestamp::get_tx_timestamp(fd_);
        } else {
            last_tx_ts_ = HWTimestamp::now_sw();
        }
        
        send_lock_.clear(std::memory_order_release);
        
        if (sent < 0) {
            stats_.send_errors.fetch_add(1, std::memory_order_relaxed);
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                return SendResult::WOULD_BLOCK;
            }
            connected_ = false;
            return SendResult::DISCONNECTED;
        }
        
        if (static_cast<size_t>(sent) != total_len) {
            connected_ = false;
            return SendResult::DISCONNECTED;
        }
        
        stats_.bytes_sent.fetch_add(total_len, std::memory_order_relaxed);
        stats_.messages_sent.fetch_add(1, std::memory_order_relaxed);
        return SendResult::SUCCESS;
    }
    
    ssize_t recv(void* buf, size_t max_len) override {
        if (!connected_ || fd_ < 0) return -1;
        
        if (hw_timestamps_enabled_) {
            // Use recvmsg to get timestamps
            struct msghdr msg = {};
            struct iovec iov = {buf, max_len};
            char control[256];
            
            msg.msg_iov = &iov;
            msg.msg_iovlen = 1;
            msg.msg_control = control;
            msg.msg_controllen = sizeof(control);
            
            ssize_t n = recvmsg(fd_, &msg, 0);
            if (n > 0) {
                last_rx_ts_ = hw_timestamp::extract_from_cmsg(&msg);
                if (!last_rx_ts_.valid) {
                    last_rx_ts_ = HWTimestamp::now_sw();
                }
                stats_.bytes_received.fetch_add(static_cast<uint64_t>(n), std::memory_order_relaxed);
            } else if (n < 0 && errno != EAGAIN && errno != EWOULDBLOCK) {
                stats_.recv_errors.fetch_add(1, std::memory_order_relaxed);
            }
            return n;
        } else {
            ssize_t n = ::recv(fd_, buf, max_len, 0);
            if (n > 0) {
                last_rx_ts_ = HWTimestamp::now_sw();
                stats_.bytes_received.fetch_add(static_cast<uint64_t>(n), std::memory_order_relaxed);
            } else if (n < 0 && errno != EAGAIN && errno != EWOULDBLOCK) {
                stats_.recv_errors.fetch_add(1, std::memory_order_relaxed);
            }
            return n;
        }
    }
    
    void poll() override {
        // Nothing to do for socket-based transport
    }
    
    HWTimestamp get_last_tx_timestamp() override { return last_tx_ts_; }
    HWTimestamp get_last_rx_timestamp() override { return last_rx_ts_; }
    bool hw_timestamps_supported() const override { return hw_timestamps_enabled_; }
    
    TransportType type() const override { return TransportType::ONLOAD; }
    const char* name() const override { return "onload"; }
    uint64_t estimated_latency_ns() const override { return 800; }
    
    const TransportStats& stats() const override { return stats_; }
    void reset_stats() override { stats_.reset(); }
    
private:
    TransportConfig config_;
    int fd_;
    bool connected_;
    bool hw_timestamps_enabled_;
    
    std::atomic_flag send_lock_ = ATOMIC_FLAG_INIT;
    std::atomic<uint32_t> send_sequence_{0};
    
    HWTimestamp last_tx_ts_;
    HWTimestamp last_rx_ts_;
    TransportStats stats_;
};

// =============================================================================
// Transport Factory
// =============================================================================

class TransportFactory {
public:
    static std::unique_ptr<ITransport> create(const TransportConfig& config) {
        switch (config.type) {
            case TransportType::TCPDIRECT:
                return std::make_unique<TCPDirectTransport>(config);
            case TransportType::ONLOAD:
            default:
                return std::make_unique<OnloadTransport>(config);
        }
    }
    
    static bool is_tcpdirect_available() {
        return zf::Library::instance().load();
    }
    
    static bool is_onload_active() {
        // Check if Onload is loaded via LD_PRELOAD
        return getenv("LD_PRELOAD") != nullptr && 
               strstr(getenv("LD_PRELOAD"), "onload") != nullptr;
    }
    
    static TransportType detect_best() {
        if (is_tcpdirect_available()) {
            return TransportType::TCPDIRECT;
        }
        return TransportType::ONLOAD;
    }
    
    static void print_available() {
        printf("Available Transports:\n");
        printf("  TCPDirect:  %s\n", is_tcpdirect_available() ? "available" : "not available");
        printf("  Onload:     %s\n", is_onload_active() ? "active" : "not active (will use kernel)");
    }
};

} // namespace ptpx
