#pragma once

#include "../core/common.hpp"
#include <flatbuffers/flatbuffers.h>
#include <array>

namespace ptpx {

// =============================================================================
// FlatBuffer Builder Pool
// Pre-allocated builders to avoid allocation in hot path
// =============================================================================

template<size_t POOL_SIZE = 16, size_t BUILDER_SIZE = 4096>
class FlatBufferBuilderPool {
public:
    FlatBufferBuilderPool() noexcept : next_index_(0) {
        // Builders are default-constructed and ready to use
    }
    
    // Acquire a builder - resets it automatically
    HOT_PATH flatbuffers::FlatBufferBuilder* acquire() noexcept {
        size_t idx = next_index_.fetch_add(1, std::memory_order_relaxed) & MASK;
        auto& builder = builders_[idx];
        builder.Reset();
        return &builder;
    }
    
    // For single-threaded use - faster
    HOT_PATH flatbuffers::FlatBufferBuilder* acquire_st() noexcept {
        size_t idx = st_index_++ & MASK;
        auto& builder = builders_[idx];
        builder.Reset();
        return &builder;
    }
    
private:
    static constexpr size_t MASK = POOL_SIZE - 1;
    static_assert((POOL_SIZE & (POOL_SIZE - 1)) == 0, "Pool size must be power of 2");
    
    std::array<flatbuffers::FlatBufferBuilder, POOL_SIZE> builders_;
    std::atomic<size_t> next_index_;
    size_t st_index_ = 0;  // Single-threaded index
};

// =============================================================================
// Zero-Copy Message Reader
// Wraps FlatBuffer for safe zero-copy access
// =============================================================================

template<typename T>
class FlatBufferReader {
public:
    FlatBufferReader() noexcept : root_(nullptr), data_(nullptr), size_(0) {}
    
    // Initialize from raw buffer (zero-copy)
    HOT_PATH bool initialize(const uint8_t* data, size_t size) noexcept {
        if (UNLIKELY(data == nullptr || size == 0)) {
            return false;
        }
        
        // Verify buffer (can be disabled for performance)
#ifdef FLATBUFFER_VERIFY
        flatbuffers::Verifier verifier(data, size);
        if (!verifier.VerifyBuffer<T>()) {
            return false;
        }
#endif
        
        data_ = data;
        size_ = size;
        root_ = flatbuffers::GetRoot<T>(data);
        return root_ != nullptr;
    }
    
    FORCE_INLINE const T* get() const noexcept { return root_; }
    FORCE_INLINE const T* operator->() const noexcept { return root_; }
    FORCE_INLINE operator bool() const noexcept { return root_ != nullptr; }
    
    FORCE_INLINE const uint8_t* data() const noexcept { return data_; }
    FORCE_INLINE size_t size() const noexcept { return size_; }
    
private:
    const T* root_;
    const uint8_t* data_;
    size_t size_;
};

// =============================================================================
// Message Framing Helper
// Packages FlatBuffer with wire header
// =============================================================================

class MessageFramer {
public:
    MessageFramer() noexcept : builder_pool_() {}
    
    // Build and frame a FlatBuffer message
    template<typename BuildFunc>
    HOT_PATH std::pair<const uint8_t*, size_t> build(
            MessageType type, 
            BuildFunc&& build_func) {
        
        auto* builder = builder_pool_.acquire_st();
        
        // Let caller build the FlatBuffer
        auto offset = build_func(*builder);
        builder->Finish(offset);
        
        // Get buffer
        const uint8_t* buf = builder->GetBufferPointer();
        size_t buf_size = builder->GetSize();
        
        return {buf, buf_size};
    }
    
    // For pre-built FlatBuffer data
    static constexpr size_t header_size() noexcept {
        return MessageHeader::SIZE;
    }
    
private:
    FlatBufferBuilderPool<> builder_pool_;
};

// =============================================================================
// Message Dispatcher
// Type-safe dispatch based on MessageType
// =============================================================================

template<typename Derived>
class MessageDispatcher {
public:
    // Dispatch incoming message to appropriate handler
    HOT_PATH void dispatch(const MessageHeader& header, const uint8_t* payload, size_t payload_len) {
        Derived* self = static_cast<Derived*>(this);
        
        switch (header.type) {
            case MessageType::NEW_ORDER:
                self->on_new_order(payload, payload_len, header);
                break;
            case MessageType::CANCEL_ORDER:
                self->on_cancel_order(payload, payload_len, header);
                break;
            case MessageType::MODIFY_ORDER:
                self->on_modify_order(payload, payload_len, header);
                break;
            case MessageType::EXECUTION_REPORT:
                self->on_execution_report(payload, payload_len, header);
                break;
            case MessageType::ORDER_REJECT:
                self->on_order_reject(payload, payload_len, header);
                break;
            case MessageType::CANCEL_REJECT:
                self->on_cancel_reject(payload, payload_len, header);
                break;
            default:
                self->on_unknown_message(header.type, payload, payload_len);
                break;
        }
    }
    
protected:
    // Default implementations - override in derived class
    void on_new_order(const uint8_t*, size_t, const MessageHeader&) {}
    void on_cancel_order(const uint8_t*, size_t, const MessageHeader&) {}
    void on_modify_order(const uint8_t*, size_t, const MessageHeader&) {}
    void on_execution_report(const uint8_t*, size_t, const MessageHeader&) {}
    void on_order_reject(const uint8_t*, size_t, const MessageHeader&) {}
    void on_cancel_reject(const uint8_t*, size_t, const MessageHeader&) {}
    void on_unknown_message(MessageType, const uint8_t*, size_t) {}
};

} // namespace ptpx
