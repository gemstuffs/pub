#pragma once

// =============================================================================
// ptpx
// Ultra-Low-Latency TCP for HFT Order Entry & Execution
// 
// Supported Technologies (in order of latency):
// 1. TCPDirect:     ~200-400ns  - Solarflare NICs (ZF API)
// 2. OpenOnload:    ~500-800ns  - Solarflare NICs (LD_PRELOAD)
// 3. epoll:         ~3-8μs      - Any NIC (fallback)
// =============================================================================

// Core utilities
#include "core/common.hpp"
#include "core/ring_buffer.hpp"
#include "core/timer_wheel.hpp"
#include "core/thread_registry.hpp"

// Kernel bypass detection
#include "net/kernel_bypass.hpp"

// Connection management (reconnect, heartbeat, sequence tracking)
#include "net/connection_manager.hpp"

// Runtime transport selection (auto-detects TCPDirect/OpenOnload/Kernel)
#include "net/transport.hpp"

// Session layer (configuration-driven, transport-agnostic)
#include "net/session.hpp"
#include "net/session_impl.hpp"

// High-level exchange client/server (fully abstracted)
#include "net/exchange.hpp"

// Standard networking (epoll-based fallback)
#include "net/tcp_session.hpp"
#include "net/tcp_server.hpp"
#include "net/tcp_client.hpp"

// Legacy TCPDirect direct API (for backwards compatibility)
// New code should use ExchangeClient or TransportFactory instead
#include "net/tcpdirect_server.hpp"
#include "net/tcpdirect_client.hpp"

namespace ptpx {

// Library version
constexpr int VERSION_MAJOR = 3;
constexpr int VERSION_MINOR = 0;
constexpr int VERSION_PATCH = 0;

// Initialize library (call once at startup)
inline void initialize() {
    Timestamp::calibrate();
}

// Print available transports and capabilities
inline void print_capabilities() {
    printf("ptpx v%d.%d.%d\n", 
           VERSION_MAJOR, VERSION_MINOR, VERSION_PATCH);
    printf("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
    
    TransportFactory::print_available();
    
    auto caps = TransportCapabilities::detect();
    printf("\nHardware Detection:\n");
    printf("  Solarflare NIC:  %s\n", 
           caps.solarflare_nic_present ? caps.solarflare_interface.c_str() : "Not found");
    printf("  TCPDirect:       %s\n", 
           caps.tcpdirect_available ? "libzf.so loaded" : "Not available");
    printf("  OpenOnload:      %s\n", 
           caps.onload_active ? "Active (LD_PRELOAD)" : "Not active");
    printf("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
}

} // namespace ptpx
