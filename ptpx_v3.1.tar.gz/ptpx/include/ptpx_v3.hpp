// =============================================================================
// ptpx v3.0
// Ultra-Low-Latency TCP for HFT Order Entry & Execution
// =============================================================================
//
// Supported Technologies (Solarflare NICs):
//   1. TCPDirect:  ~200-400ns  - ZF API, lowest latency
//   2. Onload:     ~500ns-1µs  - Socket API accelerated via LD_PRELOAD
//
// THREADING MODEL:
//   - Sessions bind to named poll threads (or get dedicated threads)
//   - send_immediate() - From callback only, zero overhead
//   - send_async()     - From any thread, lock-free queue
//   - send()           - Auto-detects context
//
// LATENCY MEASUREMENT:
//   - Hardware timestamps from Solarflare NIC for accurate measurement
//   - LatencyStats tracks min/max/avg RTT at wire level
//
// =============================================================================

#pragma once

// Core utilities
#include "core/common.hpp"
#include "core/ring_buffer.hpp"
#include "core/timer_wheel.hpp"
#include "core/mpsc_queue.hpp"
#include "core/hw_timestamp.hpp"
#include "core/thread_registry.hpp"

// Transport layer
#include "net/transport_v3.hpp"

// Session layer
#include "net/session_v3.hpp"

namespace ptpx {

// Library version
constexpr int VERSION_MAJOR = 3;
constexpr int VERSION_MINOR = 0;
constexpr int VERSION_PATCH = 0;

// Initialize library (call once at startup)
inline void initialize() {
    Timestamp::calibrate();
}

// Print available transports and capabilities
inline void print_capabilities() {
    printf("ptpx v%d.%d.%d\n", 
           VERSION_MAJOR, VERSION_MINOR, VERSION_PATCH);
    printf("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
    
    TransportFactory::print_available();
    
    printf("\nThreading Model:\n");
    printf("  send_immediate() - Callback only, ~0ns overhead\n");
    printf("  send_async()     - Any thread, ~15ns queue push\n");
    printf("  send()           - Auto-detect, best path\n");
    
    printf("\nLatency Measurement:\n");
    printf("  Hardware timestamps: %s\n", 
           TransportFactory::is_tcpdirect_available() ? "Solarflare NIC" : "Software fallback");
    
    printf("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
}

// Quick start example
inline void print_usage() {
    printf(R"(
Quick Start:

// 1. Register named thread
ptpx::register_thread("IO_CME")
    .cpu_affinity(2)
    .priority(ThreadPriority::REALTIME)
    .create();

// 2. Create session
auto session = ptpx::session("CME_ORDERS")
    .tcpdirect()                    // or .onload()
    .connect_to("10.0.0.1", 9000)
    .thread("IO_CME")               // Use named thread
    .hw_timestamps(true)            // Enable HW timestamps
    .create();

// 3. Set callbacks
SessionCallbacks cb;
cb.on_message = [&](auto& session, auto& hdr, auto* payload, size_t len) {
    auto response = process(payload, len);
    session.send_immediate(MessageType::APPLICATION, response, len);
};
session->set_callbacks(cb);

// 4. Start
session->start();

// 5. Send from any thread
strategy_thread: session->send(MessageType::NEW_ORDER, order, len);
callback:        session->send_immediate(MessageType::APPLICATION, resp, len);

// 6. Check latency (HW timestamps)
auto stats = session->latency_stats().summary();
// stats.min_ns, stats.avg_ns, stats.max_ns, stats.hw_timestamps
)");
}

} // namespace ptpx
