#!/bin/bash
# =============================================================================
# TCP Exchange Library - Test Runner Script
# Builds the library, runs all tests, and generates coverage report
# =============================================================================

set -e  # Exit on error

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="${SCRIPT_DIR}/build_test"
REPORT_DIR="${SCRIPT_DIR}/test_reports"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}======================================================${NC}"
echo -e "${BLUE}TCP Exchange Library - Test Suite${NC}"
echo -e "${BLUE}======================================================${NC}"

# =============================================================================
# Setup
# =============================================================================

echo -e "\n${YELLOW}[1/5] Setting up build environment...${NC}"

# Create directories
mkdir -p "${BUILD_DIR}"
mkdir -p "${REPORT_DIR}"

# Change to build directory
cd "${BUILD_DIR}"

# =============================================================================
# Configure
# =============================================================================

echo -e "\n${YELLOW}[2/5] Configuring CMake...${NC}"

cmake "${SCRIPT_DIR}" \
    -DCMAKE_BUILD_TYPE=Debug \
    -DBUILD_TESTS=ON \
    -DBUILD_EXAMPLES=OFF \
    -DUSE_IO_URING=OFF \
    -DENABLE_COVERAGE=ON \
    -DCMAKE_CXX_FLAGS="-g -O0 --coverage -fprofile-arcs -ftest-coverage -fno-exceptions -fno-rtti"

# =============================================================================
# Build
# =============================================================================

echo -e "\n${YELLOW}[3/5] Building tests...${NC}"

make -j$(nproc) all_tests 2>&1 | tee "${REPORT_DIR}/build.log"

# =============================================================================
# Run Tests
# =============================================================================

echo -e "\n${YELLOW}[4/5] Running tests...${NC}"

# Run each test individually and capture output
TEST_EXECUTABLES=(
    "test_common"
    "test_ring_buffer"
    "test_timer_wheel"
    "test_tcp_session"
    "test_tcp_client"
    "test_tcp_server"
    "test_kernel_bypass"
    "test_flatbuffer_utils"
)

PASSED=0
FAILED=0
TOTAL=0

echo -e "\n${BLUE}Test Results:${NC}"
echo "============================================================"

for test_exe in "${TEST_EXECUTABLES[@]}"; do
    if [ -f "tests/${test_exe}" ]; then
        echo -n "Running ${test_exe}... "
        
        # Run test and capture output
        if ./tests/${test_exe} --gtest_output=xml:"${REPORT_DIR}/${test_exe}.xml" > "${REPORT_DIR}/${test_exe}.log" 2>&1; then
            echo -e "${GREEN}PASSED${NC}"
            ((PASSED++))
        else
            echo -e "${RED}FAILED${NC}"
            ((FAILED++))
            # Show failure output
            echo "  Output:"
            tail -20 "${REPORT_DIR}/${test_exe}.log" | sed 's/^/    /'
        fi
        ((TOTAL++))
    else
        echo -e "Skipping ${test_exe} (not found)"
    fi
done

echo "============================================================"
echo -e "Total: ${TOTAL}  ${GREEN}Passed: ${PASSED}${NC}  ${RED}Failed: ${FAILED}${NC}"
echo ""

# =============================================================================
# Coverage Report
# =============================================================================

echo -e "\n${YELLOW}[5/5] Generating coverage report...${NC}"

# Check if lcov is available
if command -v lcov &> /dev/null && command -v genhtml &> /dev/null; then
    # Capture coverage
    lcov --directory . --capture --output-file "${REPORT_DIR}/coverage.info" 2>/dev/null || true
    
    # Filter out system headers and test files
    lcov --remove "${REPORT_DIR}/coverage.info" \
        '/usr/*' \
        '*/googletest/*' \
        '*/gtest/*' \
        '*/tests/*' \
        '*/build_test/*' \
        --output-file "${REPORT_DIR}/coverage_filtered.info" 2>/dev/null || true
    
    # Generate HTML report
    if [ -f "${REPORT_DIR}/coverage_filtered.info" ]; then
        genhtml "${REPORT_DIR}/coverage_filtered.info" \
            --output-directory "${REPORT_DIR}/coverage_html" \
            --title "TCP Exchange Library Coverage" \
            --legend \
            --show-details 2>/dev/null || true
        
        echo -e "${GREEN}Coverage report generated: ${REPORT_DIR}/coverage_html/index.html${NC}"
    fi
else
    echo -e "${YELLOW}lcov/genhtml not found, skipping coverage report${NC}"
fi

# =============================================================================
# Generate Summary Report
# =============================================================================

echo -e "\n${BLUE}Generating summary report...${NC}"

cat > "${REPORT_DIR}/SUMMARY.md" << EOF
# TCP Exchange Library - Test Report

**Date:** $(date '+%Y-%m-%d %H:%M:%S')
**Build Type:** Debug with Coverage

## Test Results Summary

| Status | Count |
|--------|-------|
| Total Tests | ${TOTAL} |
| Passed | ${PASSED} |
| Failed | ${FAILED} |
| Pass Rate | $(echo "scale=1; ${PASSED}*100/${TOTAL}" | bc 2>/dev/null || echo "N/A")% |

## Test Executables

| Test | Status |
|------|--------|
EOF

for test_exe in "${TEST_EXECUTABLES[@]}"; do
    if [ -f "${REPORT_DIR}/${test_exe}.xml" ]; then
        # Parse XML for pass/fail count
        tests=$(grep -oP 'tests="\K[0-9]+' "${REPORT_DIR}/${test_exe}.xml" 2>/dev/null | head -1 || echo "?")
        failures=$(grep -oP 'failures="\K[0-9]+' "${REPORT_DIR}/${test_exe}.xml" 2>/dev/null | head -1 || echo "?")
        if [ "$failures" = "0" ]; then
            echo "| ${test_exe} | ✅ PASSED (${tests} tests) |" >> "${REPORT_DIR}/SUMMARY.md"
        else
            echo "| ${test_exe} | ❌ FAILED (${failures}/${tests} failed) |" >> "${REPORT_DIR}/SUMMARY.md"
        fi
    else
        echo "| ${test_exe} | ⚠️ NOT RUN |" >> "${REPORT_DIR}/SUMMARY.md"
    fi
done

cat >> "${REPORT_DIR}/SUMMARY.md" << EOF

## Coverage Summary

Coverage report available in: \`coverage_html/index.html\`

## Files Tested

### Core Layer
- \`core/common.hpp\` - Timestamps, buffers, config
- \`core/ring_buffer.hpp\` - SPSC ring buffer, message pool
- \`core/timer_wheel.hpp\` - Timer wheel, heartbeat manager

### Network Layer
- \`net/tcp_session.hpp\` - TCP session management
- \`net/tcp_client.hpp\` - Client (initiator) implementation
- \`net/tcp_server.hpp\` - Server (acceptor) implementation
- \`net/kernel_bypass.hpp\` - Kernel bypass detection

### Protocol Layer
- \`protocol/flatbuffer_utils.hpp\` - FlatBuffer utilities

## Build Log

See \`build.log\` for full build output.

## Individual Test Logs

See \`<test_name>.log\` for individual test outputs.
See \`<test_name>.xml\` for JUnit XML reports.
EOF

echo -e "${GREEN}Summary report generated: ${REPORT_DIR}/SUMMARY.md${NC}"

# =============================================================================
# Final Summary
# =============================================================================

echo -e "\n${BLUE}======================================================${NC}"
echo -e "${BLUE}Test Run Complete${NC}"
echo -e "${BLUE}======================================================${NC}"
echo ""
echo "Reports generated in: ${REPORT_DIR}"
echo ""
echo "Files:"
echo "  - SUMMARY.md         - Test summary"
echo "  - build.log          - Build output"
echo "  - *.xml              - JUnit XML reports"
echo "  - *.log              - Individual test logs"
echo "  - coverage_html/     - HTML coverage report"
echo ""

if [ ${FAILED} -eq 0 ]; then
    echo -e "${GREEN}All tests passed!${NC}"
    exit 0
else
    echo -e "${RED}Some tests failed. Check logs for details.${NC}"
    exit 1
fi
