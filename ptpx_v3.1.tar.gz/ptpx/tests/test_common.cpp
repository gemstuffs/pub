// =============================================================================
// Unit Tests for core/common.hpp
// 100% API Coverage
// =============================================================================

#include <gtest/gtest.h>
#include <thread>
#include <chrono>
#include <cstring>

#include "core/common.hpp"

using namespace ptpx;

// =============================================================================
// Timestamp Tests - Full Coverage
// =============================================================================

class TimestampTest : public ::testing::Test {
protected:
    void SetUp() override {
        Timestamp::calibrate();
    }
};

TEST_F(TimestampTest, NowTscReturnsNonZero) {
    EXPECT_GT(Timestamp::now_tsc(), 0ULL);
}

TEST_F(TimestampTest, NowTscIsMonotonic) {
    uint64_t tsc1 = Timestamp::now_tsc();
    uint64_t tsc2 = Timestamp::now_tsc();
    EXPECT_LE(tsc1, tsc2);
}

TEST_F(TimestampTest, NowTscIncreases) {
    uint64_t tsc1 = Timestamp::now_tsc();
    for (volatile int i = 0; i < 1000; ++i) {}  // Small delay
    uint64_t tsc2 = Timestamp::now_tsc();
    EXPECT_GT(tsc2, tsc1);
}

TEST_F(TimestampTest, NowNsReturnsNonZero) {
    EXPECT_GT(Timestamp::now_ns(), 0ULL);
}

TEST_F(TimestampTest, NowNsIsMonotonic) {
    uint64_t ns1 = Timestamp::now_ns();
    uint64_t ns2 = Timestamp::now_ns();
    EXPECT_LE(ns1, ns2);
}

TEST_F(TimestampTest, TscToNsProducesReasonableValues) {
    uint64_t tsc_start = Timestamp::now_tsc();
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
    uint64_t elapsed_ns = Timestamp::tsc_to_ns(Timestamp::now_tsc() - tsc_start);
    EXPECT_GE(elapsed_ns, 500'000ULL);
    EXPECT_LE(elapsed_ns, 50'000'000ULL);
}

TEST_F(TimestampTest, TscToNsZeroReturnsZero) {
    EXPECT_EQ(Timestamp::tsc_to_ns(0), 0ULL);
}

TEST_F(TimestampTest, CalibrateMultipleTimes) {
    Timestamp::calibrate();
    uint64_t tsc1 = Timestamp::now_tsc();
    Timestamp::calibrate();
    uint64_t tsc2 = Timestamp::now_tsc();
    EXPECT_GT(tsc2, tsc1);
}

// =============================================================================
// PreallocatedBuffer Tests - Full Coverage
// =============================================================================

TEST(PreallocatedBufferTest, InitialStateIsEmpty) {
    PreallocatedBuffer<1024> buffer;
    EXPECT_EQ(buffer.readable(), 0ULL);
    EXPECT_EQ(buffer.writable(), 1024ULL);
}

TEST(PreallocatedBufferTest, WritePtrReturnsValidPointer) {
    PreallocatedBuffer<1024> buffer;
    EXPECT_NE(buffer.write_ptr(), nullptr);
}

TEST(PreallocatedBufferTest, ReadPtrReturnsValidPointer) {
    PreallocatedBuffer<1024> buffer;
    EXPECT_NE(buffer.read_ptr(), nullptr);
}

TEST(PreallocatedBufferTest, AdvanceWriteUpdatesReadable) {
    PreallocatedBuffer<1024> buffer;
    buffer.advance_write(100);
    EXPECT_EQ(buffer.readable(), 100ULL);
    EXPECT_EQ(buffer.writable(), 924ULL);
}

TEST(PreallocatedBufferTest, AdvanceReadUpdatesReadable) {
    PreallocatedBuffer<1024> buffer;
    buffer.advance_write(100);
    buffer.advance_read(30);
    EXPECT_EQ(buffer.readable(), 70ULL);
}

TEST(PreallocatedBufferTest, WriteAndReadData) {
    PreallocatedBuffer<1024> buffer;
    const char* test_data = "Hello";
    std::memcpy(buffer.write_ptr(), test_data, 5);
    buffer.advance_write(5);
    EXPECT_EQ(std::memcmp(buffer.read_ptr(), test_data, 5), 0);
}

TEST(PreallocatedBufferTest, CompactMovesDataToStart) {
    PreallocatedBuffer<1024> buffer;
    const char* data = "TestData";
    std::memcpy(buffer.write_ptr(), data, 8);
    buffer.advance_write(8);
    buffer.advance_read(4);  // Read "Test"
    buffer.compact();
    EXPECT_EQ(buffer.readable(), 4ULL);
    EXPECT_EQ(buffer.writable(), 1020ULL);
    EXPECT_EQ(std::memcmp(buffer.read_ptr(), "Data", 4), 0);
}

TEST(PreallocatedBufferTest, CompactWithNoData) {
    PreallocatedBuffer<1024> buffer;
    buffer.compact();  // Should not crash
    EXPECT_EQ(buffer.readable(), 0ULL);
}

TEST(PreallocatedBufferTest, CompactWithAllDataRead) {
    PreallocatedBuffer<1024> buffer;
    buffer.advance_write(100);
    buffer.advance_read(100);
    buffer.compact();
    EXPECT_EQ(buffer.readable(), 0ULL);
    EXPECT_EQ(buffer.writable(), 1024ULL);
}

TEST(PreallocatedBufferTest, ResetClearsBuffer) {
    PreallocatedBuffer<1024> buffer;
    buffer.advance_write(500);
    buffer.reset();
    EXPECT_EQ(buffer.readable(), 0ULL);
    EXPECT_EQ(buffer.writable(), 1024ULL);
}

TEST(PreallocatedBufferTest, FullBufferHasZeroWritable) {
    PreallocatedBuffer<256> buffer;
    buffer.advance_write(256);
    EXPECT_EQ(buffer.writable(), 0ULL);
    EXPECT_EQ(buffer.readable(), 256ULL);
}

TEST(PreallocatedBufferTest, SmallBuffer) {
    PreallocatedBuffer<16> buffer;
    EXPECT_EQ(buffer.writable(), 16ULL);
    buffer.advance_write(16);
    EXPECT_EQ(buffer.writable(), 0ULL);
}

// =============================================================================
// Config Tests - Full Coverage
// =============================================================================

TEST(ConfigTest, MaxSessionsValue) {
    EXPECT_EQ(Config::MAX_SESSIONS, 64ULL);
}

TEST(ConfigTest, MaxMessageSizeValue) {
    EXPECT_EQ(Config::MAX_MESSAGE_SIZE, 4096ULL);
}

TEST(ConfigTest, RecvBufferSizeValue) {
    EXPECT_EQ(Config::RECV_BUFFER_SIZE, 65536ULL);
}

TEST(ConfigTest, SendBufferSizeValue) {
    EXPECT_EQ(Config::SEND_BUFFER_SIZE, 65536ULL);
}

TEST(ConfigTest, HeartbeatIntervalValue) {
    EXPECT_EQ(Config::HEARTBEAT_INTERVAL_NS, 1'000'000'000ULL);
}

TEST(ConfigTest, HeartbeatTimeoutValue) {
    EXPECT_EQ(Config::HEARTBEAT_TIMEOUT_NS, 3'000'000'000ULL);
}

TEST(ConfigTest, ConnectionTimeoutValue) {
    EXPECT_EQ(Config::CONNECTION_TIMEOUT_NS, 10'000'000'000ULL);
}

TEST(ConfigTest, SendRingSize) {
    EXPECT_EQ(Config::SEND_RING_SIZE, 256ULL);
    EXPECT_TRUE((Config::SEND_RING_SIZE & (Config::SEND_RING_SIZE - 1)) == 0);  // Power of 2
}

TEST(ConfigTest, RecvRingSize) {
    EXPECT_EQ(Config::RECV_RING_SIZE, 256ULL);
    EXPECT_TRUE((Config::RECV_RING_SIZE & (Config::RECV_RING_SIZE - 1)) == 0);  // Power of 2
}

TEST(ConfigTest, BusyPollValues) {
    EXPECT_EQ(Config::BUSY_POLL_US, 50);
    EXPECT_EQ(Config::BUSY_READ_US, 50);
}

// =============================================================================
// MessageHeader Tests - Full Coverage
// =============================================================================

TEST(MessageHeaderTest, SizeIs20Bytes) {
    EXPECT_EQ(sizeof(MessageHeader), 20ULL);
    EXPECT_EQ(MessageHeader::SIZE, 20ULL);
}

TEST(MessageHeaderTest, FieldOffsets) {
    MessageHeader header{};
    uint8_t* base = reinterpret_cast<uint8_t*>(&header);
    
    EXPECT_EQ(reinterpret_cast<uint8_t*>(&header.length) - base, 0);
    EXPECT_EQ(reinterpret_cast<uint8_t*>(&header.sequence_number) - base, 4);
    EXPECT_EQ(reinterpret_cast<uint8_t*>(&header.timestamp_ns) - base, 8);
    EXPECT_EQ(reinterpret_cast<uint8_t*>(&header.type) - base, 16);
    EXPECT_EQ(reinterpret_cast<uint8_t*>(&header.flags) - base, 17);
    EXPECT_EQ(reinterpret_cast<uint8_t*>(&header.reserved) - base, 18);
}

TEST(MessageHeaderTest, CanConstructAndAccess) {
    MessageHeader header{};
    header.length = 100;
    header.sequence_number = 42;
    header.timestamp_ns = 123456789ULL;
    header.type = MessageType::NEW_ORDER;
    header.flags = 0xFF;
    header.reserved = 0x1234;
    
    EXPECT_EQ(header.length, 100U);
    EXPECT_EQ(header.sequence_number, 42U);
    EXPECT_EQ(header.timestamp_ns, 123456789ULL);
    EXPECT_EQ(header.type, MessageType::NEW_ORDER);
    EXPECT_EQ(header.flags, 0xFF);
    EXPECT_EQ(header.reserved, 0x1234);
}

// =============================================================================
// MessageType Tests - Full Coverage
// =============================================================================

TEST(MessageTypeTest, HeartbeatTypes) {
    EXPECT_EQ(static_cast<uint8_t>(MessageType::HEARTBEAT_REQUEST), 0x01);
    EXPECT_EQ(static_cast<uint8_t>(MessageType::HEARTBEAT_RESPONSE), 0x02);
}

TEST(MessageTypeTest, OrderTypes) {
    EXPECT_EQ(static_cast<uint8_t>(MessageType::NEW_ORDER), 0x10);
    EXPECT_EQ(static_cast<uint8_t>(MessageType::CANCEL_ORDER), 0x11);
    EXPECT_EQ(static_cast<uint8_t>(MessageType::MODIFY_ORDER), 0x12);
}

TEST(MessageTypeTest, ExecutionTypes) {
    EXPECT_EQ(static_cast<uint8_t>(MessageType::EXECUTION_REPORT), 0x20);
    EXPECT_EQ(static_cast<uint8_t>(MessageType::ORDER_REJECT), 0x21);
    EXPECT_EQ(static_cast<uint8_t>(MessageType::CANCEL_REJECT), 0x22);
}

// =============================================================================
// SessionState Tests - Full Coverage
// =============================================================================

TEST(SessionStateTest, AllStates) {
    EXPECT_EQ(static_cast<uint8_t>(SessionState::DISCONNECTED), 0);
    EXPECT_EQ(static_cast<uint8_t>(SessionState::CONNECTING), 1);
    EXPECT_EQ(static_cast<uint8_t>(SessionState::CONNECTED), 2);
    EXPECT_EQ(static_cast<uint8_t>(SessionState::DRAINING), 3);
    EXPECT_EQ(static_cast<uint8_t>(SessionState::ERROR), 4);
}

// =============================================================================
// SendResult Tests - Full Coverage
// =============================================================================

TEST(SendResultTest, AllResults) {
    EXPECT_EQ(static_cast<int8_t>(SendResult::SUCCESS), 0);
    EXPECT_EQ(static_cast<int8_t>(SendResult::QUEUED), 1);
    EXPECT_EQ(static_cast<int8_t>(SendResult::WOULD_BLOCK), -1);
    EXPECT_EQ(static_cast<int8_t>(SendResult::DISCONNECTED), -2);
    EXPECT_EQ(static_cast<int8_t>(SendResult::BUFFER_FULL), -3);
    EXPECT_EQ(static_cast<int8_t>(SendResult::QUEUE_FULL), -4);
    EXPECT_EQ(static_cast<int8_t>(SendResult::ERROR), -5);
}

// =============================================================================
// RecvResult Tests - Full Coverage
// =============================================================================

TEST(RecvResultTest, AllResults) {
    EXPECT_EQ(static_cast<int8_t>(RecvResult::SUCCESS), 0);
    EXPECT_EQ(static_cast<int8_t>(RecvResult::WOULD_BLOCK), -1);
    EXPECT_EQ(static_cast<int8_t>(RecvResult::DISCONNECTED), -2);
    EXPECT_EQ(static_cast<int8_t>(RecvResult::INCOMPLETE), -3);
    EXPECT_EQ(static_cast<int8_t>(RecvResult::ERROR), -4);
}

// =============================================================================
// CacheAligned Tests
// =============================================================================

TEST(CacheAlignedTest, Alignment) {
    CacheAligned<int> aligned_int;
    EXPECT_EQ(reinterpret_cast<uintptr_t>(&aligned_int) % CACHE_LINE_SIZE, 0ULL);
}

TEST(CacheAlignedTest, ValueAccess) {
    CacheAligned<int> aligned_int;
    aligned_int.value = 42;
    EXPECT_EQ(aligned_int.value, 42);
}

// =============================================================================
// Constants Tests
// =============================================================================

TEST(ConstantsTest, CacheLineSize) {
    EXPECT_EQ(CACHE_LINE_SIZE, 64ULL);
}

int main(int argc, char** argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
