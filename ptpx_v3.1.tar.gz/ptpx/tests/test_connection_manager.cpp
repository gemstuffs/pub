// =============================================================================
// ptpx - Connection Management Tests
// =============================================================================

#include <gtest/gtest.h>
#include <thread>
#include <chrono>
#include <vector>
#include <atomic>
#include "net/connection_manager.hpp"

using namespace ptpx;

// =============================================================================
// ConnState Tests
// =============================================================================

TEST(ConnStateTest, AllStatesHaveStringRepresentation) {
    EXPECT_STREQ(conn_state_to_string(ConnState::DISCONNECTED), "DISCONNECTED");
    EXPECT_STREQ(conn_state_to_string(ConnState::CONNECTING), "CONNECTING");
    EXPECT_STREQ(conn_state_to_string(ConnState::CONNECTED), "CONNECTED");
    EXPECT_STREQ(conn_state_to_string(ConnState::DRAINING), "DRAINING");
    EXPECT_STREQ(conn_state_to_string(ConnState::RECONNECTING), "RECONNECTING");
    EXPECT_STREQ(conn_state_to_string(ConnState::FAILED), "FAILED");
    EXPECT_STREQ(conn_state_to_string(ConnState::CLOSING), "CLOSING");
}

TEST(DisconnectReasonTest, AllReasonsHaveStringRepresentation) {
    EXPECT_STREQ(disconnect_reason_to_string(DisconnectReason::NONE), "NONE");
    EXPECT_STREQ(disconnect_reason_to_string(DisconnectReason::PEER_CLOSED), "PEER_CLOSED");
    EXPECT_STREQ(disconnect_reason_to_string(DisconnectReason::PEER_RESET), "PEER_RESET");
    EXPECT_STREQ(disconnect_reason_to_string(DisconnectReason::HEARTBEAT_TIMEOUT), "HEARTBEAT_TIMEOUT");
    EXPECT_STREQ(disconnect_reason_to_string(DisconnectReason::WRITE_ERROR), "WRITE_ERROR");
    EXPECT_STREQ(disconnect_reason_to_string(DisconnectReason::READ_ERROR), "READ_ERROR");
    EXPECT_STREQ(disconnect_reason_to_string(DisconnectReason::CONNECT_TIMEOUT), "CONNECT_TIMEOUT");
    EXPECT_STREQ(disconnect_reason_to_string(DisconnectReason::CONNECT_REFUSED), "CONNECT_REFUSED");
    EXPECT_STREQ(disconnect_reason_to_string(DisconnectReason::PROTOCOL_ERROR), "PROTOCOL_ERROR");
    EXPECT_STREQ(disconnect_reason_to_string(DisconnectReason::USER_REQUESTED), "USER_REQUESTED");
    EXPECT_STREQ(disconnect_reason_to_string(DisconnectReason::NETWORK_UNREACHABLE), "NETWORK_UNREACHABLE");
    EXPECT_STREQ(disconnect_reason_to_string(DisconnectReason::MAX_RETRIES_EXCEEDED), "MAX_RETRIES_EXCEEDED");
}

// =============================================================================
// ExponentialBackoff Tests
// =============================================================================

class ExponentialBackoffTest : public ::testing::Test {
protected:
    void SetUp() override {
        Timestamp::calibrate();
    }
};

TEST_F(ExponentialBackoffTest, InitialDelayIsCorrect) {
    ReconnectConfig config;
    config.initial_delay_ns = 100'000'000;  // 100ms
    config.max_delay_ns = 10'000'000'000;   // 10s
    config.backoff_multiplier = 2.0;
    config.jitter_factor = 0.0;  // No jitter for predictable test
    
    ExponentialBackoff backoff(config);
    
    EXPECT_EQ(backoff.get_next_delay_ns(), 100'000'000ULL);
}

TEST_F(ExponentialBackoffTest, DelayDoublesOnFailure) {
    ReconnectConfig config;
    config.initial_delay_ns = 100'000'000;
    config.max_delay_ns = 10'000'000'000;
    config.backoff_multiplier = 2.0;
    config.jitter_factor = 0.0;
    
    ExponentialBackoff backoff(config);
    
    EXPECT_EQ(backoff.get_next_delay_ns(), 100'000'000ULL);
    
    backoff.record_failure();
    EXPECT_EQ(backoff.get_next_delay_ns(), 200'000'000ULL);
    
    backoff.record_failure();
    EXPECT_EQ(backoff.get_next_delay_ns(), 400'000'000ULL);
    
    backoff.record_failure();
    EXPECT_EQ(backoff.get_next_delay_ns(), 800'000'000ULL);
}

TEST_F(ExponentialBackoffTest, DelayIsCappedAtMax) {
    ReconnectConfig config;
    config.initial_delay_ns = 1'000'000'000;  // 1s
    config.max_delay_ns = 5'000'000'000;      // 5s
    config.backoff_multiplier = 2.0;
    config.jitter_factor = 0.0;
    
    ExponentialBackoff backoff(config);
    
    backoff.record_failure();  // 2s
    backoff.record_failure();  // 4s
    backoff.record_failure();  // Would be 8s, but capped at 5s
    
    EXPECT_EQ(backoff.get_next_delay_ns(), 5'000'000'000ULL);
    
    backoff.record_failure();  // Still 5s
    EXPECT_EQ(backoff.get_next_delay_ns(), 5'000'000'000ULL);
}

TEST_F(ExponentialBackoffTest, ResetResetsDelay) {
    ReconnectConfig config;
    config.initial_delay_ns = 100'000'000;
    config.max_delay_ns = 10'000'000'000;
    config.backoff_multiplier = 2.0;
    config.jitter_factor = 0.0;
    
    ExponentialBackoff backoff(config);
    
    backoff.record_failure();
    backoff.record_failure();
    backoff.record_failure();
    
    EXPECT_GT(backoff.get_next_delay_ns(), config.initial_delay_ns);
    
    backoff.reset();
    
    EXPECT_EQ(backoff.get_next_delay_ns(), config.initial_delay_ns);
    EXPECT_EQ(backoff.attempt_count(), 0);
}

TEST_F(ExponentialBackoffTest, MaxAttemptsTracked) {
    ReconnectConfig config;
    config.initial_delay_ns = 1'000'000;
    config.max_attempts = 3;
    config.jitter_factor = 0.0;
    
    ExponentialBackoff backoff(config);
    
    EXPECT_FALSE(backoff.max_attempts_exceeded());
    
    backoff.record_failure();
    EXPECT_EQ(backoff.attempt_count(), 1);
    EXPECT_FALSE(backoff.max_attempts_exceeded());
    
    backoff.record_failure();
    EXPECT_EQ(backoff.attempt_count(), 2);
    EXPECT_FALSE(backoff.max_attempts_exceeded());
    
    backoff.record_failure();
    EXPECT_EQ(backoff.attempt_count(), 3);
    EXPECT_TRUE(backoff.max_attempts_exceeded());
}

TEST_F(ExponentialBackoffTest, InfiniteRetriesWhenMaxIsZero) {
    ReconnectConfig config;
    config.initial_delay_ns = 1'000'000;
    config.max_attempts = 0;  // Infinite
    config.jitter_factor = 0.0;
    
    ExponentialBackoff backoff(config);
    
    for (int i = 0; i < 100; ++i) {
        EXPECT_FALSE(backoff.max_attempts_exceeded());
        backoff.record_failure();
    }
    
    EXPECT_FALSE(backoff.max_attempts_exceeded());
}

TEST_F(ExponentialBackoffTest, JitterAddsVariation) {
    ReconnectConfig config;
    config.initial_delay_ns = 1'000'000'000;  // 1s
    config.jitter_factor = 0.1;  // ±10%
    config.backoff_multiplier = 1.0;  // No growth
    
    ExponentialBackoff backoff(config);
    
    uint64_t min_expected = 900'000'000;   // -10%
    uint64_t max_expected = 1'100'000'000; // +10%
    
    uint64_t delay = backoff.get_next_delay_ns();
    EXPECT_GE(delay, min_expected);
    EXPECT_LE(delay, max_expected);
}

// =============================================================================
// SequenceTracker Tests
// =============================================================================

TEST(SequenceTrackerTest, InitialState) {
    SequenceTracker tracker;
    
    EXPECT_EQ(tracker.get_next_send_seq(), 1);
    EXPECT_EQ(tracker.get_expected_recv_seq(), 1);
    EXPECT_EQ(tracker.get_last_acked_seq(), 0);
    EXPECT_EQ(tracker.get_gap_count(), 0);
}

TEST(SequenceTrackerTest, SendIncrements) {
    SequenceTracker tracker;
    
    EXPECT_EQ(tracker.next_send(), 1);
    EXPECT_EQ(tracker.next_send(), 2);
    EXPECT_EQ(tracker.next_send(), 3);
    EXPECT_EQ(tracker.get_next_send_seq(), 4);
}

TEST(SequenceTrackerTest, ValidateRecvInOrder) {
    SequenceTracker tracker;
    
    EXPECT_TRUE(tracker.validate_recv(1));
    EXPECT_TRUE(tracker.validate_recv(2));
    EXPECT_TRUE(tracker.validate_recv(3));
    EXPECT_EQ(tracker.get_expected_recv_seq(), 4);
    EXPECT_EQ(tracker.get_gap_count(), 0);
}

TEST(SequenceTrackerTest, ValidateRecvWithGap) {
    SequenceTracker tracker;
    
    EXPECT_TRUE(tracker.validate_recv(1));
    EXPECT_TRUE(tracker.validate_recv(2));
    // Skip 3, 4, 5
    EXPECT_TRUE(tracker.validate_recv(6));  // Gap of 3
    
    EXPECT_EQ(tracker.get_expected_recv_seq(), 7);
    EXPECT_EQ(tracker.get_gap_count(), 3);
}

TEST(SequenceTrackerTest, RejectDuplicate) {
    SequenceTracker tracker;
    
    EXPECT_TRUE(tracker.validate_recv(1));
    EXPECT_TRUE(tracker.validate_recv(2));
    EXPECT_FALSE(tracker.validate_recv(1));  // Duplicate
    EXPECT_FALSE(tracker.validate_recv(2));  // Duplicate
}

TEST(SequenceTrackerTest, RejectOldSequence) {
    SequenceTracker tracker;
    
    EXPECT_TRUE(tracker.validate_recv(1));
    EXPECT_TRUE(tracker.validate_recv(5));  // Jump ahead
    EXPECT_FALSE(tracker.validate_recv(3)); // Old
}

TEST(SequenceTrackerTest, UnackedCount) {
    SequenceTracker tracker;
    
    tracker.next_send();  // 1
    tracker.next_send();  // 2
    tracker.next_send();  // 3
    
    EXPECT_EQ(tracker.unacked_count(), 3);
    
    tracker.set_last_acked(2);
    EXPECT_EQ(tracker.unacked_count(), 1);
}

TEST(SequenceTrackerTest, Resync) {
    SequenceTracker tracker;
    
    tracker.next_send();
    tracker.next_send();
    tracker.validate_recv(1);
    tracker.validate_recv(2);
    
    // Resync after reconnect
    tracker.resync_send(100);
    tracker.resync_recv(200);
    
    EXPECT_EQ(tracker.get_next_send_seq(), 100);
    EXPECT_EQ(tracker.get_expected_recv_seq(), 200);
    
    EXPECT_EQ(tracker.next_send(), 100);
    EXPECT_TRUE(tracker.validate_recv(200));
}

TEST(SequenceTrackerTest, Reset) {
    SequenceTracker tracker;
    
    tracker.next_send();
    tracker.next_send();
    tracker.validate_recv(1);
    tracker.validate_recv(5);  // Creates gap
    
    tracker.reset();
    
    EXPECT_EQ(tracker.get_next_send_seq(), 1);
    EXPECT_EQ(tracker.get_expected_recv_seq(), 1);
    EXPECT_EQ(tracker.get_gap_count(), 0);
}

// =============================================================================
// PartialMessageBuffer Tests
// =============================================================================

TEST(PartialMessageBufferTest, InitialState) {
    PartialMessageBuffer buffer;
    
    EXPECT_EQ(buffer.size(), 0);
    EXPECT_FALSE(buffer.has_partial_header());
    EXPECT_FALSE(buffer.has_partial_message());
}

TEST(PartialMessageBufferTest, CompleteMessageInOneChunk) {
    PartialMessageBuffer buffer;
    
    // Create a complete message
    uint8_t msg[32];
    auto* header = reinterpret_cast<MessageHeader*>(msg);
    header->length = 32;
    header->type = MessageType::NEW_ORDER;
    header->sequence_number = 1;
    
    bool complete = buffer.append(msg, 32);
    
    EXPECT_TRUE(complete);
    EXPECT_EQ(buffer.size(), 32);
    EXPECT_EQ(buffer.expected_size(), 32);
}

TEST(PartialMessageBufferTest, PartialHeader) {
    PartialMessageBuffer buffer;
    
    // Send only part of header (20 bytes)
    uint8_t msg[32];
    auto* header = reinterpret_cast<MessageHeader*>(msg);
    header->length = 32;
    
    bool complete = buffer.append(msg, 10);  // Only 10 bytes
    
    EXPECT_FALSE(complete);
    EXPECT_TRUE(buffer.has_partial_header());
    EXPECT_FALSE(buffer.has_partial_message());
}

TEST(PartialMessageBufferTest, PartialMessage) {
    PartialMessageBuffer buffer;
    
    uint8_t msg[100];
    auto* header = reinterpret_cast<MessageHeader*>(msg);
    header->length = 100;
    
    // First send header + some payload
    bool complete = buffer.append(msg, 50);
    
    EXPECT_FALSE(complete);
    EXPECT_FALSE(buffer.has_partial_header());
    EXPECT_TRUE(buffer.has_partial_message());
    EXPECT_EQ(buffer.expected_size(), 100);
}

TEST(PartialMessageBufferTest, MessageAcrossMultipleChunks) {
    PartialMessageBuffer buffer;
    
    uint8_t msg[100];
    auto* header = reinterpret_cast<MessageHeader*>(msg);
    header->length = 100;
    header->sequence_number = 42;
    std::memset(msg + sizeof(MessageHeader), 0xAB, 100 - sizeof(MessageHeader));
    
    // Send in chunks
    EXPECT_FALSE(buffer.append(msg, 10));      // Partial header
    EXPECT_FALSE(buffer.append(msg + 10, 20)); // Header complete, partial body
    EXPECT_FALSE(buffer.append(msg + 30, 30)); // More body
    EXPECT_TRUE(buffer.append(msg + 60, 40));  // Complete!
    
    EXPECT_EQ(buffer.size(), 100);
}

TEST(PartialMessageBufferTest, ConsumeMessage) {
    PartialMessageBuffer buffer;
    
    uint8_t msg[50];
    auto* header = reinterpret_cast<MessageHeader*>(msg);
    header->length = 50;
    header->sequence_number = 123;
    
    buffer.append(msg, 50);
    
    uint8_t out[50];
    size_t consumed = buffer.consume_message(out, sizeof(out));
    
    EXPECT_EQ(consumed, 50);
    EXPECT_EQ(buffer.size(), 0);
    
    auto* out_header = reinterpret_cast<MessageHeader*>(out);
    EXPECT_EQ(out_header->sequence_number, 123);
}

TEST(PartialMessageBufferTest, MultipleMessagesBackToBack) {
    PartialMessageBuffer buffer;
    
    // Two messages, 30 bytes each
    uint8_t msg1[30];
    auto* h1 = reinterpret_cast<MessageHeader*>(msg1);
    h1->length = 30;
    h1->sequence_number = 1;
    
    uint8_t msg2[30];
    auto* h2 = reinterpret_cast<MessageHeader*>(msg2);
    h2->length = 30;
    h2->sequence_number = 2;
    
    // Combine into one buffer
    uint8_t combined[60];
    std::memcpy(combined, msg1, 30);
    std::memcpy(combined + 30, msg2, 30);
    
    // Append all at once
    buffer.append(combined, 60);
    
    // First message is complete
    EXPECT_EQ(buffer.expected_size(), 30);
    
    uint8_t out[30];
    size_t consumed = buffer.consume_message(out, sizeof(out));
    EXPECT_EQ(consumed, 30);
    
    auto* out_h = reinterpret_cast<MessageHeader*>(out);
    EXPECT_EQ(out_h->sequence_number, 1);
    
    // Second message should now be available after re-parsing
    EXPECT_EQ(buffer.size(), 30);
    buffer.append(nullptr, 0);  // Trigger re-parse
}

TEST(PartialMessageBufferTest, Reset) {
    PartialMessageBuffer buffer;
    
    uint8_t msg[50];
    auto* header = reinterpret_cast<MessageHeader*>(msg);
    header->length = 50;
    
    buffer.append(msg, 30);
    EXPECT_GT(buffer.size(), 0);
    
    buffer.reset();
    
    EXPECT_EQ(buffer.size(), 0);
    EXPECT_FALSE(buffer.has_partial_header());
    EXPECT_FALSE(buffer.has_partial_message());
}

TEST(PartialMessageBufferTest, RejectOversizedMessage) {
    PartialMessageBuffer buffer;
    
    uint8_t msg[sizeof(MessageHeader)];
    auto* header = reinterpret_cast<MessageHeader*>(msg);
    header->length = PartialMessageBuffer::MAX_MESSAGE_SIZE + 1;  // Too big
    
    bool complete = buffer.append(msg, sizeof(msg));
    
    EXPECT_FALSE(complete);
    EXPECT_EQ(buffer.size(), 0);  // Should have been reset
}

// =============================================================================
// ConnectionHeartbeat Tests
// =============================================================================

class ConnectionHeartbeatTest : public ::testing::Test {
protected:
    void SetUp() override {
        Timestamp::calibrate();
    }
};

TEST_F(ConnectionHeartbeatTest, InitialState) {
    HeartbeatCfg config;
    config.enabled = true;
    config.interval_ns = 100'000'000;  // 100ms
    
    ConnectionHeartbeat hb(config);
    
    EXPECT_TRUE(hb.is_enabled());
}

TEST_F(ConnectionHeartbeatTest, DisabledDoesNotSend) {
    HeartbeatCfg config;
    config.enabled = false;
    
    ConnectionHeartbeat hb(config);
    ConnStats stats;
    
    bool send_called = false;
    hb.set_send_callback([&](uint64_t) {
        send_called = true;
        return true;
    });
    
    hb.start();
    
    // Wait and poll
    std::this_thread::sleep_for(std::chrono::milliseconds(50));
    hb.poll(stats);
    
    EXPECT_FALSE(send_called);
    EXPECT_EQ(stats.heartbeats_sent.load(), 0);
}

TEST_F(ConnectionHeartbeatTest, SendsHeartbeatAfterInterval) {
    HeartbeatCfg config;
    config.enabled = true;
    config.interval_ns = 10'000'000;  // 10ms
    config.timeout_ns = 1'000'000'000;  // 1s
    
    ConnectionHeartbeat hb(config);
    ConnStats stats;
    
    std::atomic<uint64_t> sent_seq{0};
    hb.set_send_callback([&](uint64_t seq) {
        sent_seq = seq;
        return true;
    });
    
    hb.start();
    
    // Wait for interval to pass
    std::this_thread::sleep_for(std::chrono::milliseconds(15));
    hb.poll(stats);
    
    EXPECT_GT(sent_seq.load(), 0);
    EXPECT_EQ(stats.heartbeats_sent.load(), 1);
}

TEST_F(ConnectionHeartbeatTest, TracksRTT) {
    HeartbeatCfg config;
    config.enabled = true;
    config.interval_ns = 1'000'000;  // 1ms
    config.timeout_ns = 1'000'000'000;
    config.response_timeout_ns = 100'000'000;
    
    ConnectionHeartbeat hb(config);
    ConnStats stats;
    
    uint64_t sent_seq = 0;
    hb.set_send_callback([&](uint64_t seq) {
        sent_seq = seq;
        return true;
    });
    
    hb.start();
    
    // Trigger heartbeat send
    std::this_thread::sleep_for(std::chrono::milliseconds(5));
    hb.poll(stats);
    
    EXPECT_GT(sent_seq, 0);
    
    // Simulate RTT delay
    std::this_thread::sleep_for(std::chrono::milliseconds(2));
    
    // Receive response
    hb.on_heartbeat_response(sent_seq, stats);
    
    EXPECT_EQ(stats.heartbeats_received.load(), 1);
    EXPECT_GT(stats.last_heartbeat_rtt_ns.load(), 0);
}

TEST_F(ConnectionHeartbeatTest, TimeoutCallbackFires) {
    HeartbeatCfg config;
    config.enabled = true;
    config.interval_ns = 1'000'000;    // 1ms
    config.timeout_ns = 20'000'000;    // 20ms timeout
    config.response_timeout_ns = 10'000'000;
    
    ConnectionHeartbeat hb(config);
    ConnStats stats;
    
    std::atomic<bool> timeout_fired{false};
    hb.set_timeout_callback([&]() {
        timeout_fired = true;
    });
    hb.set_send_callback([](uint64_t) { return true; });
    
    hb.start();
    
    // Don't respond to heartbeats, wait for timeout
    std::this_thread::sleep_for(std::chrono::milliseconds(30));
    hb.poll(stats);
    
    EXPECT_TRUE(timeout_fired.load());
    EXPECT_GT(stats.heartbeat_timeouts.load(), 0);
}

TEST_F(ConnectionHeartbeatTest, ActivityResetsTimeout) {
    HeartbeatCfg config;
    config.enabled = true;
    config.interval_ns = 10'000'000;   // 10ms
    config.timeout_ns = 30'000'000;    // 30ms timeout
    
    ConnectionHeartbeat hb(config);
    ConnStats stats;
    
    std::atomic<bool> timeout_fired{false};
    hb.set_timeout_callback([&]() {
        timeout_fired = true;
    });
    hb.set_send_callback([](uint64_t) { return true; });
    
    hb.start();
    
    // Keep sending activity, should not timeout
    for (int i = 0; i < 5; ++i) {
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
        hb.on_activity();
        hb.poll(stats);
    }
    
    EXPECT_FALSE(timeout_fired.load());
}

// =============================================================================
// ConnStats Tests
// =============================================================================

TEST(ConnStatsTest, InitialState) {
    ConnStats stats;
    
    EXPECT_EQ(stats.connects.load(), 0);
    EXPECT_EQ(stats.disconnects.load(), 0);
    EXPECT_EQ(stats.bytes_sent.load(), 0);
    EXPECT_EQ(stats.bytes_received.load(), 0);
}

TEST(ConnStatsTest, AtomicIncrements) {
    ConnStats stats;
    
    stats.connects.fetch_add(1);
    stats.disconnects.fetch_add(1);
    stats.bytes_sent.fetch_add(100);
    stats.bytes_received.fetch_add(200);
    
    EXPECT_EQ(stats.connects.load(), 1);
    EXPECT_EQ(stats.disconnects.load(), 1);
    EXPECT_EQ(stats.bytes_sent.load(), 100);
    EXPECT_EQ(stats.bytes_received.load(), 200);
}

TEST(ConnStatsTest, Reset) {
    ConnStats stats;
    
    stats.connects = 5;
    stats.disconnects = 3;
    stats.bytes_sent = 1000;
    stats.min_heartbeat_rtt_ns = 100;
    
    stats.reset();
    
    EXPECT_EQ(stats.connects.load(), 0);
    EXPECT_EQ(stats.disconnects.load(), 0);
    EXPECT_EQ(stats.bytes_sent.load(), 0);
    EXPECT_EQ(stats.min_heartbeat_rtt_ns.load(), UINT64_MAX);
}

TEST(ConnStatsTest, ConcurrentAccess) {
    ConnStats stats;
    
    std::vector<std::thread> threads;
    const int num_threads = 4;
    const int increments_per_thread = 10000;
    
    for (int t = 0; t < num_threads; ++t) {
        threads.emplace_back([&]() {
            for (int i = 0; i < increments_per_thread; ++i) {
                stats.bytes_sent.fetch_add(1, std::memory_order_relaxed);
                stats.messages_sent.fetch_add(1, std::memory_order_relaxed);
            }
        });
    }
    
    for (auto& t : threads) {
        t.join();
    }
    
    EXPECT_EQ(stats.bytes_sent.load(), num_threads * increments_per_thread);
    EXPECT_EQ(stats.messages_sent.load(), num_threads * increments_per_thread);
}

// =============================================================================
// Mock Connection for ConnectionManager Tests
// =============================================================================

class MockConnection : public ConnectionManager<MockConnection> {
public:
    MockConnection(const ReconnectConfig& rc, const HeartbeatCfg& hc)
        : ConnectionManager(rc, hc)
        , connect_should_succeed_(true)
        , connect_immediately_(true)
        , connected_(false) {}
    
    // Configuration
    void set_connect_should_succeed(bool v) { connect_should_succeed_ = v; }
    void set_connect_immediately(bool v) { connect_immediately_ = v; }
    
    // Simulate events
    void simulate_connect_complete() {
        if (connect_should_succeed_) {
            connected_ = true;
            on_connected();
        }
    }
    
    void simulate_disconnect(DisconnectReason reason) {
        connected_ = false;
        on_disconnected(reason);
    }
    
    void simulate_data_received(size_t bytes) {
        on_data_received(bytes);
    }
    
    // CRTP implementation
    bool do_connect() {
        if (connect_immediately_ && connect_should_succeed_) {
            connected_ = true;
            on_connected();
            return true;
        }
        return connect_should_succeed_;
    }
    
    void do_disconnect() {
        connected_ = false;
    }
    
    void do_force_disconnect() {
        connected_ = false;
    }
    
    bool do_poll_connecting() {
        return connected_;
    }
    
    void do_poll() {
        // Normal poll
    }
    
    void do_poll_draining() {
        // Draining poll
    }
    
    bool is_connected_internal() const { return connected_; }
    
private:
    bool connect_should_succeed_;
    bool connect_immediately_;
    bool connected_;
};

// =============================================================================
// ConnectionManager Tests
// =============================================================================

class ConnectionManagerTest : public ::testing::Test {
protected:
    void SetUp() override {
        Timestamp::calibrate();
    }
    
    ReconnectConfig default_reconnect_config() {
        ReconnectConfig cfg;
        cfg.enabled = true;
        cfg.initial_delay_ns = 10'000'000;  // 10ms
        cfg.max_delay_ns = 100'000'000;     // 100ms
        cfg.backoff_multiplier = 2.0;
        cfg.jitter_factor = 0.0;
        cfg.max_attempts = 3;
        cfg.connect_timeout_ns = 50'000'000;  // 50ms
        return cfg;
    }
    
    HeartbeatCfg default_heartbeat_config() {
        HeartbeatCfg cfg;
        cfg.enabled = false;  // Disable for most tests
        cfg.interval_ns = 100'000'000;
        cfg.timeout_ns = 500'000'000;
        return cfg;
    }
};

TEST_F(ConnectionManagerTest, InitialStateIsDisconnected) {
    MockConnection conn(default_reconnect_config(), default_heartbeat_config());
    
    EXPECT_EQ(conn.state(), ConnState::DISCONNECTED);
}

TEST_F(ConnectionManagerTest, ConnectTransitionsToConnected) {
    MockConnection conn(default_reconnect_config(), default_heartbeat_config());
    
    std::vector<std::pair<ConnState, ConnState>> transitions;
    conn.set_state_change_callback([&](ConnState old_s, ConnState new_s, DisconnectReason) {
        transitions.emplace_back(old_s, new_s);
    });
    
    conn.connect();
    
    EXPECT_EQ(conn.state(), ConnState::CONNECTED);
    EXPECT_EQ(conn.stats().connects.load(), 1);
    
    ASSERT_GE(transitions.size(), 1);
}

TEST_F(ConnectionManagerTest, DisconnectTransitionsToDisconnected) {
    MockConnection conn(default_reconnect_config(), default_heartbeat_config());
    
    conn.connect();
    EXPECT_EQ(conn.state(), ConnState::CONNECTED);
    
    conn.disconnect(DisconnectReason::USER_REQUESTED);
    
    EXPECT_EQ(conn.state(), ConnState::DISCONNECTED);
    EXPECT_EQ(conn.last_disconnect_reason(), DisconnectReason::USER_REQUESTED);
}

TEST_F(ConnectionManagerTest, AutoReconnectOnDisconnect) {
    auto cfg = default_reconnect_config();
    cfg.enabled = true;
    cfg.initial_delay_ns = 5'000'000;  // 5ms
    
    MockConnection conn(cfg, default_heartbeat_config());
    
    conn.connect();
    EXPECT_EQ(conn.state(), ConnState::CONNECTED);
    
    // Simulate peer disconnect (not user requested)
    conn.simulate_disconnect(DisconnectReason::PEER_CLOSED);
    
    // Should be in reconnecting state
    EXPECT_EQ(conn.state(), ConnState::RECONNECTING);
    
    // Poll until reconnected
    for (int i = 0; i < 20; ++i) {
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
        conn.poll();
        if (conn.state() == ConnState::CONNECTED) break;
    }
    
    EXPECT_EQ(conn.state(), ConnState::CONNECTED);
    EXPECT_EQ(conn.stats().reconnect_attempts.load(), 1);
}

TEST_F(ConnectionManagerTest, NoReconnectOnUserDisconnect) {
    auto cfg = default_reconnect_config();
    cfg.enabled = true;
    
    MockConnection conn(cfg, default_heartbeat_config());
    
    conn.connect();
    conn.disconnect(DisconnectReason::USER_REQUESTED);
    
    EXPECT_EQ(conn.state(), ConnState::DISCONNECTED);
    EXPECT_NE(conn.state(), ConnState::RECONNECTING);
}

TEST_F(ConnectionManagerTest, MaxRetriesExceeded) {
    auto cfg = default_reconnect_config();
    cfg.enabled = true;
    cfg.max_attempts = 2;
    cfg.initial_delay_ns = 1'000'000;  // 1ms
    cfg.connect_timeout_ns = 1'000'000;  // 1ms
    
    MockConnection conn(cfg, default_heartbeat_config());
    conn.set_connect_should_succeed(false);
    conn.set_connect_immediately(false);
    
    conn.connect();
    
    // Poll through timeouts
    for (int i = 0; i < 50; ++i) {
        std::this_thread::sleep_for(std::chrono::milliseconds(2));
        conn.poll();
        if (conn.state() == ConnState::FAILED) break;
    }
    
    EXPECT_EQ(conn.state(), ConnState::FAILED);
    EXPECT_EQ(conn.last_disconnect_reason(), DisconnectReason::MAX_RETRIES_EXCEEDED);
}

TEST_F(ConnectionManagerTest, StatsTrackConnections) {
    MockConnection conn(default_reconnect_config(), default_heartbeat_config());
    
    conn.connect();
    conn.disconnect();
    conn.connect();
    conn.disconnect();
    
    EXPECT_EQ(conn.stats().connects.load(), 2);
    EXPECT_EQ(conn.stats().disconnects.load(), 2);
}

TEST_F(ConnectionManagerTest, StatsTrackData) {
    MockConnection conn(default_reconnect_config(), default_heartbeat_config());
    
    conn.connect();
    conn.simulate_data_received(100);
    conn.simulate_data_received(200);
    
    EXPECT_EQ(conn.stats().bytes_received.load(), 300);
    EXPECT_GT(conn.stats().last_activity_tsc.load(), 0);
}

TEST_F(ConnectionManagerTest, SequenceTrackerIntegration) {
    MockConnection conn(default_reconnect_config(), default_heartbeat_config());
    
    conn.connect();
    
    auto& seq = conn.sequence();
    EXPECT_EQ(seq.next_send(), 1);
    EXPECT_EQ(seq.next_send(), 2);
    EXPECT_TRUE(seq.validate_recv(1));
    EXPECT_TRUE(seq.validate_recv(2));
}

// =============================================================================
// Integration Test - Simulated Network Scenarios
// =============================================================================

TEST_F(ConnectionManagerTest, RapidDisconnectReconnect) {
    auto cfg = default_reconnect_config();
    cfg.enabled = true;
    cfg.initial_delay_ns = 1'000'000;  // 1ms
    cfg.max_attempts = 0;  // Infinite
    
    MockConnection conn(cfg, default_heartbeat_config());
    
    for (int i = 0; i < 10; ++i) {
        conn.connect();
        EXPECT_EQ(conn.state(), ConnState::CONNECTED);
        
        conn.simulate_disconnect(DisconnectReason::PEER_RESET);
        
        // Wait for reconnect
        for (int j = 0; j < 10; ++j) {
            std::this_thread::sleep_for(std::chrono::milliseconds(2));
            conn.poll();
            if (conn.state() == ConnState::CONNECTED) break;
        }
    }
    
    EXPECT_GE(conn.stats().connects.load(), 10);
    EXPECT_GE(conn.stats().disconnects.load(), 10);
}

TEST_F(ConnectionManagerTest, DisconnectDuringHighLoad) {
    MockConnection conn(default_reconnect_config(), default_heartbeat_config());
    
    conn.connect();
    
    // Simulate high message rate
    for (int i = 0; i < 1000; ++i) {
        conn.sequence().next_send();
        conn.stats().messages_sent.fetch_add(1);
        conn.stats().bytes_sent.fetch_add(100);
    }
    
    // Disconnect mid-stream
    conn.simulate_disconnect(DisconnectReason::PEER_CLOSED);
    
    // Reconnect
    conn.connect();
    
    // Sequence should continue (or resync)
    EXPECT_GE(conn.sequence().get_next_send_seq(), 1);
}

// =============================================================================
// Main
// =============================================================================

int main(int argc, char** argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
