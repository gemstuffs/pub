// =============================================================================
// Unit Tests for protocol/flatbuffer_utils.hpp
// =============================================================================

#include <gtest/gtest.h>
#include <cstring>
#include <vector>

#include "protocol/flatbuffer_utils.hpp"

using namespace ptpx;

// =============================================================================
// FlatBufferBuilderPool Tests
// =============================================================================

TEST(FlatBufferBuilderPoolTest, AcquireReturnsValidBuilder) {
    FlatBufferBuilderPool<4> pool;
    auto* builder = pool.acquire();
    ASSERT_NE(builder, nullptr);
    // Builder should be usable
    EXPECT_EQ(builder->GetSize(), 0ULL);  // Empty after Reset
}

TEST(FlatBufferBuilderPoolTest, AcquireMultiple) {
    FlatBufferBuilderPool<8> pool;
    std::vector<flatbuffers::FlatBufferBuilder*> builders;
    
    for (int i = 0; i < 8; ++i) {
        auto* builder = pool.acquire();
        if (builder) {
            builders.push_back(builder);
        }
    }
    
    EXPECT_GT(builders.size(), 0ULL);
}

TEST(FlatBufferBuilderPoolTest, BuilderCanBeUsed) {
    FlatBufferBuilderPool<4> pool;
    auto* builder = pool.acquire();
    ASSERT_NE(builder, nullptr);
    
    // Create a simple buffer
    std::vector<uint8_t> data = {1, 2, 3, 4, 5};
    auto vec = builder->CreateVector(data);
    builder->Finish(vec);
    
    EXPECT_GT(builder->GetSize(), 0ULL);
}

TEST(FlatBufferBuilderPoolTest, AcquireStWorks) {
    FlatBufferBuilderPool<4> pool;
    auto* builder = pool.acquire_st();
    ASSERT_NE(builder, nullptr);
    EXPECT_EQ(builder->GetSize(), 0ULL);  // Should be reset
}

// =============================================================================
// MessageFramer Tests
// =============================================================================

TEST(MessageFramerTest, HeaderSizeIsCorrect) {
    EXPECT_EQ(MessageFramer::header_size(), MessageHeader::SIZE);
    EXPECT_EQ(MessageFramer::header_size(), 20ULL);
}

TEST(MessageFramerTest, Construction) {
    MessageFramer framer;
    // Should not crash
}

// =============================================================================
// MessageDispatcher Tests (CRTP)
// =============================================================================

class TestHandler : public MessageDispatcher<TestHandler> {
public:
    int new_order_count = 0;
    int cancel_order_count = 0;
    int execution_report_count = 0;
    int unknown_count = 0;
    
    void on_new_order(const uint8_t*, size_t, const MessageHeader&) {
        ++new_order_count;
    }
    
    void on_cancel_order(const uint8_t*, size_t, const MessageHeader&) {
        ++cancel_order_count;
    }
    
    void on_execution_report(const uint8_t*, size_t, const MessageHeader&) {
        ++execution_report_count;
    }
    
    void on_unknown_message(MessageType, const uint8_t*, size_t) {
        ++unknown_count;
    }
};

TEST(MessageDispatcherTest, DispatchNewOrder) {
    TestHandler handler;
    MessageHeader header{};
    header.type = MessageType::NEW_ORDER;
    header.length = MessageHeader::SIZE;
    
    handler.dispatch(header, nullptr, 0);
    
    EXPECT_EQ(handler.new_order_count, 1);
    EXPECT_EQ(handler.cancel_order_count, 0);
}

TEST(MessageDispatcherTest, DispatchCancelOrder) {
    TestHandler handler;
    MessageHeader header{};
    header.type = MessageType::CANCEL_ORDER;
    header.length = MessageHeader::SIZE;
    
    handler.dispatch(header, nullptr, 0);
    
    EXPECT_EQ(handler.cancel_order_count, 1);
}

TEST(MessageDispatcherTest, DispatchExecutionReport) {
    TestHandler handler;
    MessageHeader header{};
    header.type = MessageType::EXECUTION_REPORT;
    header.length = MessageHeader::SIZE;
    
    handler.dispatch(header, nullptr, 0);
    
    EXPECT_EQ(handler.execution_report_count, 1);
}

TEST(MessageDispatcherTest, DispatchMultiple) {
    TestHandler handler;
    MessageHeader header{};
    header.length = MessageHeader::SIZE;
    
    header.type = MessageType::NEW_ORDER;
    handler.dispatch(header, nullptr, 0);
    handler.dispatch(header, nullptr, 0);
    
    header.type = MessageType::EXECUTION_REPORT;
    handler.dispatch(header, nullptr, 0);
    
    EXPECT_EQ(handler.new_order_count, 2);
    EXPECT_EQ(handler.execution_report_count, 1);
}

TEST(MessageDispatcherTest, DispatchUnknown) {
    TestHandler handler;
    MessageHeader header{};
    header.type = MessageType::HEARTBEAT_REQUEST;  // Not handled explicitly
    header.length = MessageHeader::SIZE;
    
    handler.dispatch(header, nullptr, 0);
    
    EXPECT_EQ(handler.unknown_count, 1);
}

int main(int argc, char** argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
