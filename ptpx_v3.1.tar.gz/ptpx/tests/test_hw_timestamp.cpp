// =============================================================================
// ptpx - Hardware Timestamp Tests
// =============================================================================

#include "../include/core/hw_timestamp.hpp"
#include <gtest/gtest.h>
#include <thread>
#include <chrono>

using namespace ptpx;

// =============================================================================
// HWTimestamp Basic Tests
// =============================================================================

TEST(HWTimestampTest, DefaultConstruction) {
    HWTimestamp ts;
    EXPECT_EQ(ts.ns, 0u);
    EXPECT_FALSE(ts.valid);
    EXPECT_FALSE(ts.is_hw);
}

TEST(HWTimestampTest, ValueConstruction) {
    HWTimestamp ts(1234567890, true, true);
    EXPECT_EQ(ts.ns, 1234567890u);
    EXPECT_TRUE(ts.valid);
    EXPECT_TRUE(ts.is_hw);
}

TEST(HWTimestampTest, Invalid) {
    auto ts = HWTimestamp::invalid();
    EXPECT_EQ(ts.ns, 0u);
    EXPECT_FALSE(ts.valid);
}

TEST(HWTimestampTest, SoftwareTimestamp) {
    auto ts = HWTimestamp::now_sw();
    EXPECT_TRUE(ts.valid);
    EXPECT_FALSE(ts.is_hw);  // Software timestamp
    EXPECT_GT(ts.ns, 0u);
}

TEST(HWTimestampTest, SoftwareTimestampMonotonic) {
    auto ts1 = HWTimestamp::now_sw();
    std::this_thread::sleep_for(std::chrono::microseconds(100));
    auto ts2 = HWTimestamp::now_sw();
    
    EXPECT_GT(ts2.ns, ts1.ns);
}

// =============================================================================
// LatencyStats Tests
// =============================================================================

TEST(LatencyStatsTest, InitialState) {
    LatencyStats stats;
    EXPECT_EQ(stats.min_ns(), 0u);
    EXPECT_EQ(stats.max_ns(), 0u);
    EXPECT_EQ(stats.avg_ns(), 0u);
    EXPECT_EQ(stats.count(), 0u);
    EXPECT_FALSE(stats.has_hw_timestamps());
}

TEST(LatencyStatsTest, RecordSingleRTT) {
    LatencyStats stats;
    
    HWTimestamp tx(1000, true, true);
    HWTimestamp rx(1500, true, true);
    
    stats.record(tx, rx);
    
    EXPECT_EQ(stats.min_ns(), 500u);
    EXPECT_EQ(stats.max_ns(), 500u);
    EXPECT_EQ(stats.avg_ns(), 500u);
    EXPECT_EQ(stats.last_ns(), 500u);
    EXPECT_EQ(stats.count(), 1u);
    EXPECT_TRUE(stats.has_hw_timestamps());
}

TEST(LatencyStatsTest, RecordMultipleRTT) {
    LatencyStats stats;
    
    // Record RTTs: 100, 200, 300
    stats.record(HWTimestamp(1000, true), HWTimestamp(1100, true));  // 100ns
    stats.record(HWTimestamp(2000, true), HWTimestamp(2200, true));  // 200ns
    stats.record(HWTimestamp(3000, true), HWTimestamp(3300, true));  // 300ns
    
    EXPECT_EQ(stats.min_ns(), 100u);
    EXPECT_EQ(stats.max_ns(), 300u);
    EXPECT_EQ(stats.avg_ns(), 200u);  // (100+200+300)/3
    EXPECT_EQ(stats.count(), 3u);
}

TEST(LatencyStatsTest, RecordOneway) {
    LatencyStats stats;
    
    stats.record_oneway(100, true);
    stats.record_oneway(200, true);
    stats.record_oneway(300, true);
    
    EXPECT_EQ(stats.min_ns(), 100u);
    EXPECT_EQ(stats.max_ns(), 300u);
    EXPECT_EQ(stats.avg_ns(), 200u);
    EXPECT_EQ(stats.count(), 3u);
    EXPECT_TRUE(stats.has_hw_timestamps());
}

TEST(LatencyStatsTest, SoftwareTimestampFlag) {
    LatencyStats stats;
    
    // Record with software timestamp
    stats.record_oneway(100, false);  // is_hw = false
    
    EXPECT_FALSE(stats.has_hw_timestamps());
    
    // Record with hardware timestamp
    stats.record_oneway(200, true);  // is_hw = true
    
    EXPECT_TRUE(stats.has_hw_timestamps());
}

TEST(LatencyStatsTest, Reset) {
    LatencyStats stats;
    
    stats.record_oneway(100);
    stats.record_oneway(200);
    
    EXPECT_EQ(stats.count(), 2u);
    
    stats.reset();
    
    EXPECT_EQ(stats.min_ns(), 0u);
    EXPECT_EQ(stats.max_ns(), 0u);
    EXPECT_EQ(stats.avg_ns(), 0u);
    EXPECT_EQ(stats.count(), 0u);
    EXPECT_FALSE(stats.has_hw_timestamps());
}

TEST(LatencyStatsTest, Summary) {
    LatencyStats stats;
    
    stats.record_oneway(100, true);
    stats.record_oneway(200, true);
    stats.record_oneway(300, true);
    
    auto summary = stats.summary();
    
    EXPECT_EQ(summary.min_ns, 100u);
    EXPECT_EQ(summary.max_ns, 300u);
    EXPECT_EQ(summary.avg_ns, 200u);
    EXPECT_EQ(summary.last_ns, 300u);
    EXPECT_EQ(summary.count, 3u);
    EXPECT_TRUE(summary.hw_timestamps);
}

TEST(LatencyStatsTest, InvalidTimestamps) {
    LatencyStats stats;
    
    // Invalid TX
    stats.record(HWTimestamp::invalid(), HWTimestamp(1000, true));
    EXPECT_EQ(stats.count(), 0u);
    
    // Invalid RX
    stats.record(HWTimestamp(1000, true), HWTimestamp::invalid());
    EXPECT_EQ(stats.count(), 0u);
    
    // RX before TX (invalid)
    stats.record(HWTimestamp(2000, true), HWTimestamp(1000, true));
    EXPECT_EQ(stats.count(), 0u);
}

// =============================================================================
// Concurrent Access Tests
// =============================================================================

TEST(LatencyStatsTest, ConcurrentRecording) {
    LatencyStats stats;
    std::atomic<bool> stop{false};
    
    constexpr int NUM_THREADS = 4;
    constexpr int RECORDS_PER_THREAD = 10000;
    
    std::vector<std::thread> threads;
    for (int t = 0; t < NUM_THREADS; ++t) {
        threads.emplace_back([&, t]() {
            for (int i = 0; i < RECORDS_PER_THREAD; ++i) {
                uint64_t latency = 100 + (t * 100) + (i % 100);
                stats.record_oneway(latency, true);
            }
        });
    }
    
    for (auto& t : threads) {
        t.join();
    }
    
    EXPECT_EQ(stats.count(), NUM_THREADS * RECORDS_PER_THREAD);
    EXPECT_GE(stats.min_ns(), 100u);
    EXPECT_GE(stats.max_ns(), stats.min_ns());
}

TEST(LatencyStatsTest, ConcurrentReadWrite) {
    LatencyStats stats;
    std::atomic<bool> stop{false};
    
    // Writer thread
    std::thread writer([&]() {
        for (int i = 0; i < 100000; ++i) {
            stats.record_oneway(100 + (i % 1000));
        }
    });
    
    // Reader threads
    std::vector<std::thread> readers;
    for (int r = 0; r < 4; ++r) {
        readers.emplace_back([&]() {
            while (!stop.load(std::memory_order_acquire)) {
                auto summary = stats.summary();
                // Just accessing - no assertion on values during concurrent write
                (void)summary;
            }
        });
    }
    
    writer.join();
    stop.store(true, std::memory_order_release);
    
    for (auto& r : readers) {
        r.join();
    }
    
    // After all threads done, values should be consistent
    auto summary = stats.summary();
    EXPECT_EQ(summary.count, 100000u);
    EXPECT_GE(summary.min_ns, 100u);
    EXPECT_LE(summary.max_ns, 1100u);
}

// =============================================================================
// Main
// =============================================================================

int main(int argc, char** argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
