// =============================================================================
// ptpx - Kernel Bypass Tests
// =============================================================================

#include <gtest/gtest.h>
#include <set>
#include "net/kernel_bypass.hpp"

using namespace ptpx;

// =============================================================================
// BypassMode Tests
// =============================================================================

TEST(BypassModeTest, ValuesAreDefined) {
    EXPECT_EQ(static_cast<uint8_t>(BypassMode::NONE), 0);
    EXPECT_EQ(static_cast<uint8_t>(BypassMode::ONLOAD), 1);
    EXPECT_EQ(static_cast<uint8_t>(BypassMode::TCPDIRECT), 2);
}

TEST(BypassModeTest, AllModesUnique) {
    std::set<uint8_t> values;
    values.insert(static_cast<uint8_t>(BypassMode::NONE));
    values.insert(static_cast<uint8_t>(BypassMode::ONLOAD));
    values.insert(static_cast<uint8_t>(BypassMode::TCPDIRECT));
    EXPECT_EQ(values.size(), 3);
}

TEST(BypassModeTest, TCPDirectIsFastest) {
    // TCPDirect (value 2) represents fastest TCP option
    EXPECT_GT(static_cast<uint8_t>(BypassMode::TCPDIRECT), 
              static_cast<uint8_t>(BypassMode::ONLOAD));
}

// =============================================================================
// BypassInfo Tests
// =============================================================================

TEST(BypassInfoTest, DetectReturnsValidInfo) {
    BypassInfo info = BypassInfo::detect();
    EXPECT_NE(info.library_name, nullptr);
}

TEST(BypassInfoTest, DetectSetsMode) {
    BypassInfo info = BypassInfo::detect();
    EXPECT_TRUE(info.mode == BypassMode::NONE ||
                info.mode == BypassMode::ONLOAD ||
                info.mode == BypassMode::TCPDIRECT);
}

TEST(BypassInfoTest, NoneModeSetsKernelLibrary) {
    BypassInfo info = BypassInfo::detect();
    if (info.mode == BypassMode::NONE) {
        EXPECT_STREQ(info.library_name, "kernel");
        EXPECT_FALSE(info.zero_copy_supported);
        EXPECT_FALSE(info.tcpdirect_available);
        EXPECT_GE(info.min_latency_ns, 3000);  // Kernel >= 3μs
    }
}

TEST(BypassInfoTest, TCPDirectModeHasCorrectProperties) {
    BypassInfo info = BypassInfo::detect();
    if (info.mode == BypassMode::TCPDIRECT) {
        EXPECT_TRUE(info.zero_copy_supported);
        EXPECT_TRUE(info.tcpdirect_available);
        EXPECT_LE(info.min_latency_ns, 500);  // Should be < 500ns
    }
}

TEST(BypassInfoTest, OnloadModeHasCorrectProperties) {
    BypassInfo info = BypassInfo::detect();
    if (info.mode == BypassMode::ONLOAD) {
        EXPECT_TRUE(info.zero_copy_supported);
        EXPECT_LE(info.min_latency_ns, 1000);  // Should be < 1μs
    }
}

TEST(BypassInfoTest, DetectIsIdempotent) {
    BypassInfo info1 = BypassInfo::detect();
    BypassInfo info2 = BypassInfo::detect();
    EXPECT_EQ(info1.mode, info2.mode);
    EXPECT_EQ(info1.min_latency_ns, info2.min_latency_ns);
}

TEST(BypassInfoTest, LatencyOrderIsCorrect) {
    // TCPDirect < OpenOnload < Kernel
    constexpr uint64_t TCPDIRECT_LATENCY = 300;
    constexpr uint64_t ONLOAD_LATENCY = 600;
    constexpr uint64_t KERNEL_LATENCY = 5000;
    
    EXPECT_LT(TCPDIRECT_LATENCY, ONLOAD_LATENCY);
    EXPECT_LT(ONLOAD_LATENCY, KERNEL_LATENCY);
}

// =============================================================================
// BypassSocket Tests
// =============================================================================

TEST(BypassSocketTest, DefaultConstruction) {
    BypassSocket sock;
    EXPECT_EQ(sock.fd(), -1);
}

TEST(BypassSocketTest, FdConstruction) {
    BypassSocket sock(-1);  // Invalid fd
    EXPECT_EQ(sock.fd(), -1);
}

TEST(BypassSocketTest, MoveConstruction) {
    BypassSocket sock1;
    BypassSocket sock2(std::move(sock1));
    EXPECT_EQ(sock1.fd(), -1);
}

TEST(BypassSocketTest, MoveAssignment) {
    BypassSocket sock1;
    BypassSocket sock2;
    sock2 = std::move(sock1);
    EXPECT_EQ(sock1.fd(), -1);
}

TEST(BypassSocketTest, RecvOnInvalidFd) {
    BypassSocket sock;
    char buf[64];
    ssize_t ret = sock.recv(buf, sizeof(buf));
    EXPECT_LT(ret, 0);
}

TEST(BypassSocketTest, SendOnInvalidFd) {
    BypassSocket sock;
    const char* data = "test";
    ssize_t ret = sock.send(data, 4);
    EXPECT_LT(ret, 0);
}

// =============================================================================
// PrintLaunchCommands Tests
// =============================================================================

TEST(PrintLaunchCommandsTest, GeneratesOutput) {
    // Just verify it doesn't crash for each mode
    testing::internal::CaptureStdout();
    print_launch_commands(BypassMode::NONE, "test_app", 1);
    std::string output = testing::internal::GetCapturedStdout();
    EXPECT_FALSE(output.empty());
    EXPECT_NE(output.find("taskset"), std::string::npos);
}

TEST(PrintLaunchCommandsTest, OnloadMode) {
    testing::internal::CaptureStdout();
    print_launch_commands(BypassMode::ONLOAD, "test_app", 2);
    std::string output = testing::internal::GetCapturedStdout();
    EXPECT_NE(output.find("onload"), std::string::npos);
    EXPECT_NE(output.find("EF_POLL_USEC"), std::string::npos);
}

TEST(PrintLaunchCommandsTest, TCPDirectMode) {
    testing::internal::CaptureStdout();
    print_launch_commands(BypassMode::TCPDIRECT, "test_app", 3);
    std::string output = testing::internal::GetCapturedStdout();
    EXPECT_NE(output.find("TCPDirect"), std::string::npos);
}

int main(int argc, char** argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
