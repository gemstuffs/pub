// =============================================================================
// ptpx - MPSC Queue Tests
// =============================================================================

#include "../include/core/mpsc_queue.hpp"
#include <gtest/gtest.h>
#include <thread>
#include <vector>
#include <atomic>
#include <chrono>
#include <memory>

using namespace ptpx;

// =============================================================================
// Basic Functionality
// =============================================================================

TEST(MPSCQueueTest, EmptyQueue) {
    MPSCQueue<256> queue;
    EXPECT_TRUE(queue.empty());
    EXPECT_EQ(queue.try_pop(), nullptr);
}

TEST(MPSCQueueTest, SinglePushPop) {
    MPSCQueue<256> queue;
    
    uint8_t data[] = {1, 2, 3, 4, 5};
    EXPECT_TRUE(queue.try_push(data, sizeof(data), 12345));
    EXPECT_FALSE(queue.empty());
    
    SendRequest req;
    EXPECT_TRUE(queue.try_pop_copy(req));
    EXPECT_EQ(req.len, sizeof(data));
    EXPECT_EQ(req.enqueue_tsc, 12345);
    EXPECT_EQ(memcmp(req.payload, data, sizeof(data)), 0);
    
    EXPECT_TRUE(queue.empty());
}

TEST(MPSCQueueTest, MultiplePushPop) {
    MPSCQueue<256> queue;
    
    for (int i = 0; i < 100; ++i) {
        uint8_t data = static_cast<uint8_t>(i);
        EXPECT_TRUE(queue.try_push(&data, 1, i));
    }
    
    for (int i = 0; i < 100; ++i) {
        SendRequest req;
        EXPECT_TRUE(queue.try_pop_copy(req));
        EXPECT_EQ(req.payload[0], static_cast<uint8_t>(i));
        EXPECT_EQ(req.enqueue_tsc, static_cast<uint64_t>(i));
    }
    
    EXPECT_TRUE(queue.empty());
}

TEST(MPSCQueueTest, DrainFunction) {
    MPSCQueue<256> queue;
    
    for (int i = 0; i < 50; ++i) {
        uint8_t data = static_cast<uint8_t>(i);
        queue.try_push(&data, 1, 0);
    }
    
    int count = 0;
    size_t drained = queue.drain([&](const SendRequest& req) {
        EXPECT_EQ(req.payload[0], static_cast<uint8_t>(count));
        ++count;
    });
    
    EXPECT_EQ(drained, 50u);
    EXPECT_EQ(count, 50);
    EXPECT_TRUE(queue.empty());
}

TEST(MPSCQueueTest, TryPopAndProcess) {
    MPSCQueue<256> queue;
    
    uint8_t data = 42;
    queue.try_push(&data, 1, 0);
    
    bool processed = false;
    bool result = queue.try_pop_and_process([&](const SendRequest& req) {
        EXPECT_EQ(req.payload[0], 42);
        processed = true;
    });
    
    EXPECT_TRUE(result);
    EXPECT_TRUE(processed);
    EXPECT_TRUE(queue.empty());
}

TEST(MPSCQueueTest, MaxPayloadSize) {
    MPSCQueue<256> queue;
    
    // Should succeed
    std::vector<uint8_t> data(SendRequest::MAX_PAYLOAD);
    EXPECT_TRUE(queue.try_push(data.data(), data.size(), 0));
    
    // Should fail - too large
    std::vector<uint8_t> large_data(SendRequest::MAX_PAYLOAD + 1);
    EXPECT_FALSE(queue.try_push(large_data.data(), large_data.size(), 0));
}

// =============================================================================
// Concurrent Tests
// =============================================================================

TEST(MPSCQueueTest, MultiProducerSingleConsumer) {
    // Use heap-allocated queue to avoid stack issues with large queue
    auto queue_ptr = std::make_unique<MPSCQueue<256>>();
    auto& queue = *queue_ptr;
    
    std::atomic<int> produced{0};
    std::atomic<int> consumed{0};
    std::atomic<bool> producers_done{false};
    
    constexpr int NUM_PRODUCERS = 4;
    constexpr int ITEMS_PER_PRODUCER = 100;
    
    // Consumer thread
    std::thread consumer([&]() {
        while (!producers_done.load(std::memory_order_acquire) || !queue.empty()) {
            SendRequest req;
            if (queue.try_pop_copy(req)) {
                consumed.fetch_add(1, std::memory_order_relaxed);
            } else {
                std::this_thread::yield();
            }
        }
    });
    
    // Producer threads
    std::vector<std::thread> producers;
    for (int p = 0; p < NUM_PRODUCERS; ++p) {
        producers.emplace_back([&, p]() {
            int local_produced = 0;
            for (int i = 0; i < ITEMS_PER_PRODUCER; ++i) {
                uint8_t data = static_cast<uint8_t>(p);
                // Retry on failure (queue might be temporarily full)
                while (!queue.try_push(&data, 1, i)) {
                    std::this_thread::yield();
                }
                ++local_produced;
            }
            produced.fetch_add(local_produced, std::memory_order_relaxed);
        });
    }
    
    // Wait for producers
    for (auto& t : producers) {
        t.join();
    }
    
    // Signal producers done
    producers_done.store(true, std::memory_order_release);
    
    // Wait for consumer
    consumer.join();
    
    EXPECT_EQ(produced.load(), NUM_PRODUCERS * ITEMS_PER_PRODUCER);
    EXPECT_EQ(consumed.load(), NUM_PRODUCERS * ITEMS_PER_PRODUCER);
}

TEST(MPSCQueueTest, StressTest) {
    auto queue_ptr = std::make_unique<MPSCQueue<256>>();
    auto& queue = *queue_ptr;
    
    std::atomic<uint64_t> push_count{0};
    std::atomic<uint64_t> pop_count{0};
    std::atomic<bool> producers_done{false};
    
    // Single consumer
    std::thread consumer([&]() {
        while (!producers_done.load(std::memory_order_acquire) || !queue.empty()) {
            queue.drain([&](const SendRequest&) {
                pop_count.fetch_add(1, std::memory_order_relaxed);
            });
            std::this_thread::yield();
        }
        // Final drain
        queue.drain([&](const SendRequest&) {
            pop_count.fetch_add(1, std::memory_order_relaxed);
        });
    });
    
    // Multiple producers
    std::vector<std::thread> producers;
    for (int p = 0; p < 4; ++p) {
        producers.emplace_back([&]() {
            uint8_t data = 0;
            int local_push = 0;
            for (int i = 0; i < 1000; ++i) {
                if (queue.try_push(&data, 1, 0)) {
                    ++local_push;
                }
            }
            push_count.fetch_add(local_push, std::memory_order_relaxed);
        });
    }
    
    for (auto& t : producers) {
        t.join();
    }
    
    producers_done.store(true, std::memory_order_release);
    consumer.join();
    
    // Some pushes may fail due to queue full, but pop should match push
    EXPECT_EQ(pop_count.load(), push_count.load());
}

// =============================================================================
// Performance Test
// =============================================================================

TEST(MPSCQueueTest, PushLatency) {
    auto queue_ptr = std::make_unique<MPSCQueue<256>>();
    auto& queue = *queue_ptr;
    
    constexpr int ITERATIONS = 10000;
    std::vector<uint64_t> latencies;
    latencies.reserve(ITERATIONS);
    
    uint8_t data = 0;
    
    for (int i = 0; i < ITERATIONS; ++i) {
        auto start = std::chrono::high_resolution_clock::now();
        queue.try_push(&data, 1, 0);
        auto end = std::chrono::high_resolution_clock::now();
        
        latencies.push_back(
            std::chrono::duration_cast<std::chrono::nanoseconds>(end - start).count()
        );
        
        // Pop to keep queue from filling
        SendRequest req;
        queue.try_pop_copy(req);
    }
    
    // Calculate stats
    std::sort(latencies.begin(), latencies.end());
    uint64_t min_lat = latencies.front();
    uint64_t max_lat = latencies.back();
    uint64_t p50 = latencies[ITERATIONS / 2];
    uint64_t p99 = latencies[ITERATIONS * 99 / 100];
    
    printf("MPSC Queue Push Latency:\n");
    printf("  Min: %lu ns\n", min_lat);
    printf("  P50: %lu ns\n", p50);
    printf("  P99: %lu ns\n", p99);
    printf("  Max: %lu ns\n", max_lat);
    
    // Should be under 1us for P50 on a reasonable system
    EXPECT_LT(p50, 2000u);  // P50 < 2us
}

// =============================================================================
// Main
// =============================================================================

int main(int argc, char** argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
