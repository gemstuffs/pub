// =============================================================================
// Unit Tests for core/ring_buffer.hpp
// 100% API Coverage
// =============================================================================

#include <gtest/gtest.h>
#include <thread>
#include <atomic>
#include <string>

#include "core/ring_buffer.hpp"

using namespace ptpx;

// =============================================================================
// SPSCRingBuffer Tests - Full Coverage
// =============================================================================

TEST(SPSCRingBufferTest, InitialStateIsEmpty) {
    SPSCRingBuffer<int, 16> buffer;
    EXPECT_TRUE(buffer.empty());
    EXPECT_FALSE(buffer.full());
    EXPECT_EQ(buffer.size(), 0ULL);
}

TEST(SPSCRingBufferTest, CapacityIsOneLessThanSize) {
    SPSCRingBuffer<int, 16> buffer;
    EXPECT_EQ(buffer.capacity(), 15ULL);
    
    SPSCRingBuffer<int, 256> buffer2;
    EXPECT_EQ(buffer2.capacity(), 255ULL);
}

TEST(SPSCRingBufferTest, PushIncreasesSize) {
    SPSCRingBuffer<int, 16> buffer;
    EXPECT_TRUE(buffer.try_push(42));
    EXPECT_EQ(buffer.size(), 1ULL);
    EXPECT_FALSE(buffer.empty());
}

TEST(SPSCRingBufferTest, PushPopSingleItem) {
    SPSCRingBuffer<int, 16> buffer;
    EXPECT_TRUE(buffer.try_push(42));
    
    int value;
    EXPECT_TRUE(buffer.try_pop(value));
    EXPECT_EQ(value, 42);
    EXPECT_TRUE(buffer.empty());
}

TEST(SPSCRingBufferTest, PushPopMultipleItems) {
    SPSCRingBuffer<int, 16> buffer;
    
    for (int i = 0; i < 10; ++i) {
        EXPECT_TRUE(buffer.try_push(i));
    }
    EXPECT_EQ(buffer.size(), 10ULL);
    
    for (int i = 0; i < 10; ++i) {
        int value;
        EXPECT_TRUE(buffer.try_pop(value));
        EXPECT_EQ(value, i);
    }
    EXPECT_TRUE(buffer.empty());
}

TEST(SPSCRingBufferTest, PopFromEmptyReturnsFalse) {
    SPSCRingBuffer<int, 16> buffer;
    int value;
    EXPECT_FALSE(buffer.try_pop(value));
}

TEST(SPSCRingBufferTest, PushToFullReturnsFalse) {
    SPSCRingBuffer<int, 16> buffer;
    
    for (size_t i = 0; i < buffer.capacity(); ++i) {
        EXPECT_TRUE(buffer.try_push(static_cast<int>(i)));
    }
    EXPECT_TRUE(buffer.full());
    EXPECT_FALSE(buffer.try_push(999));
}

TEST(SPSCRingBufferTest, PeekReturnsPointerWithoutRemoving) {
    SPSCRingBuffer<int, 16> buffer;
    buffer.try_push(42);
    buffer.try_push(43);
    
    const int* peeked = buffer.peek();
    EXPECT_NE(peeked, nullptr);
    EXPECT_EQ(*peeked, 42);
    EXPECT_EQ(buffer.size(), 2ULL);
}

TEST(SPSCRingBufferTest, PeekOnEmptyReturnsNull) {
    SPSCRingBuffer<int, 16> buffer;
    EXPECT_EQ(buffer.peek(), nullptr);
}

TEST(SPSCRingBufferTest, WrapAround) {
    SPSCRingBuffer<int, 8> buffer;
    
    for (int iter = 0; iter < 5; ++iter) {
        for (size_t i = 0; i < buffer.capacity(); ++i) {
            EXPECT_TRUE(buffer.try_push(static_cast<int>(i + iter * 100)));
        }
        for (size_t i = 0; i < buffer.capacity(); ++i) {
            int value;
            EXPECT_TRUE(buffer.try_pop(value));
            EXPECT_EQ(value, static_cast<int>(i + iter * 100));
        }
    }
}

TEST(SPSCRingBufferTest, SizeTracking) {
    SPSCRingBuffer<int, 16> buffer;
    
    EXPECT_EQ(buffer.size(), 0ULL);
    buffer.try_push(1);
    EXPECT_EQ(buffer.size(), 1ULL);
    buffer.try_push(2);
    EXPECT_EQ(buffer.size(), 2ULL);
    
    int value;
    buffer.try_pop(value);
    EXPECT_EQ(buffer.size(), 1ULL);
    buffer.try_pop(value);
    EXPECT_EQ(buffer.size(), 0ULL);
}

TEST(SPSCRingBufferTest, FullAndEmptyStates) {
    SPSCRingBuffer<int, 4> buffer;  // Capacity 3
    
    EXPECT_TRUE(buffer.empty());
    EXPECT_FALSE(buffer.full());
    
    buffer.try_push(1);
    EXPECT_FALSE(buffer.empty());
    EXPECT_FALSE(buffer.full());
    
    buffer.try_push(2);
    buffer.try_push(3);
    EXPECT_FALSE(buffer.empty());
    EXPECT_TRUE(buffer.full());
    
    int value;
    buffer.try_pop(value);
    EXPECT_FALSE(buffer.full());
}

TEST(SPSCRingBufferTest, ConcurrentProducerConsumer) {
    SPSCRingBuffer<int, 1024> buffer;
    std::atomic<int> consumed_count{0};
    const int ITEMS = 10000;
    
    std::thread consumer([&]() {
        int expected = 0;
        while (expected < ITEMS) {
            int value;
            if (buffer.try_pop(value)) {
                EXPECT_EQ(value, expected);
                ++expected;
                ++consumed_count;
            }
        }
    });
    
    for (int i = 0; i < ITEMS; ++i) {
        while (!buffer.try_push(i)) {
            std::this_thread::yield();
        }
    }
    
    consumer.join();
    EXPECT_EQ(consumed_count.load(), ITEMS);
}

TEST(SPSCRingBufferTest, WithStrings) {
    SPSCRingBuffer<std::string, 8> buffer;
    
    EXPECT_TRUE(buffer.try_push("Hello"));
    EXPECT_TRUE(buffer.try_push("World"));
    
    std::string value;
    EXPECT_TRUE(buffer.try_pop(value));
    EXPECT_EQ(value, "Hello");
    EXPECT_TRUE(buffer.try_pop(value));
    EXPECT_EQ(value, "World");
}

TEST(SPSCRingBufferTest, WithStructs) {
    struct Data {
        int x;
        double y;
    };
    
    SPSCRingBuffer<Data, 8> buffer;
    
    EXPECT_TRUE(buffer.try_push(Data{1, 2.5}));
    
    Data value;
    EXPECT_TRUE(buffer.try_pop(value));
    EXPECT_EQ(value.x, 1);
    EXPECT_DOUBLE_EQ(value.y, 2.5);
}

// =============================================================================
// MessageSlot Tests - Full Coverage
// =============================================================================

TEST(MessageSlotTest, DefaultConstruction) {
    MessageSlot slot;
    EXPECT_EQ(slot.length, 0U);
    EXPECT_EQ(slot.sequence, 0U);
    EXPECT_EQ(slot.timestamp, 0ULL);
    EXPECT_EQ(slot.type, MessageType::HEARTBEAT_REQUEST);
}

TEST(MessageSlotTest, DataReturnsValidPointer) {
    MessageSlot slot;
    EXPECT_NE(slot.data(), nullptr);
}

TEST(MessageSlotTest, ConstDataReturnsValidPointer) {
    const MessageSlot slot;
    EXPECT_NE(slot.data(), nullptr);
}

TEST(MessageSlotTest, PayloadPointsAfterHeader) {
    MessageSlot slot;
    EXPECT_EQ(slot.payload() - slot.data(), static_cast<ptrdiff_t>(MessageHeader::SIZE));
}

TEST(MessageSlotTest, ConstPayloadPointsAfterHeader) {
    const MessageSlot slot;
    EXPECT_EQ(slot.payload() - slot.data(), static_cast<ptrdiff_t>(MessageHeader::SIZE));
}

TEST(MessageSlotTest, PayloadSizeCalculation) {
    MessageSlot slot;
    slot.length = MessageHeader::SIZE;
    EXPECT_EQ(slot.payload_size(), 0ULL);
    
    slot.length = MessageHeader::SIZE + 100;
    EXPECT_EQ(slot.payload_size(), 100ULL);
    
    slot.length = 0;  // Edge case
    EXPECT_EQ(slot.payload_size(), 0ULL);
}

TEST(MessageSlotTest, BufferSize) {
    MessageSlot slot;
    EXPECT_GE(slot.buffer.size(), Config::MAX_MESSAGE_SIZE);
}

TEST(MessageSlotTest, FieldAssignment) {
    MessageSlot slot;
    slot.length = 1000;
    slot.sequence = 42;
    slot.timestamp = 123456789ULL;
    slot.type = MessageType::NEW_ORDER;
    
    EXPECT_EQ(slot.length, 1000U);
    EXPECT_EQ(slot.sequence, 42U);
    EXPECT_EQ(slot.timestamp, 123456789ULL);
    EXPECT_EQ(slot.type, MessageType::NEW_ORDER);
}

// =============================================================================
// MessagePool Tests - Full Coverage
// =============================================================================

TEST(MessagePoolTest, AcquireReturnsValidSlot) {
    MessagePool<16> pool;
    MessageSlot* slot = pool.acquire();
    EXPECT_NE(slot, nullptr);
}

TEST(MessagePoolTest, AcquireAndRelease) {
    MessagePool<16> pool;
    MessageSlot* slot = pool.acquire();
    ASSERT_NE(slot, nullptr);
    
    slot->length = 100;
    pool.release(slot);
    
    MessageSlot* slot2 = pool.acquire();
    EXPECT_NE(slot2, nullptr);
}

TEST(MessagePoolTest, ReleaseNullIsNoOp) {
    MessagePool<16> pool;
    pool.release(nullptr);  // Should not crash
}

TEST(MessagePoolTest, CanAcquireMultiple) {
    MessagePool<16> pool;
    std::vector<MessageSlot*> slots;
    
    for (int i = 0; i < 16; ++i) {
        MessageSlot* slot = pool.acquire();
        if (slot) {
            slots.push_back(slot);
        }
    }
    
    EXPECT_GT(slots.size(), 0ULL);
    
    for (auto* slot : slots) {
        pool.release(slot);
    }
}

TEST(MessagePoolTest, ReuseReleasedSlots) {
    MessagePool<4> pool;
    
    MessageSlot* slot1 = pool.acquire();
    ASSERT_NE(slot1, nullptr);
    pool.release(slot1);
    
    MessageSlot* slot2 = pool.acquire();
    EXPECT_NE(slot2, nullptr);
}

TEST(MessagePoolTest, AcquiredSlotsAreUsable) {
    MessagePool<4> pool;
    
    MessageSlot* slot = pool.acquire();
    ASSERT_NE(slot, nullptr);
    
    // Write data
    const char* data = "Test";
    std::memcpy(slot->data(), data, 4);
    slot->length = 4;
    
    EXPECT_EQ(std::memcmp(slot->data(), "Test", 4), 0);
    EXPECT_EQ(slot->length, 4U);
    
    pool.release(slot);
}

int main(int argc, char** argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
