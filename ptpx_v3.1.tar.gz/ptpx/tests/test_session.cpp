// =============================================================================
// ptpx - Session Layer Unit Tests
// =============================================================================
// Note: Built with -fno-exceptions, so no EXPECT_THROW tests

#include <gtest/gtest.h>
#include "../include/ptpx.hpp"
#include <thread>
#include <chrono>
#include <algorithm>

using namespace ptpx;

// =============================================================================
// SessionConfig Tests
// =============================================================================

class SessionConfigTest : public ::testing::Test {};

TEST_F(SessionConfigTest, ValidInitiatorConfig) {
    auto cfg = SessionConfig::initiator("TEST_SESSION");
    cfg.primary.host = "127.0.0.1";
    cfg.primary.port = 9000;
    
    EXPECT_TRUE(cfg.is_valid());
    EXPECT_EQ(cfg.validation_error(), "");
}

TEST_F(SessionConfigTest, InvalidEmptyName) {
    auto cfg = SessionConfig::initiator("");
    cfg.primary.host = "127.0.0.1";
    cfg.primary.port = 9000;
    
    EXPECT_FALSE(cfg.is_valid());
    EXPECT_EQ(cfg.validation_error(), "Session name is empty");
}

TEST_F(SessionConfigTest, InvalidNoEndpoint) {
    auto cfg = SessionConfig::initiator("TEST");
    // No host/port set
    
    EXPECT_FALSE(cfg.is_valid());
    EXPECT_NE(cfg.validation_error(), "");
}

TEST_F(SessionConfigTest, InvalidBufferSize) {
    auto cfg = SessionConfig::initiator("TEST");
    cfg.primary.host = "127.0.0.1";
    cfg.primary.port = 9000;
    cfg.send_buffer_size = 100;  // Too small
    
    EXPECT_FALSE(cfg.is_valid());
    EXPECT_NE(cfg.validation_error().find("send_buffer_size"), std::string::npos);
}

TEST_F(SessionConfigTest, InvalidHeartbeatConfig) {
    auto cfg = SessionConfig::initiator("TEST");
    cfg.primary.host = "127.0.0.1";
    cfg.primary.port = 9000;
    cfg.heartbeat.enabled = true;
    cfg.heartbeat.interval_ns = 5'000'000'000;  // 5s
    cfg.heartbeat.timeout_ns = 1'000'000'000;   // 1s - less than interval!
    
    EXPECT_FALSE(cfg.is_valid());
    EXPECT_NE(cfg.validation_error().find("timeout"), std::string::npos);
}

TEST_F(SessionConfigTest, BuilderPattern) {
    auto cfg = session("CME_ORDERS")
        .as_initiator()
        .connect_to("192.168.1.100", 9000)
        .transport(TransportSubType::AUTO)
        .interface("eth0")
        .heartbeat(1000, 5000)
        .reconnect(100, 30000, 10)
        .buffer_sizes(65536, 65536)
        .build();
    
    EXPECT_EQ(cfg.name, "CME_ORDERS");
    EXPECT_EQ(cfg.type, SessionType::INITIATOR);
    EXPECT_EQ(cfg.primary.host, "192.168.1.100");
    EXPECT_EQ(cfg.primary.port, 9000);
    EXPECT_EQ(cfg.primary.interface, "eth0");
    EXPECT_TRUE(cfg.heartbeat.enabled);
    EXPECT_EQ(cfg.heartbeat.interval_ns, 1'000'000'000ULL);
    EXPECT_EQ(cfg.heartbeat.timeout_ns, 5'000'000'000ULL);
    EXPECT_TRUE(cfg.reconnect.enabled);
    EXPECT_EQ(cfg.reconnect.max_attempts, 10u);
    EXPECT_TRUE(cfg.is_valid());
}

TEST_F(SessionConfigTest, FailoverConfig) {
    auto cfg = session("TEST")
        .as_initiator()
        .connect_to("primary.example.com", 9000)
        .failover("backup.example.com", 9001, "eth1")
        .build();
    
    EXPECT_TRUE(cfg.failover.has_value());
    EXPECT_EQ(cfg.failover->host, "backup.example.com");
    EXPECT_EQ(cfg.failover->port, 9001);
    EXPECT_EQ(cfg.failover->interface, "eth1");
}

TEST_F(SessionConfigTest, InvalidReconnectConfig) {
    auto cfg = session("TEST")
        .as_initiator()
        .connect_to("127.0.0.1", 9000)
        .reconnect(100, 50, 5)  // max < initial - invalid
        .build();
    
    EXPECT_FALSE(cfg.is_valid());
    EXPECT_NE(cfg.validation_error().find("max_delay"), std::string::npos);
}

// =============================================================================
// SessionStats Tests (Thread Safety)
// =============================================================================

class SessionStatsTest : public ::testing::Test {
protected:
    SessionStats stats;
};

TEST_F(SessionStatsTest, AtomicIncrements) {
    constexpr int NUM_THREADS = 4;
    constexpr int INCREMENTS_PER_THREAD = 10000;
    
    std::vector<std::thread> threads;
    for (int i = 0; i < NUM_THREADS; ++i) {
        threads.emplace_back([this]() {
            for (int j = 0; j < INCREMENTS_PER_THREAD; ++j) {
                stats.messages_sent.fetch_add(1, std::memory_order_relaxed);
                stats.bytes_sent.fetch_add(100, std::memory_order_relaxed);
            }
        });
    }
    
    for (auto& t : threads) t.join();
    
    EXPECT_EQ(stats.messages_sent.load(), NUM_THREADS * INCREMENTS_PER_THREAD);
    EXPECT_EQ(stats.bytes_sent.load(), NUM_THREADS * INCREMENTS_PER_THREAD * 100);
}

TEST_F(SessionStatsTest, RTTRecording) {
    stats.record_rtt(1000);
    EXPECT_EQ(stats.min_rtt_ns.load(), 1000u);
    EXPECT_EQ(stats.max_rtt_ns.load(), 1000u);
    EXPECT_EQ(stats.avg_rtt_ns(), 1000u);
    
    stats.record_rtt(500);
    EXPECT_EQ(stats.min_rtt_ns.load(), 500u);
    EXPECT_EQ(stats.max_rtt_ns.load(), 1000u);
    
    stats.record_rtt(2000);
    EXPECT_EQ(stats.min_rtt_ns.load(), 500u);
    EXPECT_EQ(stats.max_rtt_ns.load(), 2000u);
}

TEST_F(SessionStatsTest, Reset) {
    stats.messages_sent.store(100, std::memory_order_relaxed);
    stats.bytes_sent.store(10000, std::memory_order_relaxed);
    stats.connect_count.store(5, std::memory_order_relaxed);
    
    stats.reset();
    
    EXPECT_EQ(stats.messages_sent.load(), 0u);
    EXPECT_EQ(stats.bytes_sent.load(), 0u);
    EXPECT_EQ(stats.connect_count.load(), 0u);
}

// =============================================================================
// SessionFactory Tests
// =============================================================================

class SessionFactoryTest : public ::testing::Test {};

TEST_F(SessionFactoryTest, CreateReturnsNullOnInvalidConfig) {
    SessionConfig cfg;  // Empty name
    
    auto session = SessionFactory::create(cfg);
    EXPECT_EQ(session, nullptr);
}

TEST_F(SessionFactoryTest, CreateOrThrowReturnsNullOnInvalidConfig) {
    // With -fno-exceptions, create_or_throw behaves like create
    SessionConfig cfg;  // Empty name
    
    auto session = SessionFactory::create_or_throw(cfg);
    EXPECT_EQ(session, nullptr);
}

TEST_F(SessionFactoryTest, CreateSucceedsWithValidConfig) {
    auto cfg = session("TEST")
        .as_initiator()
        .connect_to("127.0.0.1", 9999)
        .no_heartbeat()
        .no_reconnect()
        .build();
    
    auto s = SessionFactory::create(cfg);
    ASSERT_NE(s, nullptr);
    EXPECT_EQ(s->name(), "TEST");
    EXPECT_EQ(s->type(), SessionType::INITIATOR);
    EXPECT_EQ(s->state(), SessionState::DISCONNECTED);
}

// =============================================================================
// Session State Machine Tests
// =============================================================================

class SessionStateTest : public ::testing::Test {
protected:
    std::unique_ptr<ISession> sess;
    
    void SetUp() override {
        auto cfg = SessionConfig::initiator("STATE_TEST");
        cfg.primary.host = "127.0.0.1";
        cfg.primary.port = 9999;
        cfg.heartbeat.enabled = false;
        cfg.reconnect.enabled = false;
        sess = SessionFactory::create(cfg);
    }
};

TEST_F(SessionStateTest, InitialState) {
    EXPECT_EQ(sess->state(), SessionState::DISCONNECTED);
    EXPECT_FALSE(sess->is_connected());
}

TEST_F(SessionStateTest, StopFromDisconnectedIsNoop) {
    EXPECT_EQ(sess->state(), SessionState::DISCONNECTED);
    sess->stop();  // Should not crash
    EXPECT_EQ(sess->state(), SessionState::DISCONNECTED);
}

TEST_F(SessionStateTest, SendFailsWhenDisconnected) {
    uint8_t data[10] = {0};
    auto result = sess->send(MessageType::NEW_ORDER, data, sizeof(data));
    EXPECT_EQ(result, SendResult::DISCONNECTED);
}

TEST_F(SessionStateTest, DoubleStopIsNoop) {
    sess->stop();
    sess->stop();  // Second stop should be safe
    EXPECT_EQ(sess->state(), SessionState::DISCONNECTED);
}

// =============================================================================
// SessionManager Tests
// =============================================================================

class SessionManagerTest : public ::testing::Test {
protected:
    SessionManager manager;
};

TEST_F(SessionManagerTest, AddAndGetSession) {
    auto cfg = session("SESSION_1")
        .as_initiator()
        .connect_to("127.0.0.1", 9000)
        .build();
    
    auto* s = manager.add_session(cfg);
    ASSERT_NE(s, nullptr);
    EXPECT_EQ(s->name(), "SESSION_1");
    
    auto* retrieved = manager.get_session("SESSION_1");
    EXPECT_EQ(retrieved, s);
}

TEST_F(SessionManagerTest, HasSession) {
    auto cfg = session("EXISTS")
        .as_initiator()
        .connect_to("127.0.0.1", 9000)
        .build();
    
    manager.add_session(cfg);
    
    EXPECT_TRUE(manager.has_session("EXISTS"));
    EXPECT_FALSE(manager.has_session("NOT_EXISTS"));
}

TEST_F(SessionManagerTest, RejectsDuplicateName) {
    auto cfg = session("DUPLICATE")
        .as_initiator()
        .connect_to("127.0.0.1", 9000)
        .build();
    
    auto* first = manager.add_session(cfg);
    ASSERT_NE(first, nullptr);
    
    auto* second = manager.add_session(cfg);
    EXPECT_EQ(second, nullptr);  // Should reject duplicate
    
    EXPECT_EQ(manager.session_count(), 1u);
}

TEST_F(SessionManagerTest, RemoveSession) {
    auto cfg = session("TO_REMOVE")
        .as_initiator()
        .connect_to("127.0.0.1", 9000)
        .build();
    
    manager.add_session(cfg);
    EXPECT_EQ(manager.session_count(), 1u);
    
    manager.remove_session("TO_REMOVE");
    EXPECT_EQ(manager.session_count(), 0u);
    EXPECT_FALSE(manager.has_session("TO_REMOVE"));
}

TEST_F(SessionManagerTest, ForEachSession) {
    manager.add_session(session("X").as_initiator().connect_to("127.0.0.1", 9000).build());
    manager.add_session(session("Y").as_initiator().connect_to("127.0.0.1", 9001).build());
    
    int count = 0;
    manager.for_each_session([&count](ISession& s) {
        count++;
        EXPECT_EQ(s.state(), SessionState::DISCONNECTED);
    });
    
    EXPECT_EQ(count, 2);
}

TEST_F(SessionManagerTest, GetNonExistentReturnsNull) {
    EXPECT_EQ(manager.get_session("NONEXISTENT"), nullptr);
}

TEST_F(SessionManagerTest, AddInvalidConfigReturnsNull) {
    SessionConfig invalid_cfg;  // Empty name
    EXPECT_EQ(manager.add_session(invalid_cfg), nullptr);
}

// =============================================================================
// Sequence Wrap-Around Tests
// =============================================================================

class SequenceTest : public ::testing::Test {};

TEST_F(SequenceTest, WrapAroundDetection) {
    // Test the sequence_diff helper
    EXPECT_EQ(detail::sequence_diff(1, 1), 0);
    EXPECT_EQ(detail::sequence_diff(2, 1), 1);
    EXPECT_EQ(detail::sequence_diff(1, 2), -1);
    
    // Wrap-around case: 0xFFFFFFFF -> 0
    EXPECT_EQ(detail::sequence_diff(0, 0xFFFFFFFF), 1);  // 0 is 1 more than max
    EXPECT_EQ(detail::sequence_diff(0xFFFFFFFF, 0), -1); // max is 1 less than 0
    
    // Large gap
    EXPECT_TRUE(detail::sequence_less_than(0xFFFFFFFE, 0xFFFFFFFF));
    EXPECT_FALSE(detail::sequence_less_than(0xFFFFFFFF, 0xFFFFFFFE));
}

// =============================================================================
// EndpointConfig Tests
// =============================================================================

TEST(EndpointConfigTest, Validity) {
    EndpointConfig empty;
    EXPECT_FALSE(empty.is_valid());
    
    EndpointConfig noPort;
    noPort.host = "localhost";
    EXPECT_FALSE(noPort.is_valid());
    
    EndpointConfig valid;
    valid.host = "localhost";
    valid.port = 9000;
    EXPECT_TRUE(valid.is_valid());
}

TEST(EndpointConfigTest, ToString) {
    EndpointConfig ep;
    ep.host = "192.168.1.1";
    ep.port = 8080;
    
    EXPECT_EQ(ep.to_string(), "192.168.1.1:8080");
}

TEST(EndpointConfigTest, Equality) {
    EndpointConfig a{"host1", 9000, "eth0"};
    EndpointConfig b{"host1", 9000, "eth0"};
    EndpointConfig c{"host2", 9000, "eth0"};
    
    EXPECT_EQ(a, b);
    EXPECT_FALSE(a == c);
}

// =============================================================================
// Reconnect Delay Calculation Tests
// =============================================================================

TEST(ReconnectDelayTest, ExponentialBackoff) {
    ReconnectConfig cfg;
    cfg.initial_delay_ns = 1000;
    cfg.max_delay_ns = 100000;
    cfg.backoff_multiplier = 2.0;
    cfg.jitter_factor = 0;  // No jitter for deterministic test
    cfg.max_attempts = 10;
    
    EXPECT_EQ(detail::calculate_reconnect_delay(cfg, 0), 1000u);
    EXPECT_EQ(detail::calculate_reconnect_delay(cfg, 1), 2000u);
    EXPECT_EQ(detail::calculate_reconnect_delay(cfg, 2), 4000u);
    EXPECT_EQ(detail::calculate_reconnect_delay(cfg, 3), 8000u);
}

TEST(ReconnectDelayTest, MaxDelayClamp) {
    ReconnectConfig cfg;
    cfg.initial_delay_ns = 1000;
    cfg.max_delay_ns = 5000;
    cfg.backoff_multiplier = 2.0;
    cfg.jitter_factor = 0;
    
    // Should be clamped to max_delay_ns
    EXPECT_EQ(detail::calculate_reconnect_delay(cfg, 10), 5000u);
}

TEST(ReconnectDelayTest, JitterApplied) {
    ReconnectConfig cfg;
    cfg.initial_delay_ns = 10000;
    cfg.max_delay_ns = 100000;
    cfg.backoff_multiplier = 1.0;  // No backoff
    cfg.jitter_factor = 0.1;  // 10% jitter
    
    // Run multiple times to verify jitter is being applied
    uint64_t min_seen = UINT64_MAX;
    uint64_t max_seen = 0;
    
    for (int i = 0; i < 100; ++i) {
        uint64_t delay = detail::calculate_reconnect_delay(cfg, 0);
        min_seen = std::min(min_seen, delay);
        max_seen = std::max(max_seen, delay);
    }
    
    // With 10% jitter, should see values in range [9000, 11000]
    EXPECT_GE(min_seen, 9000u);
    EXPECT_LE(max_seen, 11000u);
    EXPECT_NE(min_seen, max_seen);  // Should have some variation
}

// =============================================================================
// Time Elapsed Helper Tests
// =============================================================================

TEST(TimeElapsedTest, BasicElapsed) {
    EXPECT_TRUE(detail::time_elapsed(0, 100, 200));
    EXPECT_TRUE(detail::time_elapsed(0, 100, 100));
    EXPECT_FALSE(detail::time_elapsed(0, 100, 50));
}

TEST(TimeElapsedTest, WrapAroundHandling) {
    // If now < start, assume elapsed (wrap-around)
    EXPECT_TRUE(detail::time_elapsed(UINT64_MAX - 10, 100, 5));
}

// =============================================================================
// Main
// =============================================================================

int main(int argc, char** argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
