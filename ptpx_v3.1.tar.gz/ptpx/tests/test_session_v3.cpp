// =============================================================================
// ptpx - Session v3 Tests
// =============================================================================

#include "../include/ptpx_v3.hpp"
#include <gtest/gtest.h>
#include <thread>
#include <chrono>
#include <atomic>

using namespace ptpx;

// =============================================================================
// Configuration Tests
// =============================================================================

TEST(SessionConfigTest, DefaultValues) {
    SessionConfig cfg;
    cfg.name = "TEST";
    cfg.primary.host = "127.0.0.1";
    cfg.primary.port = 9000;
    
    EXPECT_TRUE(cfg.is_valid());
    EXPECT_EQ(cfg.type, SessionType::INITIATOR);
    EXPECT_EQ(cfg.transport_type, TransportType::ONLOAD);
    EXPECT_TRUE(cfg.enable_stats);
    EXPECT_TRUE(cfg.enable_hw_timestamps);
}

TEST(SessionConfigTest, ValidationEmpty) {
    SessionConfig cfg;
    EXPECT_FALSE(cfg.is_valid());
    EXPECT_EQ(cfg.validation_error(), "Session name is empty");
}

TEST(SessionConfigTest, ValidationNoEndpoint) {
    SessionConfig cfg;
    cfg.name = "TEST";
    cfg.type = SessionType::INITIATOR;
    EXPECT_FALSE(cfg.is_valid());
    EXPECT_NE(cfg.validation_error().find("endpoint"), std::string::npos);
}

TEST(SessionConfigTest, ValidationAcceptor) {
    SessionConfig cfg;
    cfg.name = "TEST";
    cfg.type = SessionType::ACCEPTOR;
    cfg.primary.port = 9000;  // Only port needed for acceptor
    EXPECT_TRUE(cfg.is_valid());
}

// =============================================================================
// Session Builder Tests
// =============================================================================

TEST(SessionBuilderTest, BasicBuild) {
    auto cfg = session("CME_ORDERS")
        .as_initiator()
        .connect_to("10.0.0.1", 9000)
        .tcpdirect()
        .build();
    
    EXPECT_EQ(cfg.name, "CME_ORDERS");
    EXPECT_EQ(cfg.type, SessionType::INITIATOR);
    EXPECT_EQ(cfg.primary.host, "10.0.0.1");
    EXPECT_EQ(cfg.primary.port, 9000);
    EXPECT_EQ(cfg.transport_type, TransportType::TCPDIRECT);
    EXPECT_TRUE(cfg.is_valid());
}

TEST(SessionBuilderTest, FullConfiguration) {
    auto cfg = session("NYSE_MD")
        .as_initiator()
        .connect_to("10.0.0.1", 9000)
        .interface("enp1s0f0")
        .onload()
        .thread("IO_NYSE")
        .failover("10.0.0.2", 9000)
        .heartbeat(1000, 5000)
        .reconnect(100, 30000, 10)
        .stats(true)
        .hw_timestamps(true)
        .build();
    
    EXPECT_EQ(cfg.name, "NYSE_MD");
    EXPECT_EQ(cfg.primary.interface, "enp1s0f0");
    EXPECT_EQ(cfg.transport_type, TransportType::ONLOAD);
    EXPECT_TRUE(cfg.thread_name.has_value());
    EXPECT_EQ(*cfg.thread_name, "IO_NYSE");
    EXPECT_TRUE(cfg.failover.has_value());
    EXPECT_EQ(cfg.failover->host, "10.0.0.2");
    EXPECT_TRUE(cfg.heartbeat.enabled);
    EXPECT_EQ(cfg.heartbeat.interval_ns, 1000'000'000ULL);
    EXPECT_TRUE(cfg.reconnect.enabled);
    EXPECT_EQ(cfg.reconnect.max_attempts, 10u);
    EXPECT_TRUE(cfg.is_valid());
}

TEST(SessionBuilderTest, DisableFeatures) {
    auto cfg = session("TEST")
        .as_initiator()
        .connect_to("127.0.0.1", 9000)
        .no_heartbeat()
        .no_reconnect()
        .stats(false)
        .build();
    
    EXPECT_FALSE(cfg.heartbeat.enabled);
    EXPECT_FALSE(cfg.reconnect.enabled);
    EXPECT_FALSE(cfg.enable_stats);
}

TEST(SessionBuilderTest, CreateSession) {
    auto s = session("TEST")
        .as_initiator()
        .connect_to("127.0.0.1", 9999)
        .onload()
        .create();
    
    ASSERT_NE(s, nullptr);
    EXPECT_EQ(s->name(), "TEST");
    EXPECT_EQ(s->type(), SessionType::INITIATOR);
    EXPECT_EQ(s->state(), SessionState::DISCONNECTED);
}

// =============================================================================
// Session State Tests
// =============================================================================

TEST(SessionStateTest, InitialState) {
    auto s = session("TEST")
        .connect_to("127.0.0.1", 9999)
        .create();
    
    EXPECT_EQ(s->state(), SessionState::DISCONNECTED);
    EXPECT_FALSE(s->is_connected());
}

TEST(SessionStateTest, StatisticsInitial) {
    auto s = session("TEST")
        .connect_to("127.0.0.1", 9999)
        .create();
    
    const auto& stats = s->stats();
    EXPECT_EQ(stats.connect_count.load(), 0u);
    EXPECT_EQ(stats.messages_sent.load(), 0u);
    EXPECT_EQ(stats.messages_received.load(), 0u);
}

TEST(SessionStateTest, LatencyStatsInitial) {
    auto s = session("TEST")
        .connect_to("127.0.0.1", 9999)
        .create();
    
    const auto& lstats = s->latency_stats();
    EXPECT_EQ(lstats.count(), 0u);
    EXPECT_FALSE(lstats.has_hw_timestamps());
}

// =============================================================================
// Send API Tests (without actual network)
// =============================================================================

TEST(SessionSendTest, SendDisconnected) {
    auto s = session("TEST")
        .connect_to("127.0.0.1", 9999)
        .create();
    
    uint8_t data[] = {1, 2, 3, 4};
    
    // All send methods should return DISCONNECTED
    EXPECT_EQ(s->send_immediate(MessageType::NEW_ORDER, data, sizeof(data)), 
              SendResult::DISCONNECTED);
    EXPECT_EQ(s->send_async(MessageType::NEW_ORDER, data, sizeof(data)), 
              SendResult::DISCONNECTED);
    EXPECT_EQ(s->send(MessageType::NEW_ORDER, data, sizeof(data)), 
              SendResult::DISCONNECTED);
}

TEST(SessionSendTest, SendConvenienceMethods) {
    auto s = session("TEST")
        .connect_to("127.0.0.1", 9999)
        .create();
    
    uint8_t data[] = {1, 2, 3, 4};
    
    EXPECT_EQ(s->send_order(data, sizeof(data)), SendResult::DISCONNECTED);
    EXPECT_EQ(s->send_cancel(data, sizeof(data)), SendResult::DISCONNECTED);
}

// =============================================================================
// Callback Tests
// =============================================================================

TEST(SessionCallbackTest, SetCallbacks) {
    auto s = session("TEST")
        .connect_to("127.0.0.1", 9999)
        .create();
    
    bool connect_called = false;
    bool state_change_called = false;
    
    SessionCallbacks cb;
    cb.on_connect = [&](ISession&) { connect_called = true; };
    cb.on_state_change = [&](ISession&, SessionState, SessionState) { state_change_called = true; };
    
    s->set_callbacks(cb);
    
    // Callbacks are set but not called until events occur
    EXPECT_FALSE(connect_called);
    EXPECT_FALSE(state_change_called);
}

// =============================================================================
// Stats Control Tests
// =============================================================================

TEST(SessionStatsTest, EnableDisable) {
    auto s = session("TEST")
        .connect_to("127.0.0.1", 9999)
        .stats(true)
        .create();
    
    // Stats should be enabled
    const auto& cfg = s->config();
    EXPECT_TRUE(cfg.enable_stats);
    
    // Can disable at runtime
    s->enable_stats(false);
    
    // Reset stats
    s->reset_stats();
    EXPECT_EQ(s->stats().connect_count.load(), 0u);
}

// =============================================================================
// Thread Binding Tests  
// =============================================================================

TEST(SessionThreadTest, NoThreadSpecified) {
    auto cfg = session("TEST")
        .connect_to("127.0.0.1", 9999)
        .build();
    
    EXPECT_FALSE(cfg.thread_name.has_value());
}

TEST(SessionThreadTest, NamedThread) {
    // Register thread first
    ThreadRegistry::instance().clear();
    register_thread("IO_TEST").cpu_affinity(0).create();
    
    auto cfg = session("TEST")
        .connect_to("127.0.0.1", 9999)
        .thread("IO_TEST")
        .build();
    
    EXPECT_TRUE(cfg.thread_name.has_value());
    EXPECT_EQ(*cfg.thread_name, "IO_TEST");
    
    ThreadRegistry::instance().clear();
}

// =============================================================================
// Transport Selection Tests
// =============================================================================

TEST(TransportSelectionTest, TCPDirect) {
    auto cfg = session("TEST")
        .connect_to("127.0.0.1", 9999)
        .tcpdirect()
        .build();
    
    EXPECT_EQ(cfg.transport_type, TransportType::TCPDIRECT);
}

TEST(TransportSelectionTest, Onload) {
    auto cfg = session("TEST")
        .connect_to("127.0.0.1", 9999)
        .onload()
        .build();
    
    EXPECT_EQ(cfg.transport_type, TransportType::ONLOAD);
}

// =============================================================================
// Endpoint Configuration Tests
// =============================================================================

TEST(EndpointConfigTest, Validity) {
    EndpointConfig ep;
    EXPECT_FALSE(ep.is_valid());
    
    ep.host = "127.0.0.1";
    EXPECT_FALSE(ep.is_valid());
    
    ep.port = 9000;
    EXPECT_TRUE(ep.is_valid());
}

TEST(EndpointConfigTest, ToString) {
    EndpointConfig ep{"10.0.0.1", 9000, ""};
    EXPECT_EQ(ep.to_string(), "10.0.0.1:9000");
}

TEST(EndpointConfigTest, Equality) {
    EndpointConfig a{"10.0.0.1", 9000, "eth0"};
    EndpointConfig b{"10.0.0.1", 9000, "eth0"};
    EndpointConfig c{"10.0.0.2", 9000, "eth0"};
    
    EXPECT_EQ(a, b);
    EXPECT_FALSE(a == c);
}

// =============================================================================
// Sequence Number Tests
// =============================================================================

TEST(SessionSequenceTest, InitialSequence) {
    auto s = session("TEST")
        .connect_to("127.0.0.1", 9999)
        .create();
    
    // Default initial sequence is 1
    EXPECT_EQ(s->next_send_sequence(), 1u);
    EXPECT_EQ(s->last_recv_sequence(), 0u);
}

// =============================================================================
// Integration Test (without actual network)
// =============================================================================

TEST(SessionIntegrationTest, FullWorkflow) {
    ThreadRegistry::instance().clear();
    
    // Register thread
    EXPECT_TRUE(register_thread("IO_CME").cpu_affinity(0).create());
    
    // Create session
    auto s = session("CME_ORDERS")
        .as_initiator()
        .connect_to("127.0.0.1", 9999)
        .onload()
        .thread("IO_CME")
        .heartbeat(1000, 5000)
        .reconnect(100, 30000)
        .stats(true)
        .hw_timestamps(true)
        .create();
    
    ASSERT_NE(s, nullptr);
    
    // Set callbacks
    std::atomic<int> message_count{0};
    SessionCallbacks cb;
    cb.on_message = [&](ISession&, const MessageHeader&, const uint8_t*, size_t) {
        message_count.fetch_add(1);
    };
    s->set_callbacks(cb);
    
    // Check initial state
    EXPECT_EQ(s->state(), SessionState::DISCONNECTED);
    EXPECT_EQ(s->name(), "CME_ORDERS");
    EXPECT_EQ(s->type(), SessionType::INITIATOR);
    EXPECT_STREQ(s->transport_name(), "none");
    
    // Stop and cleanup
    s->stop();
    EXPECT_EQ(s->state(), SessionState::DISCONNECTED);
    
    ThreadRegistry::instance().clear();
}

// =============================================================================
// Main
// =============================================================================

int main(int argc, char** argv) {
    testing::InitGoogleTest(&argc, argv);
    ptpx::initialize();
    return RUN_ALL_TESTS();
}

// =============================================================================
// Idle-Aware Heartbeat Tests
// =============================================================================

TEST(HeartbeatTest, IdleAwareHeartbeatDesign) {
    // Verify the heartbeat design: heartbeats should only be sent during idle periods
    using namespace ptpx;
    
    SessionConfig config;
    config.name = "HeartbeatTest";
    config.primary = EndpointConfig{"127.0.0.1", 12345, ""};
    config.heartbeat.enabled = true;
    config.heartbeat.interval_ns = 1'000'000'000;  // 1 second
    config.heartbeat.timeout_ns = 5'000'000'000;   // 5 seconds
    
    EXPECT_TRUE(config.heartbeat.enabled);
    EXPECT_EQ(config.heartbeat.interval_ns, 1'000'000'000ULL);
}

TEST(HeartbeatTest, LastSendTimestampTracking) {
    using namespace ptpx;
    
    HeartbeatConfig hb_config;
    hb_config.enabled = true;
    hb_config.interval_ns = 1'000'000'000;
    hb_config.timeout_ns = 5'000'000'000;
    
    EXPECT_TRUE(hb_config.enabled);
    EXPECT_EQ(hb_config.interval_ns, 1'000'000'000ULL);
    EXPECT_EQ(hb_config.timeout_ns, 5'000'000'000ULL);
}

TEST(HeartbeatTest, IdleDetectionLogic) {
    uint64_t last_send_ns = 1000;
    uint64_t last_recv_ns = 2000;
    uint64_t interval_ns = 500;
    uint64_t now = 3000;
    
    uint64_t last_activity = std::max(last_send_ns, last_recv_ns);
    EXPECT_EQ(last_activity, 2000ULL);
    
    bool is_idle = (now - last_activity) > interval_ns;
    EXPECT_TRUE(is_idle);
    
    last_send_ns = 2800;
    last_activity = std::max(last_send_ns, last_recv_ns);
    EXPECT_EQ(last_activity, 2800ULL);
    
    is_idle = (now - last_activity) > interval_ns;
    EXPECT_FALSE(is_idle);
}

TEST(HeartbeatTest, HeartbeatMessageExclusion) {
    using namespace ptpx;
    
    EXPECT_EQ(static_cast<uint8_t>(MessageType::HEARTBEAT_REQUEST), 0x01);
    EXPECT_EQ(static_cast<uint8_t>(MessageType::HEARTBEAT_RESPONSE), 0x02);
    EXPECT_EQ(static_cast<uint8_t>(MessageType::NEW_ORDER), 0x10);
    EXPECT_EQ(static_cast<uint8_t>(MessageType::EXECUTION_REPORT), 0x20);
}

TEST(HeartbeatTest, ConfigurationValidation) {
    using namespace ptpx;
    
    HeartbeatConfig config1;
    config1.enabled = false;
    EXPECT_FALSE(config1.enabled);
    
    HeartbeatConfig config2;
    config2.enabled = true;
    config2.interval_ns = 500'000'000;
    config2.timeout_ns = 2'000'000'000;
    
    EXPECT_TRUE(config2.enabled);
    EXPECT_LT(config2.interval_ns, config2.timeout_ns);
}

TEST(HeartbeatTest, SessionBuilderHeartbeatConfig) {
    using namespace ptpx;
    
    auto config = SessionBuilder("TestSession")
        .connect_to("127.0.0.1", 9000)
        .heartbeat(1000, 5000)
        .build();
    
    EXPECT_TRUE(config.heartbeat.enabled);
    EXPECT_EQ(config.heartbeat.interval_ns, 1'000'000'000ULL);
    EXPECT_EQ(config.heartbeat.timeout_ns, 5'000'000'000ULL);
    
    auto config2 = SessionBuilder("TestSession2")
        .connect_to("127.0.0.1", 9001)
        .no_heartbeat()
        .build();
    
    EXPECT_FALSE(config2.heartbeat.enabled);
}
