// =============================================================================
// ptpx - Socket Integration Tests
// Tests real network behavior: disconnect, reconnect, partial messages
// =============================================================================

#include <gtest/gtest.h>
#include <thread>
#include <chrono>
#include <atomic>
#include <vector>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <poll.h>
#include <cerrno>
#include <cstring>

#include "core/common.hpp"
#include "net/connection_manager.hpp"

using namespace ptpx;

// =============================================================================
// Test Utilities
// =============================================================================

class TestServer {
public:
    TestServer() : listen_fd_(-1), client_fd_(-1), port_(0), running_(false) {}
    
    ~TestServer() {
        stop();
    }
    
    bool start(uint16_t port = 0) {
        listen_fd_ = socket(AF_INET, SOCK_STREAM, 0);
        if (listen_fd_ < 0) return false;
        
        int opt = 1;
        setsockopt(listen_fd_, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
        
        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        addr.sin_port = htons(port);
        
        if (bind(listen_fd_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) < 0) {
            close(listen_fd_);
            listen_fd_ = -1;
            return false;
        }
        
        // Get assigned port
        socklen_t len = sizeof(addr);
        getsockname(listen_fd_, reinterpret_cast<sockaddr*>(&addr), &len);
        port_ = ntohs(addr.sin_port);
        
        if (listen(listen_fd_, 1) < 0) {
            close(listen_fd_);
            listen_fd_ = -1;
            return false;
        }
        
        running_ = true;
        return true;
    }
    
    void stop() {
        running_ = false;
        if (client_fd_ >= 0) {
            close(client_fd_);
            client_fd_ = -1;
        }
        if (listen_fd_ >= 0) {
            close(listen_fd_);
            listen_fd_ = -1;
        }
    }
    
    bool accept_client(int timeout_ms = 1000) {
        struct pollfd pfd = {listen_fd_, POLLIN, 0};
        if (poll(&pfd, 1, timeout_ms) <= 0) return false;
        
        client_fd_ = accept(listen_fd_, nullptr, nullptr);
        if (client_fd_ < 0) return false;
        
        // Set non-blocking
        int flags = fcntl(client_fd_, F_GETFL, 0);
        fcntl(client_fd_, F_SETFL, flags | O_NONBLOCK);
        
        // TCP_NODELAY
        int opt = 1;
        setsockopt(client_fd_, IPPROTO_TCP, TCP_NODELAY, &opt, sizeof(opt));
        
        return true;
    }
    
    void disconnect_client() {
        if (client_fd_ >= 0) {
            close(client_fd_);
            client_fd_ = -1;
        }
    }
    
    void reset_client() {
        if (client_fd_ >= 0) {
            struct linger sl = {1, 0};  // Enable linger with 0 timeout = RST
            setsockopt(client_fd_, SOL_SOCKET, SO_LINGER, &sl, sizeof(sl));
            close(client_fd_);
            client_fd_ = -1;
        }
    }
    
    ssize_t send_data(const void* data, size_t len) {
        if (client_fd_ < 0) return -1;
        return ::send(client_fd_, data, len, MSG_NOSIGNAL);
    }
    
    ssize_t recv_data(void* buf, size_t len) {
        if (client_fd_ < 0) return -1;
        return ::recv(client_fd_, buf, len, MSG_DONTWAIT);
    }
    
    // Send partial message (for testing partial read handling)
    bool send_partial_message(const void* data, size_t total_len, size_t chunk_size, int delay_ms) {
        const uint8_t* ptr = static_cast<const uint8_t*>(data);
        size_t sent = 0;
        
        while (sent < total_len) {
            size_t to_send = std::min(chunk_size, total_len - sent);
            ssize_t n = send_data(ptr + sent, to_send);
            if (n <= 0) return false;
            sent += n;
            
            if (delay_ms > 0 && sent < total_len) {
                std::this_thread::sleep_for(std::chrono::milliseconds(delay_ms));
            }
        }
        return true;
    }
    
    uint16_t port() const { return port_; }
    bool has_client() const { return client_fd_ >= 0; }
    int client_fd() const { return client_fd_; }
    
private:
    int listen_fd_;
    int client_fd_;
    uint16_t port_;
    std::atomic<bool> running_;
};

class TestClient {
public:
    TestClient() : fd_(-1) {}
    
    ~TestClient() {
        disconnect();
    }
    
    bool connect(uint16_t port, int timeout_ms = 1000) {
        fd_ = socket(AF_INET, SOCK_STREAM, 0);
        if (fd_ < 0) return false;
        
        // Set non-blocking for connect
        int flags = fcntl(fd_, F_GETFL, 0);
        fcntl(fd_, F_SETFL, flags | O_NONBLOCK);
        
        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        addr.sin_port = htons(port);
        
        int ret = ::connect(fd_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr));
        if (ret < 0 && errno != EINPROGRESS) {
            close(fd_);
            fd_ = -1;
            return false;
        }
        
        // Wait for connect
        struct pollfd pfd = {fd_, POLLOUT, 0};
        ret = poll(&pfd, 1, timeout_ms);
        if (ret <= 0) {
            close(fd_);
            fd_ = -1;
            return false;
        }
        
        // Check for errors
        int err = 0;
        socklen_t len = sizeof(err);
        getsockopt(fd_, SOL_SOCKET, SO_ERROR, &err, &len);
        if (err != 0) {
            close(fd_);
            fd_ = -1;
            return false;
        }
        
        // TCP_NODELAY
        int opt = 1;
        setsockopt(fd_, IPPROTO_TCP, TCP_NODELAY, &opt, sizeof(opt));
        
        return true;
    }
    
    void disconnect() {
        if (fd_ >= 0) {
            close(fd_);
            fd_ = -1;
        }
    }
    
    ssize_t send_data(const void* data, size_t len) {
        if (fd_ < 0) return -1;
        return ::send(fd_, data, len, MSG_NOSIGNAL);
    }
    
    ssize_t recv_data(void* buf, size_t len, int timeout_ms = 100) {
        if (fd_ < 0) return -1;
        
        struct pollfd pfd = {fd_, POLLIN, 0};
        if (poll(&pfd, 1, timeout_ms) <= 0) {
            return -1;
        }
        return ::recv(fd_, buf, len, MSG_DONTWAIT);
    }
    
    // Poll for disconnect detection
    bool is_disconnected() {
        if (fd_ < 0) return true;
        
        char buf[1];
        ssize_t n = ::recv(fd_, buf, 1, MSG_PEEK | MSG_DONTWAIT);
        
        if (n == 0) return true;  // Peer closed
        if (n < 0 && errno != EAGAIN && errno != EWOULDBLOCK) return true;
        
        return false;
    }
    
    int fd() const { return fd_; }
    bool is_connected() const { return fd_ >= 0; }
    
private:
    int fd_;
};

// =============================================================================
// Basic Socket Tests
// =============================================================================

class SocketIntegrationTest : public ::testing::Test {
protected:
    void SetUp() override {
        Timestamp::calibrate();
    }
    
    TestServer server;
    TestClient client;
};

TEST_F(SocketIntegrationTest, BasicConnectDisconnect) {
    ASSERT_TRUE(server.start());
    
    std::thread server_thread([&]() {
        server.accept_client(1000);
    });
    
    ASSERT_TRUE(client.connect(server.port()));
    server_thread.join();
    
    EXPECT_TRUE(server.has_client());
    EXPECT_TRUE(client.is_connected());
    
    client.disconnect();
    EXPECT_FALSE(client.is_connected());
    
    server.stop();
}

TEST_F(SocketIntegrationTest, ServerClosesConnection) {
    ASSERT_TRUE(server.start());
    
    std::thread server_thread([&]() {
        server.accept_client(1000);
    });
    
    ASSERT_TRUE(client.connect(server.port()));
    server_thread.join();
    
    // Server closes connection
    server.disconnect_client();
    
    // Client should detect disconnect
    std::this_thread::sleep_for(std::chrono::milliseconds(10));
    EXPECT_TRUE(client.is_disconnected());
}

TEST_F(SocketIntegrationTest, ServerResetsConnection) {
    ASSERT_TRUE(server.start());
    
    std::thread server_thread([&]() {
        server.accept_client(1000);
    });
    
    ASSERT_TRUE(client.connect(server.port()));
    server_thread.join();
    
    // Server sends RST
    server.reset_client();
    
    // Client should detect disconnect
    std::this_thread::sleep_for(std::chrono::milliseconds(10));
    
    char buf[64];
    ssize_t n = client.recv_data(buf, sizeof(buf), 100);
    EXPECT_TRUE(n == 0 || n < 0);  // Disconnect detected
}

// =============================================================================
// Message Framing Tests
// =============================================================================

TEST_F(SocketIntegrationTest, CompleteMessageRoundtrip) {
    ASSERT_TRUE(server.start());
    
    std::thread server_thread([&]() {
        server.accept_client(1000);
    });
    
    ASSERT_TRUE(client.connect(server.port()));
    server_thread.join();
    
    // Create and send message
    uint8_t msg[64];
    auto* header = reinterpret_cast<MessageHeader*>(msg);
    header->length = 64;
    header->sequence_number = 42;
    header->type = MessageType::NEW_ORDER;
    std::memset(msg + sizeof(MessageHeader), 0xAB, 64 - sizeof(MessageHeader));
    
    EXPECT_EQ(client.send_data(msg, 64), 64);
    
    // Receive on server
    uint8_t recv_buf[64];
    std::this_thread::sleep_for(std::chrono::milliseconds(10));
    ssize_t n = server.recv_data(recv_buf, sizeof(recv_buf));
    
    EXPECT_EQ(n, 64);
    
    auto* recv_header = reinterpret_cast<MessageHeader*>(recv_buf);
    EXPECT_EQ(recv_header->length, 64);
    EXPECT_EQ(recv_header->sequence_number, 42);
}

TEST_F(SocketIntegrationTest, PartialMessageFromServer) {
    ASSERT_TRUE(server.start());
    
    std::thread server_thread([&]() {
        server.accept_client(1000);
    });
    
    ASSERT_TRUE(client.connect(server.port()));
    server_thread.join();
    
    // Create message
    uint8_t msg[100];
    auto* header = reinterpret_cast<MessageHeader*>(msg);
    header->length = 100;
    header->sequence_number = 99;
    std::memset(msg + sizeof(MessageHeader), 0xCD, 100 - sizeof(MessageHeader));
    
    // Server sends in chunks
    PartialMessageBuffer buffer;
    
    // Send first chunk (header only)
    server.send_data(msg, 20);
    std::this_thread::sleep_for(std::chrono::milliseconds(10));
    
    uint8_t recv_buf[128];
    ssize_t n = client.recv_data(recv_buf, sizeof(recv_buf), 100);
    ASSERT_GT(n, 0);
    
    bool complete = buffer.append(recv_buf, n);
    EXPECT_FALSE(complete);  // Not complete yet
    EXPECT_TRUE(buffer.has_partial_message());
    
    // Send rest
    server.send_data(msg + 20, 80);
    std::this_thread::sleep_for(std::chrono::milliseconds(10));
    
    n = client.recv_data(recv_buf, sizeof(recv_buf), 100);
    ASSERT_GT(n, 0);
    
    complete = buffer.append(recv_buf, n);
    EXPECT_TRUE(complete);
    
    // Verify message
    uint8_t extracted[100];
    size_t msg_len = buffer.consume_message(extracted, sizeof(extracted));
    EXPECT_EQ(msg_len, 100);
    
    auto* extracted_header = reinterpret_cast<MessageHeader*>(extracted);
    EXPECT_EQ(extracted_header->sequence_number, 99);
}

TEST_F(SocketIntegrationTest, DisconnectMidMessage) {
    ASSERT_TRUE(server.start());
    
    std::thread server_thread([&]() {
        server.accept_client(1000);
    });
    
    ASSERT_TRUE(client.connect(server.port()));
    server_thread.join();
    
    // Create large message
    uint8_t msg[1000];
    auto* header = reinterpret_cast<MessageHeader*>(msg);
    header->length = 1000;
    
    // Send partial message
    server.send_data(msg, 200);  // Only 200 of 1000 bytes
    std::this_thread::sleep_for(std::chrono::milliseconds(10));
    
    // Server disconnects mid-message
    server.disconnect_client();
    
    // Client receives partial data then EOF
    PartialMessageBuffer buffer;
    uint8_t recv_buf[1024];
    
    ssize_t n = client.recv_data(recv_buf, sizeof(recv_buf), 100);
    if (n > 0) {
        buffer.append(recv_buf, n);
    }
    
    // Try to receive more - should get disconnect
    std::this_thread::sleep_for(std::chrono::milliseconds(10));
    n = client.recv_data(recv_buf, sizeof(recv_buf), 100);
    EXPECT_TRUE(n == 0 || n < 0);  // EOF or error
    
    // Buffer should have partial data
    EXPECT_TRUE(buffer.has_partial_message() || buffer.has_partial_header());
}

// =============================================================================
// Reconnection Tests
// =============================================================================

TEST_F(SocketIntegrationTest, ClientReconnectAfterServerClose) {
    ASSERT_TRUE(server.start());
    uint16_t port = server.port();
    
    // First connection
    std::thread server_thread([&]() {
        server.accept_client(1000);
    });
    
    ASSERT_TRUE(client.connect(port));
    server_thread.join();
    EXPECT_TRUE(server.has_client());
    
    // Server closes
    server.disconnect_client();
    std::this_thread::sleep_for(std::chrono::milliseconds(20));
    
    // Client reconnects
    client.disconnect();
    
    std::thread server_thread2([&]() {
        server.accept_client(1000);
    });
    
    ASSERT_TRUE(client.connect(port));
    server_thread2.join();
    EXPECT_TRUE(server.has_client());
}

TEST_F(SocketIntegrationTest, MultipleReconnections) {
    ASSERT_TRUE(server.start());
    uint16_t port = server.port();
    
    for (int i = 0; i < 5; ++i) {
        std::thread server_thread([&]() {
            server.accept_client(1000);
        });
        
        ASSERT_TRUE(client.connect(port)) << "Connection " << i << " failed";
        server_thread.join();
        
        // Exchange data
        uint8_t msg[] = {1, 2, 3, 4};
        EXPECT_EQ(client.send_data(msg, 4), 4);
        
        // Disconnect
        server.disconnect_client();
        client.disconnect();
        
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
}

// =============================================================================
// Throughput Test Under Disconnection
// =============================================================================

TEST_F(SocketIntegrationTest, HighThroughputWithDisconnect) {
    ASSERT_TRUE(server.start());
    uint16_t port = server.port();
    
    std::thread server_thread([&]() {
        server.accept_client(1000);
    });
    
    ASSERT_TRUE(client.connect(port));
    server_thread.join();
    
    std::atomic<uint64_t> messages_sent{0};
    std::atomic<bool> stop{false};
    
    // Sender thread
    std::thread sender([&]() {
        uint8_t msg[64];
        auto* header = reinterpret_cast<MessageHeader*>(msg);
        header->length = 64;
        
        while (!stop.load()) {
            header->sequence_number = ++messages_sent;
            ssize_t n = client.send_data(msg, 64);
            if (n <= 0) break;
            
            // Small delay to prevent overwhelming
            std::this_thread::sleep_for(std::chrono::microseconds(10));
        }
    });
    
    // Let it run
    std::this_thread::sleep_for(std::chrono::milliseconds(50));
    
    // Disconnect server mid-stream
    server.disconnect_client();
    
    stop = true;
    sender.join();
    
    EXPECT_GT(messages_sent.load(), 100);  // Should have sent many before disconnect
}

// =============================================================================
// Sequence Continuity Test
// =============================================================================

TEST_F(SocketIntegrationTest, SequenceContinuityAcrossReconnect) {
    ASSERT_TRUE(server.start());
    uint16_t port = server.port();
    
    SequenceTracker tracker;
    uint32_t last_received = 0;
    
    for (int round = 0; round < 3; ++round) {
        std::thread server_thread([&]() {
            server.accept_client(1000);
        });
        
        ASSERT_TRUE(client.connect(port));
        server_thread.join();
        
        // Send some messages
        for (int i = 0; i < 10; ++i) {
            uint8_t msg[32];
            auto* header = reinterpret_cast<MessageHeader*>(msg);
            header->length = 32;
            header->sequence_number = tracker.next_send();
            
            client.send_data(msg, 32);
        }
        
        // Receive on server
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
        uint8_t recv_buf[1024];
        ssize_t n = server.recv_data(recv_buf, sizeof(recv_buf));
        
        if (n > 0) {
            // Parse messages
            size_t offset = 0;
            while (offset + sizeof(MessageHeader) <= static_cast<size_t>(n)) {
                auto* h = reinterpret_cast<MessageHeader*>(recv_buf + offset);
                if (h->length > 0 && offset + h->length <= static_cast<size_t>(n)) {
                    EXPECT_GT(h->sequence_number, last_received) 
                        << "Sequence went backwards at round " << round;
                    last_received = h->sequence_number;
                    offset += h->length;
                } else {
                    break;
                }
            }
        }
        
        // Disconnect
        server.disconnect_client();
        client.disconnect();
        
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
    
    EXPECT_GT(last_received, 0);
}

// =============================================================================
// Connection Timeout Test
// =============================================================================

TEST_F(SocketIntegrationTest, ConnectTimeout) {
    // Try to connect to a port with no listener
    TestClient client;
    
    // This IP is reserved and should not respond
    // Using localhost with no listener instead
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    ASSERT_GE(fd, 0);
    
    // Set short connect timeout
    struct timeval tv;
    tv.tv_sec = 0;
    tv.tv_usec = 100000;  // 100ms
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    
    int flags = fcntl(fd, F_GETFL, 0);
    fcntl(fd, F_SETFL, flags | O_NONBLOCK);
    
    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    addr.sin_port = htons(59999);  // Unlikely to be listening
    
    int ret = ::connect(fd, reinterpret_cast<sockaddr*>(&addr), sizeof(addr));
    
    if (ret < 0 && errno == EINPROGRESS) {
        struct pollfd pfd = {fd, POLLOUT, 0};
        ret = poll(&pfd, 1, 100);  // 100ms timeout
        
        if (ret == 0) {
            // Timeout
            close(fd);
            SUCCEED();  // Expected behavior
            return;
        }
    }
    
    if (ret == 0) {
        // Connection refused is also acceptable
        close(fd);
        SUCCEED();
    } else {
        close(fd);
        // If connect succeeded, something is listening (unexpected but OK for test)
        SUCCEED();
    }
}

// =============================================================================
// Stress Test - Rapid Connect/Disconnect
// =============================================================================

TEST_F(SocketIntegrationTest, RapidConnectDisconnect) {
    ASSERT_TRUE(server.start());
    uint16_t port = server.port();
    
    std::atomic<int> successful_connections{0};
    
    for (int i = 0; i < 20; ++i) {
        std::thread server_thread([&]() {
            if (server.accept_client(200)) {
                server.disconnect_client();
            }
        });
        
        if (client.connect(port, 200)) {
            ++successful_connections;
            client.disconnect();
        }
        
        server_thread.join();
        
        // Very short delay
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
    
    EXPECT_GT(successful_connections.load(), 10);  // Most should succeed
}

// =============================================================================
// Half-Open Connection Detection
// =============================================================================

TEST_F(SocketIntegrationTest, DetectHalfOpenConnection) {
    ASSERT_TRUE(server.start());
    
    std::thread server_thread([&]() {
        server.accept_client(1000);
    });
    
    ASSERT_TRUE(client.connect(server.port()));
    server_thread.join();
    
    // Kill server's view of connection without FIN
    // (Simulate network partition by closing listening socket)
    // This is hard to simulate properly, so we just test detection via send failure
    
    server.disconnect_client();
    std::this_thread::sleep_for(std::chrono::milliseconds(10));
    
    // Client tries to send - should eventually fail
    uint8_t msg[64] = {0};
    bool detected_disconnect = false;
    
    for (int i = 0; i < 10; ++i) {
        ssize_t n = client.send_data(msg, sizeof(msg));
        if (n <= 0) {
            detected_disconnect = true;
            break;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
    
    // Also check recv
    if (!detected_disconnect) {
        detected_disconnect = client.is_disconnected();
    }
    
    EXPECT_TRUE(detected_disconnect);
}

// =============================================================================
// Main
// =============================================================================

int main(int argc, char** argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
