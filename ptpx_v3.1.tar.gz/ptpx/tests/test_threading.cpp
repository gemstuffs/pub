// =============================================================================
// ptpx - Threading Model Test
// =============================================================================
// 
// Demonstrates the new threading model:
// - Named threads registered globally
// - Sessions bind to threads by name
// - send() is thread-safe (callable from any thread)
// - poll() is managed by the poll thread
//
// =============================================================================

#include "../include/ptpx.hpp"
#include <gtest/gtest.h>
#include <thread>
#include <chrono>
#include <atomic>

using namespace ptpx;

// =============================================================================
// Thread Registry Tests
// =============================================================================

TEST(ThreadRegistryTest, RegisterThread) {
    // Clear any previous state
    ThreadRegistry::instance().clear();
    
    // Register a named thread
    bool ok = register_thread("IO_CME")
        .cpu_affinity(0)
        .priority(ThreadPriority::HIGH)
        .create();
    
    EXPECT_TRUE(ok);
    EXPECT_TRUE(ThreadRegistry::instance().has_thread("IO_CME"));
    EXPECT_EQ(ThreadRegistry::instance().thread_count(), 1);
    
    // Duplicate registration should fail
    ok = register_thread("IO_CME").create();
    EXPECT_FALSE(ok);
    
    // Get the thread
    PollThread* thread = ThreadRegistry::instance().get_thread("IO_CME");
    EXPECT_NE(thread, nullptr);
    EXPECT_EQ(thread->name(), "IO_CME");
    
    ThreadRegistry::instance().clear();
}

TEST(ThreadRegistryTest, MultipleThreads) {
    ThreadRegistry::instance().clear();
    
    EXPECT_TRUE(register_thread("IO_CME").cpu_affinity(0).create());
    EXPECT_TRUE(register_thread("IO_NYSE").cpu_affinity(1).create());
    EXPECT_TRUE(register_thread("IO_EUREX").cpu_affinity(2).create());
    
    EXPECT_EQ(ThreadRegistry::instance().thread_count(), 3);
    
    auto names = ThreadRegistry::instance().thread_names();
    EXPECT_EQ(names.size(), 3);
    
    ThreadRegistry::instance().clear();
}

TEST(ThreadRegistryTest, DedicatedThread) {
    ThreadRegistry::instance().clear();
    
    // Get or create a dedicated thread for a session
    PollThread* t1 = ThreadRegistry::instance().get_or_create_dedicated("MY_SESSION");
    EXPECT_NE(t1, nullptr);
    EXPECT_EQ(t1->name(), "_dedicated_MY_SESSION");
    
    // Getting again returns the same thread
    PollThread* t2 = ThreadRegistry::instance().get_or_create_dedicated("MY_SESSION");
    EXPECT_EQ(t1, t2);
    
    ThreadRegistry::instance().clear();
}

TEST(ThreadRegistryTest, ThreadLifecycle) {
    ThreadRegistry::instance().clear();
    
    register_thread("TEST_THREAD").create();
    PollThread* thread = ThreadRegistry::instance().get_thread("TEST_THREAD");
    
    EXPECT_FALSE(thread->is_running());
    
    thread->start();
    std::this_thread::sleep_for(std::chrono::milliseconds(10));
    EXPECT_TRUE(thread->is_running());
    
    thread->stop();
    EXPECT_FALSE(thread->is_running());
    
    ThreadRegistry::instance().clear();
}

// =============================================================================
// Session Thread Binding Tests
// =============================================================================

TEST(SessionThreadBindingTest, SessionWithNamedThread) {
    ThreadRegistry::instance().clear();
    
    // Register thread first
    register_thread("IO_CME").create();
    
    // Create session bound to named thread
    auto cfg = session("CME_ORDERS")
        .as_initiator()
        .connect_to("127.0.0.1", 9999)
        .thread("IO_CME")  // Use named thread
        .build();
    
    EXPECT_TRUE(cfg.thread_name.has_value());
    EXPECT_EQ(*cfg.thread_name, "IO_CME");
    
    ThreadRegistry::instance().clear();
}

TEST(SessionThreadBindingTest, SessionWithDedicatedThread) {
    ThreadRegistry::instance().clear();
    
    // Create session without specifying thread (gets dedicated)
    auto cfg = session("NYSE_MD")
        .as_initiator()
        .connect_to("127.0.0.1", 9998)
        .build();
    
    EXPECT_FALSE(cfg.thread_name.has_value());  // Will get dedicated thread
    
    ThreadRegistry::instance().clear();
}

TEST(SessionThreadBindingTest, MultipleSessionsSameThread) {
    ThreadRegistry::instance().clear();
    
    // Register shared thread
    register_thread("IO_CME").cpu_affinity(2).create();
    
    // Multiple sessions can share the same thread
    auto cfg1 = session("CME_ORDERS")
        .as_initiator()
        .connect_to("127.0.0.1", 9999)
        .thread("IO_CME")
        .build();
    
    auto cfg2 = session("CME_DROPS")
        .as_initiator()
        .connect_to("127.0.0.1", 9998)
        .thread("IO_CME")  // Same thread
        .build();
    
    EXPECT_EQ(*cfg1.thread_name, "IO_CME");
    EXPECT_EQ(*cfg2.thread_name, "IO_CME");
    
    ThreadRegistry::instance().clear();
}

// =============================================================================
// Thread Safety Tests
// =============================================================================

TEST(ThreadSafetyTest, ConcurrentSendSimulation) {
    // This test verifies the thread-safe send design
    // (actual network tests would require a server)
    
    std::atomic<int> send_count{0};
    std::atomic<bool> stop{false};
    
    // Simulate multiple threads trying to "send"
    auto sender = [&](int thread_id) {
        while (!stop.load(std::memory_order_acquire)) {
            // In real code: session->send(payload, len);
            send_count.fetch_add(1, std::memory_order_relaxed);
            std::this_thread::yield();
        }
    };
    
    std::thread t1(sender, 1);
    std::thread t2(sender, 2);
    std::thread t3(sender, 3);
    
    std::this_thread::sleep_for(std::chrono::milliseconds(50));
    stop.store(true, std::memory_order_release);
    
    t1.join();
    t2.join();
    t3.join();
    
    // All sends should have completed
    EXPECT_GT(send_count.load(), 0);
}

// =============================================================================
// Main
// =============================================================================

int main(int argc, char** argv) {
    testing::InitGoogleTest(&argc, argv);
    ptpx::initialize();
    return RUN_ALL_TESTS();
}
