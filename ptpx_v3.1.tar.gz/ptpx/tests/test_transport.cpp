// =============================================================================
// ptpx - Runtime Transport Tests
// =============================================================================

#include <gtest/gtest.h>
#include <thread>
#include <chrono>
#include <atomic>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

#include "ptpx.hpp"

using namespace ptpx;

// =============================================================================
// Test Server Helper
// =============================================================================

class EchoServer {
public:
    EchoServer() : listen_fd_(-1), port_(0), running_(false) {}
    
    ~EchoServer() { stop(); }
    
    bool start() {
        listen_fd_ = socket(AF_INET, SOCK_STREAM, 0);
        if (listen_fd_ < 0) return false;
        
        int opt = 1;
        setsockopt(listen_fd_, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
        
        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        addr.sin_port = 0;  // Auto-assign
        
        if (bind(listen_fd_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) < 0) {
            close(listen_fd_);
            return false;
        }
        
        socklen_t len = sizeof(addr);
        getsockname(listen_fd_, reinterpret_cast<sockaddr*>(&addr), &len);
        port_ = ntohs(addr.sin_port);
        
        listen(listen_fd_, 5);
        running_ = true;
        
        server_thread_ = std::thread([this]() { run(); });
        return true;
    }
    
    void stop() {
        running_ = false;
        if (listen_fd_ >= 0) {
            close(listen_fd_);
            listen_fd_ = -1;
        }
        if (server_thread_.joinable()) {
            server_thread_.join();
        }
    }
    
    uint16_t port() const { return port_; }
    
private:
    void run() {
        while (running_) {
            fd_set fds;
            FD_ZERO(&fds);
            FD_SET(listen_fd_, &fds);
            
            timeval tv = {0, 100000};  // 100ms timeout
            int ret = select(listen_fd_ + 1, &fds, nullptr, nullptr, &tv);
            
            if (ret > 0 && FD_ISSET(listen_fd_, &fds)) {
                int client_fd = accept(listen_fd_, nullptr, nullptr);
                if (client_fd >= 0) {
                    handle_client(client_fd);
                    close(client_fd);
                }
            }
        }
    }
    
    void handle_client(int fd) {
        uint8_t buf[4096];
        while (running_) {
            ssize_t n = recv(fd, buf, sizeof(buf), MSG_DONTWAIT);
            if (n > 0) {
                send(fd, buf, n, 0);
            } else if (n == 0) {
                break;
            } else if (errno != EAGAIN && errno != EWOULDBLOCK) {
                break;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }
    }
    
    int listen_fd_;
    uint16_t port_;
    std::atomic<bool> running_;
    std::thread server_thread_;
};

// =============================================================================
// High-Level ExchangeClient Tests
// =============================================================================

class ExchangeClientTest : public ::testing::Test {
protected:
    void SetUp() override {
        Timestamp::calibrate();
        server_.start();
    }
    
    void TearDown() override {
        server_.stop();
    }
    
    EchoServer server_;
};

TEST_F(ExchangeClientTest, SimpleUsage) {
    // This is the ideal API - completely transport-agnostic
    ExchangeClient client("127.0.0.1", server_.port());
    
    ASSERT_TRUE(client.connect());
    EXPECT_TRUE(client.is_connected());
    
    // Transport is auto-selected
    std::cout << "ExchangeClient using: " << client.transport_name() 
              << " (~" << client.estimated_latency_ns() << "ns)\n";
    
    // Send order - no knowledge of underlying transport needed
    uint8_t order_data[64] = {0};
    auto result = client.send_order(order_data, sizeof(order_data));
    EXPECT_EQ(result, SendResult::SUCCESS);
    
    client.disconnect();
}

TEST_F(ExchangeClientTest, WithCallback) {
    ExchangeClient client("127.0.0.1", server_.port());
    
    std::atomic<int> msg_count{0};
    client.on_message([&](const ReceivedMessage& msg) {
        msg_count++;
    });
    
    client.on_disconnect([](DisconnectReason reason) {
        std::cout << "Disconnected: " << static_cast<int>(reason) << "\n";
    });
    
    ASSERT_TRUE(client.connect());
    
    // Send some data
    uint8_t data[32] = {1, 2, 3, 4};
    client.send_order(data, sizeof(data));
    
    // Poll for response
    for (int i = 0; i < 10; ++i) {
        client.poll();
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
    
    client.disconnect();
}

TEST_F(ExchangeClientTest, WithConfig) {
    ExchangeClient::Config cfg;
    cfg.host = "127.0.0.1";
    cfg.port = server_.port();
    cfg.auto_reconnect = true;
    cfg.heartbeat_enabled = false;
    
    ExchangeClient client(cfg);
    ASSERT_TRUE(client.connect());
    EXPECT_TRUE(client.is_connected());
    
    client.disconnect();
}

TEST(ExchangeClientStandaloneTest, ConnectToExchangeHelper) {
    // One-liner connection (will fail since no server, but tests API)
    auto client = connect_to_exchange("127.0.0.1", 1);  // Bad port
    EXPECT_EQ(client, nullptr);  // Should fail gracefully
}

// =============================================================================
// RuntimeConfig Tests
// =============================================================================

TEST(RuntimeConfigTest, DefaultIsAuto) {
    RuntimeConfig::instance().reset();
    EXPECT_EQ(RuntimeConfig::instance().get_transport(), TransportType::AUTO);
    EXPECT_FALSE(RuntimeConfig::instance().is_explicit());
}

TEST(RuntimeConfigTest, SetTransportExplicitly) {
    RuntimeConfig::instance().reset();
    
    RuntimeConfig::instance().set_transport(TransportType::TCPDIRECT);
    EXPECT_EQ(RuntimeConfig::instance().get_transport(), TransportType::TCPDIRECT);
    EXPECT_TRUE(RuntimeConfig::instance().is_explicit());
    
    RuntimeConfig::instance().set_transport(TransportType::KERNEL);
    EXPECT_EQ(RuntimeConfig::instance().get_transport(), TransportType::KERNEL);
    
    RuntimeConfig::instance().reset();
}

TEST(RuntimeConfigTest, UseTcpdirectHelper) {
    RuntimeConfig::instance().reset();
    
    ptpx::use_tcpdirect(true);
    EXPECT_EQ(RuntimeConfig::instance().get_transport(), TransportType::TCPDIRECT);
    
    ptpx::use_tcpdirect(false);
    EXPECT_EQ(RuntimeConfig::instance().get_transport(), TransportType::KERNEL);
    
    RuntimeConfig::instance().reset();
}

TEST(RuntimeConfigTest, UseOnloadHelper) {
    RuntimeConfig::instance().reset();
    
    ptpx::use_onload(true);
    EXPECT_EQ(RuntimeConfig::instance().get_transport(), TransportType::ONLOAD);
    
    ptpx::use_onload(false);
    EXPECT_EQ(RuntimeConfig::instance().get_transport(), TransportType::KERNEL);
    
    RuntimeConfig::instance().reset();
}

TEST(RuntimeConfigTest, UseKernelHelper) {
    RuntimeConfig::instance().reset();
    
    ptpx::use_kernel(true);
    EXPECT_EQ(RuntimeConfig::instance().get_transport(), TransportType::KERNEL);
    
    RuntimeConfig::instance().reset();
}

TEST(RuntimeConfigTest, UseAutoHelper) {
    RuntimeConfig::instance().reset();
    
    ptpx::use_tcpdirect(true);
    EXPECT_EQ(RuntimeConfig::instance().get_transport(), TransportType::TCPDIRECT);
    
    ptpx::use_auto();
    EXPECT_EQ(RuntimeConfig::instance().get_transport(), TransportType::AUTO);
    
    RuntimeConfig::instance().reset();
}

TEST(RuntimeConfigTest, ResetClearsExplicit) {
    RuntimeConfig::instance().reset();
    
    ptpx::use_tcpdirect(true);
    EXPECT_TRUE(RuntimeConfig::instance().is_explicit());
    
    RuntimeConfig::instance().reset();
    EXPECT_FALSE(RuntimeConfig::instance().is_explicit());
}

TEST(RuntimeConfigTest, FactoryRespectsRuntimeConfig) {
    RuntimeConfig::instance().reset();
    
    // Force kernel via RuntimeConfig
    ptpx::use_kernel(true);
    
    TransportConfig config;
    config.preferred_type = TransportType::AUTO;  // Let RuntimeConfig decide
    config.host = "127.0.0.1";
    config.port = 12345;
    
    auto transport = TransportFactory::create_client(config);
    EXPECT_EQ(transport->type(), TransportType::KERNEL);
    
    RuntimeConfig::instance().reset();
}

TEST(RuntimeConfigTest, ConfigOverridesRuntimeConfig) {
    RuntimeConfig::instance().reset();
    
    // Set RuntimeConfig to TCPDirect
    ptpx::use_tcpdirect(true);
    
    // But config explicitly requests kernel
    TransportConfig config;
    config.preferred_type = TransportType::KERNEL;  // Explicit, not AUTO
    config.host = "127.0.0.1";
    config.port = 12345;
    
    auto transport = TransportFactory::create_client(config);
    EXPECT_EQ(transport->type(), TransportType::KERNEL);  // Config wins
    
    RuntimeConfig::instance().reset();
}

// =============================================================================
// Transport Type Tests
// =============================================================================

TEST(TransportTypeTest, EnumValues) {
    EXPECT_EQ(static_cast<int>(TransportType::AUTO), 0);
    EXPECT_EQ(static_cast<int>(TransportType::TCPDIRECT), 1);
    EXPECT_EQ(static_cast<int>(TransportType::ONLOAD), 2);
    EXPECT_EQ(static_cast<int>(TransportType::KERNEL), 3);
}

TEST(TransportTypeTest, ToString) {
    EXPECT_STREQ(transport_type_to_string(TransportType::AUTO), "AUTO");
    EXPECT_STREQ(transport_type_to_string(TransportType::TCPDIRECT), "TCPDIRECT");
    EXPECT_STREQ(transport_type_to_string(TransportType::ONLOAD), "ONLOAD");
    EXPECT_STREQ(transport_type_to_string(TransportType::KERNEL), "KERNEL");
}

// =============================================================================
// Capability Detection Tests
// =============================================================================

TEST(TransportCapabilitiesTest, Detect) {
    auto caps = TransportCapabilities::detect();
    
    // These should always work
    SUCCEED();  // Just verify it doesn't crash
    
    std::cout << "Detected capabilities:\n";
    std::cout << "  TCPDirect available: " << (caps.tcpdirect_available ? "yes" : "no") << "\n";
    std::cout << "  Onload active: " << (caps.onload_active ? "yes" : "no") << "\n";
    std::cout << "  Solarflare NIC: " << (caps.solarflare_nic_present ? "yes" : "no");
    if (caps.solarflare_nic_present) {
        std::cout << " (" << caps.solarflare_interface << ")";
    }
    std::cout << "\n";
}

TEST(TransportCapabilitiesTest, DetectIsIdempotent) {
    auto caps1 = TransportCapabilities::detect();
    auto caps2 = TransportCapabilities::detect();
    
    EXPECT_EQ(caps1.tcpdirect_available, caps2.tcpdirect_available);
    EXPECT_EQ(caps1.onload_active, caps2.onload_active);
    EXPECT_EQ(caps1.solarflare_nic_present, caps2.solarflare_nic_present);
}

// =============================================================================
// Factory Tests
// =============================================================================

TEST(TransportFactoryTest, KernelAlwaysAvailable) {
    EXPECT_TRUE(TransportFactory::is_available(TransportType::KERNEL));
}

TEST(TransportFactoryTest, AutoAlwaysAvailable) {
    EXPECT_TRUE(TransportFactory::is_available(TransportType::AUTO));
}

TEST(TransportFactoryTest, CreateKernelTransport) {
    TransportConfig config;
    config.preferred_type = TransportType::KERNEL;
    config.host = "127.0.0.1";
    config.port = 12345;
    
    auto transport = TransportFactory::create_client(config);
    
    ASSERT_NE(transport, nullptr);
    EXPECT_EQ(transport->type(), TransportType::KERNEL);
    EXPECT_STREQ(transport->type_name(), "kernel");
    EXPECT_GE(transport->estimated_latency_ns(), 1000);  // At least 1μs
}

TEST(TransportFactoryTest, CreateAutoTransport) {
    TransportConfig config;
    config.preferred_type = TransportType::AUTO;
    config.host = "127.0.0.1";
    config.port = 12345;
    
    auto transport = TransportFactory::create_client(config);
    
    ASSERT_NE(transport, nullptr);
    // Should be one of the valid types
    EXPECT_TRUE(transport->type() == TransportType::KERNEL ||
                transport->type() == TransportType::ONLOAD ||
                transport->type() == TransportType::TCPDIRECT);
}

TEST(TransportFactoryTest, PrintAvailable) {
    // Just verify it doesn't crash
    testing::internal::CaptureStdout();
    TransportFactory::print_available();
    std::string output = testing::internal::GetCapturedStdout();
    
    EXPECT_TRUE(output.find("Available Transports") != std::string::npos);
    EXPECT_TRUE(output.find("Kernel TCP") != std::string::npos);
}

// =============================================================================
// Kernel Transport Tests
// =============================================================================

class KernelTransportTest : public ::testing::Test {
protected:
    void SetUp() override {
        Timestamp::calibrate();
        server_.start();
    }
    
    void TearDown() override {
        server_.stop();
    }
    
    EchoServer server_;
};

TEST_F(KernelTransportTest, Connect) {
    TransportConfig config;
    config.preferred_type = TransportType::KERNEL;
    config.host = "127.0.0.1";
    config.port = server_.port();
    
    auto transport = TransportFactory::create_client(config);
    
    EXPECT_FALSE(transport->is_connected());
    EXPECT_TRUE(transport->connect());
    EXPECT_TRUE(transport->is_connected());
    
    transport->disconnect();
    EXPECT_FALSE(transport->is_connected());
}

TEST_F(KernelTransportTest, SendReceive) {
    TransportConfig config;
    config.preferred_type = TransportType::KERNEL;
    config.host = "127.0.0.1";
    config.port = server_.port();
    
    auto transport = TransportFactory::create_client(config);
    ASSERT_TRUE(transport->connect());
    
    // Send data
    const char* msg = "Hello, World!";
    auto result = transport->send(msg, strlen(msg));
    EXPECT_EQ(result, SendResult::SUCCESS);
    
    // Give server time to echo
    std::this_thread::sleep_for(std::chrono::milliseconds(50));
    
    // Receive
    char buf[64];
    ssize_t received = transport->recv(buf, sizeof(buf));
    
    if (received > 0) {
        buf[received] = '\0';
        EXPECT_STREQ(buf, msg);
    }
    
    transport->disconnect();
}

TEST_F(KernelTransportTest, SendMessage) {
    TransportConfig config;
    config.preferred_type = TransportType::KERNEL;
    config.host = "127.0.0.1";
    config.port = server_.port();
    
    auto transport = TransportFactory::create_client(config);
    ASSERT_TRUE(transport->connect());
    
    // Send message with header
    uint8_t payload[] = {1, 2, 3, 4, 5, 6, 7, 8};
    auto result = transport->send_message(MessageType::NEW_ORDER, payload, sizeof(payload));
    EXPECT_EQ(result, SendResult::SUCCESS);
    
    // Verify stats
    const auto& stats = transport->stats();
    EXPECT_GT(stats.bytes_sent.load(), 0);
    EXPECT_EQ(stats.messages_sent.load(), 1);
    
    transport->disconnect();
}

TEST_F(KernelTransportTest, ConnectFailure) {
    TransportConfig config;
    config.preferred_type = TransportType::KERNEL;
    config.host = "127.0.0.1";
    config.port = 1;  // Privileged port, should fail
    config.connect_timeout_ns = 100'000'000;  // 100ms
    
    auto transport = TransportFactory::create_client(config);
    
    EXPECT_FALSE(transport->connect());
    EXPECT_FALSE(transport->is_connected());
}

TEST_F(KernelTransportTest, Stats) {
    TransportConfig config;
    config.preferred_type = TransportType::KERNEL;
    config.host = "127.0.0.1";
    config.port = server_.port();
    
    auto transport = TransportFactory::create_client(config);
    
    const auto& stats = transport->stats();
    EXPECT_EQ(stats.connects.load(), 0);
    
    ASSERT_TRUE(transport->connect());
    EXPECT_EQ(stats.connects.load(), 1);
    
    transport->disconnect();
    EXPECT_EQ(stats.disconnects.load(), 1);
}

// =============================================================================
// TCPDirect Transport Tests (Conditional)
// =============================================================================

TEST(TCPDirectTransportTest, DlopenAvailability) {
    bool available = tcpdirect::is_available();
    
    if (available) {
        std::cout << "TCPDirect library loaded successfully\n";
    } else {
        std::cout << "TCPDirect library not available (expected on non-Solarflare systems)\n";
    }
    
    SUCCEED();  // Just checking it doesn't crash
}

TEST(TCPDirectTransportTest, CreateTCPDirectTransport) {
    TransportConfig config;
    config.preferred_type = TransportType::TCPDIRECT;
    config.host = "127.0.0.1";
    config.port = 12345;
    config.interface = "eth0";
    
    auto transport = TransportFactory::create_client(config);
    
    ASSERT_NE(transport, nullptr);
    
    // If TCPDirect not available, should fall back to kernel
    if (!tcpdirect::is_available()) {
        EXPECT_EQ(transport->type(), TransportType::KERNEL);
        std::cout << "TCPDirect not available, fell back to kernel transport\n";
    } else {
        EXPECT_EQ(transport->type(), TransportType::TCPDIRECT);
        std::cout << "TCPDirect transport created\n";
    }
}

// =============================================================================
// ITransport Interface Tests
// =============================================================================

TEST(ITransportTest, InterfaceCompleteness) {
    TransportConfig config;
    config.preferred_type = TransportType::KERNEL;
    config.host = "127.0.0.1";
    config.port = 12345;
    
    auto transport = TransportFactory::create_client(config);
    
    // Verify all interface methods exist
    EXPECT_FALSE(transport->is_connected());
    EXPECT_EQ(transport->type(), TransportType::KERNEL);
    EXPECT_NE(transport->type_name(), nullptr);
    EXPECT_GT(transport->estimated_latency_ns(), 0);
    
    // Stats should be accessible
    const auto& stats = transport->stats();
    EXPECT_EQ(stats.connects.load(), 0);
}

// =============================================================================
// Integration Tests
// =============================================================================

TEST_F(KernelTransportTest, MultipleConnections) {
    TransportConfig config;
    config.preferred_type = TransportType::KERNEL;
    config.host = "127.0.0.1";
    config.port = server_.port();
    
    std::vector<std::unique_ptr<ITransport>> transports;
    
    for (int i = 0; i < 5; ++i) {
        auto t = TransportFactory::create_client(config);
        ASSERT_TRUE(t->connect());
        transports.push_back(std::move(t));
    }
    
    // All should be connected
    for (const auto& t : transports) {
        EXPECT_TRUE(t->is_connected());
    }
    
    // Disconnect all
    for (auto& t : transports) {
        t->disconnect();
        EXPECT_FALSE(t->is_connected());
    }
}

TEST_F(KernelTransportTest, ReconnectAfterDisconnect) {
    TransportConfig config;
    config.preferred_type = TransportType::KERNEL;
    config.host = "127.0.0.1";
    config.port = server_.port();
    
    auto transport = TransportFactory::create_client(config);
    
    // Connect/disconnect cycle
    for (int i = 0; i < 3; ++i) {
        ASSERT_TRUE(transport->connect());
        EXPECT_TRUE(transport->is_connected());
        transport->disconnect();
        EXPECT_FALSE(transport->is_connected());
    }
    
    EXPECT_EQ(transport->stats().connects.load(), 3);
    EXPECT_EQ(transport->stats().disconnects.load(), 3);
}

// =============================================================================
// Performance Test
// =============================================================================

TEST_F(KernelTransportTest, Throughput) {
    TransportConfig config;
    config.preferred_type = TransportType::KERNEL;
    config.host = "127.0.0.1";
    config.port = server_.port();
    
    auto transport = TransportFactory::create_client(config);
    ASSERT_TRUE(transport->connect());
    
    const int NUM_MESSAGES = 1000;
    uint8_t payload[64] = {0};
    
    auto start = std::chrono::steady_clock::now();
    
    for (int i = 0; i < NUM_MESSAGES; ++i) {
        auto result = transport->send_message(MessageType::NEW_ORDER, payload, sizeof(payload));
        ASSERT_EQ(result, SendResult::SUCCESS);
    }
    
    auto end = std::chrono::steady_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
    
    double msgs_per_sec = NUM_MESSAGES * 1'000'000.0 / duration.count();
    
    std::cout << "Sent " << NUM_MESSAGES << " messages in " << duration.count() << "μs\n";
    std::cout << "Throughput: " << static_cast<int>(msgs_per_sec) << " msgs/sec\n";
    
    EXPECT_EQ(transport->stats().messages_sent.load(), NUM_MESSAGES);
    
    transport->disconnect();
}

// =============================================================================
// Runtime Selection Documentation
// =============================================================================

TEST(RuntimeTransportTest, PrintUsageGuide) {
    std::cout << "\n";
    std::cout << "=================================================================\n";
    std::cout << "ptpx - API Levels\n";
    std::cout << "=================================================================\n";
    std::cout << "\n";
    std::cout << "=== Level 1: High-Level (Recommended) ===\n";
    std::cout << "\n";
    std::cout << "  // Completely transport-agnostic\n";
    std::cout << "  ExchangeClient client(\"192.168.1.1\", 9000);\n";
    std::cout << "  client.connect();\n";
    std::cout << "  client.send_order(order_data, len);\n";
    std::cout << "  \n";
    std::cout << "  // With callbacks\n";
    std::cout << "  client.on_message([](const ReceivedMessage& msg) {\n";
    std::cout << "      process(msg.payload, msg.payload_len);\n";
    std::cout << "  });\n";
    std::cout << "  client.poll();  // In your event loop\n";
    std::cout << "\n";
    std::cout << "  // One-liner helper\n";
    std::cout << "  auto client = connect_to_exchange(\"192.168.1.1\", 9000);\n";
    std::cout << "\n";
    std::cout << "=== Level 2: Transport Factory ===\n";
    std::cout << "\n";
    std::cout << "  TransportConfig config;\n";
    std::cout << "  config.host = \"192.168.1.1\";\n";
    std::cout << "  config.port = 9000;\n";
    std::cout << "  \n";
    std::cout << "  auto transport = TransportFactory::create_client(config);\n";
    std::cout << "  transport->connect();\n";
    std::cout << "  transport->send_message(MessageType::NEW_ORDER, data, len);\n";
    std::cout << "\n";
    std::cout << "=== Level 3: Direct (Zero Overhead) ===\n";
    std::cout << "\n";
    std::cout << "  // When you know transport at compile time\n";
    std::cout << "  DirectClient<KernelTransport> client(config);\n";
    std::cout << "  client.send_order(data, len);  // No vtable lookup\n";
    std::cout << "\n";
    std::cout << "=== Transport Control ===\n";
    std::cout << "\n";
    std::cout << "  // Programmatic\n";
    std::cout << "  ptpx::use_tcpdirect();\n";
    std::cout << "  ptpx::use_kernel();\n";
    std::cout << "  \n";
    std::cout << "  // Environment\n";
    std::cout << "  export TCP_EXCHANGE_TRANSPORT=tcpdirect\n";
    std::cout << "\n";
    std::cout << "=================================================================\n";
    
    SUCCEED();
}

// =============================================================================
// Main
// =============================================================================

int main(int argc, char** argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
